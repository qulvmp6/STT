var PageNavigationHandler = new function() {
	var e = this;

	// 定義合法的頁面走訪順序
	e.process = {
		// 本行正卡申請流程
		"1" : [
			"index.html", "step1.html", "otpVerify.html",
			"step2_1.html", "step2_2a.html",
			"step3_1.html", "step3_2.html", "step3_3.html"
		],
		// 他行卡申請流程
		"0" : [
			"index.html", "step1.html",
			"step2_1.html", "step2_2.html", "step2_3.html",
			"step3_1.html", "step3_2.html", "step3_3.html",
			"step4.html"
		],
		// 金融卡申請流程
		"2" : [
			"index.html", "step1a.html", "step1b.html", "step1c.html",
			"step2_1.html", "step2_2.html", "step2_3.html",
			"step3_1.html", "step3_2.html", "step3_3.html",
			"step4.html"
		]
	
	};

	var kvArray = [
		"step2_1.html", "step2_2.html", "step2_2a.html", "step2_3.html"
	];
	e.canBackFromNextMap = kvArray;

	// 使頁面無法回上一頁
	e.backControl = function() {
		if(Environment.MODE === "DEV") {
			return;
		}

        if (window.history && window.history.pushState) {
            $(window).on('popstate', function() {
				var hashLocation = location.hash;
				var hashSplit = hashLocation.split("#");
				// var hashSplit = hashLocation.split("#!/");
				var hashName = hashSplit[1];

				if (hashName !== '') {
					var hash = window.location.hash;
					if (hash === '') {
					  	if(!window.history.state) {
							window.history.pushState('forward', null, "#control");
						}
					}
                }
            });

            if(!window.history.state) {
            	window.history.pushState('forward', null, "#control");
            }
        }
	};

	// 比對當前的頁面走訪順序是否合法
	e.walkthroughtControl = function(isOrigin) {
		if(Environment.MODE === "DEV") {
			return;
		}
		
		var processType = "0";
		if(isOrigin == "1") {
			processType = "1";
		} else if (isOrigin == "2") {
			processType = "2";
		}

		var currentHtml = localStorage.getItem(LSKey.CURRENT_HTML);
		// console.log("currentHtml : " + currentHtml);

		var index = e.process[processType].indexOf(currentHtml);
		if(index > 0) {
			var previousHtml = localStorage.getItem(LSKey.PREVIOUS_HTML);
			// console.log("previousHtml : " + previousHtml);
			if(previousHtml !== e.process[processType][index - 1] && currentHtml !== previousHtml && !e.isBackFromNext(currentHtml, processType)) {
				showErrorPage("請依正常流程進行信用卡申請");
			}
		}
	};

	e.isBackFromNext = function(currentHtml, processType) {
		var canBackFromNext = e.canBackFromNextMap.indexOf(currentHtml);
		var isValid = false;

		if(canBackFromNext != -1) {
			var index = e.process[processType].indexOf(currentHtml);
			if(localStorage.getItem(LSKey.PREVIOUS_HTML) == e.process[processType][index + 1]) {
				isValid = true;
			}
		}

		return isValid;
	};
};
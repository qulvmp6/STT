var CM002RqData = function() {
	// 不需帶資料
}

var CM002RsData = function() {
	this.cityCardIssue = [];
	this.cardIDCFlag = [];
	this.marriage = [];
	this.education = [];
	this.addrZone = [];
	this.telZoneNum = [];
	this.addrCond = [];
	this.busIness = [];
	this.job = [];
	this.payMentDueDate = [];

	// "addrZone": [
	//     {"city":"台北市", "dists":[
	//       {"dist":"中正區", "postalCode":"100"},
	//       {"dist":"大同區", "postalCode":"103"}]},
	//     {"city":"新北市", "dists":[
	//       {"dist":"萬里", "postalCode":"207"},
	//       {"dist":"金山", "postalCode":"208"}]}
 	//  ]

 	// 其他，key-value
 	// "cardIDCFlag": [
  	//   {"key":"1", "value":"初發"},
  	//   {"key":"2", "value":"補發"},
  	//   {"key":"3", "value":"換發"}
  	// ]

}
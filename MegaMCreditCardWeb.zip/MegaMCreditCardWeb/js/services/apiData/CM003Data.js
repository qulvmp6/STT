var CM003RqData = function() {
	this.queryCodeS = "";
	this.queryCodeC = "";
}

var CM003RsData = function() {
	this.defaultCard = "";
	this.cIntrId = "";
	this.creditCards = [];

	// "creditCards": [
	// 	{
	// 		"cardName": "e秒刷一卡通鈦金卡", 
	// 		"cardKinds": [
	// 			{
	// 				"cardKind":"e秒刷一卡通鈦金卡",
	// 				"cardCode":"40230", 
	// 				"picUrl":"https:// wwwfile.megabank.com.tw/......"
	//				"feeCode":"2"
	//				"eBill":"Y"
	//				"isCombo":"Y",
	//				"additional":"MOCK信用卡補充條款"
	// 			}
	// 		]
	// 	},
	// 	{
	// 		"cardName": "幸福卡", 
	// 		"cardKinds": [
	// 			{
	// 				"cardKind":"幸福普卡", 
	// 				"cardCode":"30155", 
	// 				"picUrl":"https:// wwwfile.megabank.com.tw/......"
	//				"feeCode":"4"
	//				"eBill":"N"
	//				"isCombo":"Y",
	//				"additional":"MOCK信用卡補充條款222"
	// 			},
	// 			{
	// 				"cardKind":"幸福鈦金卡", 
	// 				"cardCode":"30156", 
	// 				"picUrl":"https:// wwwfile.megabank.com.tw/......"
	//				"feeCode":"1"
	//				"eBill":"Y"
	//				"isCombo":"N"
	// 			}
	// 		]
	// 	}
	// ]
}
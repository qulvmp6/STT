var VR003RqData = function() {
	this.custID = "";
	this.birthday = "";
	this.phoneNo = "";
}

var VR003RsData = function() {
	this.seqNo = "";
	this.maskPhone = "";
}
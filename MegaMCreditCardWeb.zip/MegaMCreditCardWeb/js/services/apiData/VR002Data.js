var VR002RqData = function() {
	this.primID = "";
	this.birthday = "";
	this.otp = "";
}

var VR002RsData = function() {
	// 無回傳資料
}
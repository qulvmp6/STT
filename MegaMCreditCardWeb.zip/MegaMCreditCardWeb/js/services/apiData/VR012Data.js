var VR012RqData = function() {
	this.uuid = "";
	this.primID = "";
}

var VR012RsData = function() {
	// 沒有回傳資料
}
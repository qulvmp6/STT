var CM004RqData = function() {
	this.postalCode = "";
}

var CM004RsData = function() {
	this.branches = [];

	// {
	//   "branches": [
	//     {"code":"406", "name":"衡陽分行"},
	//     {"code":"170", "name":"城中分行"},
	//     {"code":"309", "name":"南台北分行"}
	//   ]
	// }
}
var CM006RqData = function() {
}

var CM006RsData = function() {
	this.items = [];
}
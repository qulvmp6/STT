var VR001RqData = function() {
	this.primID = "";
	this.birthday = "";
	this.creditCard = "";
	this.dueDate = "";
	this.checkCode = "";
	this.otp = "";
}

var VR001RsData = function() {
	this.primChName =  "";
	this.cardFlag = "";
	this.billAddr = "";
	this.autoPayIndicator = "";
	this.autoPayAcctBank = "";
	this.autoPayAcctNo = "";
	this.phoneNo = "";
}
var VR004RqData = function() {
	this.custID = "";
	this.birthday = "";
	this.seqNo = "";
	this.otpCode = "";
	this.isGetCardFriendData = "";
}

var VR004RsData = function() {
	this.primChName =  "";
	this.cardFlag = "";
	this.billAddr = "";
	this.autoPayIndicator = "";
	this.autoPayAcctBank = "";
	this.autoPayAcctNo = "";
	this.phoneNo = "";
}
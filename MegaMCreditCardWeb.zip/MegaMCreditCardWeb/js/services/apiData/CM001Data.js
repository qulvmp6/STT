var CM001RqData = function() {
	this.articleCodes = [];
}

var CM001RsData = function() {
	this.articles = [];

	// "articles": [
	// 	{
	// 		"articleCode": "C1",
	// 		"article": "......",
	// 		"version": "20151112"
	// 	}
	// ]
}
var Ajax = new function() {
    var e = this;

	e.Post = function (url, dataJson, successFun, errorFun) {
        $.ajax({
            url: url,
            type: 'POST',
            data: dataJson,
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            cache: false,
            timeout : 120000,
            success: function(response) {
                if (successFun) {
                    successFun(response);
                }
            },
            error: function(xhr, status) {
                if (errorFun) {
                    errorFun(xhr, status);
                }
            }
        });
    };
};
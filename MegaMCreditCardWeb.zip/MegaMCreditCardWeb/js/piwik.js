"object" != typeof JSON_PIWIK && "object" == typeof window.JSON && window.JSON.stringify && window.JSON.parse ? JSON_PIWIK = window.JSON : function() {
        var t = {};
        (function() {
            var e = "function" == typeof define && define.amd,
                n = {
                    function: !0,
                    object: !0
                },
                i = n[typeof t] && t && !t.nodeType && t,
                r = n[typeof window] && window || this,
                o = i && n[typeof module] && module && !module.nodeType && "object" == typeof global && global;

            function a(t, e) {
                t || (t = r.Object()), e || (e = r.Object());
                var i = t.Number || r.Number,
                    o = t.String || r.String,
                    s = t.Object || r.Object,
                    u = t.Date || r.Date,
                    c = t.SyntaxError || r.SyntaxError,
                    f = t.TypeError || r.TypeError,
                    l = t.Math || r.Math,
                    h = t.JSON || r.JSON;
                "object" == typeof h && h && (e.stringify = h.stringify, e.parse = h.parse);
                var d, g, p, v = s.prototype,
                    m = v.toString,
                    T = new u(-0xc782b5b800cec);
                try {
                    T = -109252 == T.getUTCFullYear() && 0 === T.getUTCMonth() && 1 === T.getUTCDate() && 10 == T.getUTCHours() && 37 == T.getUTCMinutes() && 6 == T.getUTCSeconds() && 708 == T.getUTCMilliseconds()
                } catch (t) {}

                function b(t) {
                    if (b[t] !== p) return b[t];
                    var n;
                    if ("bug-string-char-index" == t) n = "a" != "a" [0];
                    else if ("json" == t) n = b("json-stringify") && b("json-parse");
                    else {
                        var r, a = '{"a":[1,true,false,null,"\\u0000\\b\\n\\f\\r\\t"]}';
                        if ("json-stringify" == t) {
                            var s = e.stringify,
                                c = "function" == typeof s && T;
                            if (c) {
                                (r = function() {
                                    return 1
                                }).toJSON = r;
                                try {
                                    c = "0" === s(0) && "0" === s(new i) && '""' == s(new o) && s(m) === p && s(p) === p && s() === p && "1" === s(r) && "[1]" == s([r]) && "[null]" == s([p]) && "null" == s(null) && "[null,null,null]" == s([p, m, null]) && s({
                                        a: [r, !0, !1, null, "\0\b\n\f\r\t"]
                                    }) == a && "1" === s(null, r) && "[\n 1,\n 2\n]" == s([1, 2], null, 1) && '"-271821-04-20T00:00:00.000Z"' == s(new u(-864e13)) && '"+275760-09-13T00:00:00.000Z"' == s(new u(864e13)) && '"-000001-01-01T00:00:00.000Z"' == s(new u(-621987552e5)) && '"1969-12-31T23:59:59.999Z"' == s(new u(-1))
                                } catch (t) {
                                    c = !1
                                }
                            }
                            n = c
                        }
                        if ("json-parse" == t) {
                            var f = e.parse;
                            if ("function" == typeof f) try {
                                if (0 === f("0") && !f(!1)) {
                                    var l = 5 == (r = f(a)).a.length && 1 === r.a[0];
                                    if (l) {
                                        try {
                                            l = !f('"\t"')
                                        } catch (t) {}
                                        if (l) try {
                                            l = 1 !== f("01")
                                        } catch (t) {}
                                        if (l) try {
                                            l = 1 !== f("1.")
                                        } catch (t) {}
                                    }
                                }
                            } catch (t) {
                                l = !1
                            }
                            n = l
                        }
                    }
                    return b[t] = !!n
                }
                if (!b("json")) {
                    var C = "[object Function]",
                        N = "[object Number]",
                        w = "[object String]",
                        k = "[object Array]",
                        y = b("bug-string-char-index");
                    if (!T) var A = l.floor,
                        O = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334],
                        _ = function(t, e) {
                            return O[e] + 365 * (t - 1970) + A((t - 1969 + (e = +(e > 1))) / 4) - A((t - 1901 + e) / 100) + A((t - 1601 + e) / 400)
                        };
                    if ((d = v.hasOwnProperty) || (d = function(t) {
                            var e, n = {};
                            return (n.__proto__ = null, n.__proto__ = {
                                toString: 1
                            }, n).toString != m ? d = function(t) {
                                var e = this.__proto__,
                                    n = t in (this.__proto__ = null, this);
                                return this.__proto__ = e, n
                            } : (e = n.constructor, d = function(t) {
                                var n = (this.constructor || e).prototype;
                                return t in this && !(t in n && this[t] === n[t])
                            }), n = null, d.call(this, t)
                        }), g = function(t, e) {
                            var i, r, o, a = 0;
                            (i = function() {
                                this.valueOf = 0
                            }).prototype.valueOf = 0, r = new i;
                            for (o in r) d.call(r, o) && a++;
                            return i = r = null, a ? g = 2 == a ? function(t, e) {
                                var n, i = {},
                                    r = m.call(t) == C;
                                for (n in t) r && "prototype" == n || d.call(i, n) || !(i[n] = 1) || !d.call(t, n) || e(n)
                            } : function(t, e) {
                                var n, i, r = m.call(t) == C;
                                for (n in t) r && "prototype" == n || !d.call(t, n) || (i = "constructor" === n) || e(n);
                                (i || d.call(t, n = "constructor")) && e(n)
                            } : (r = ["valueOf", "toString", "toLocaleString", "propertyIsEnumerable", "isPrototypeOf", "hasOwnProperty", "constructor"], g = function(t, e) {
                                var i, o, a = m.call(t) == C,
                                    s = !a && "function" != typeof t.constructor && n[typeof t.hasOwnProperty] && t.hasOwnProperty || d;
                                for (i in t) a && "prototype" == i || !s.call(t, i) || e(i);
                                for (o = r.length; i = r[--o]; s.call(t, i) && e(i));
                            }), g(t, e)
                        }, !b("json-stringify")) {
                        var E = {
                                92: "\\\\",
                                34: '\\"',
                                8: "\\b",
                                12: "\\f",
                                10: "\\n",
                                13: "\\r",
                                9: "\\t"
                            },
                            S = function(t, e) {
                                return ("000000" + (e || 0)).slice(-t)
                            },
                            I = function(t) {
                                for (var e = '"', n = 0, i = t.length, r = !y || i > 10, o = r && (y ? t.split("") : t); n < i; n++) {
                                    var a = t.charCodeAt(n);
                                    switch (a) {
                                        case 8:
                                        case 9:
                                        case 10:
                                        case 12:
                                        case 13:
                                        case 34:
                                        case 92:
                                            e += E[a];
                                            break;
                                        default:
                                            if (a < 32) {
                                                e += "\\u00" + S(2, a.toString(16));
                                                break
                                            }
                                            e += r ? o[n] : t.charAt(n)
                                    }
                                }
                                return e + '"'
                            },
                            P = function(t, e, n, i, r, o, a) {
                                var s, u, c, l, h, v, T, b, C, y, O, E, x, R, L, j;
                                try {
                                    s = e[t]
                                } catch (t) {}
                                if ("object" == typeof s && s)
                                    if ("[object Date]" != (u = m.call(s)) || d.call(s, "toJSON")) "function" == typeof s.toJSON && (u != N && u != w && u != k || d.call(s, "toJSON")) && (s = s.toJSON(t));
                                    else if (s > -1 / 0 && s < 1 / 0) {
                                    if (_) {
                                        for (h = A(s / 864e5), c = A(h / 365.2425) + 1970 - 1; _(c + 1, 0) <= h; c++);
                                        for (l = A((h - _(c, 0)) / 30.42); _(c, l + 1) <= h; l++);
                                        h = 1 + h - _(c, l), T = A((v = (s % 864e5 + 864e5) % 864e5) / 36e5) % 24, b = A(v / 6e4) % 60, C = A(v / 1e3) % 60, y = v % 1e3
                                    } else c = s.getUTCFullYear(), l = s.getUTCMonth(), h = s.getUTCDate(), T = s.getUTCHours(), b = s.getUTCMinutes(), C = s.getUTCSeconds(), y = s.getUTCMilliseconds();
                                    s = (c <= 0 || c >= 1e4 ? (c < 0 ? "-" : "+") + S(6, c < 0 ? -c : c) : S(4, c)) + "-" + S(2, l + 1) + "-" + S(2, h) + "T" + S(2, T) + ":" + S(2, b) + ":" + S(2, C) + "." + S(3, y) + "Z"
                                } else s = null;
                                if (n && (s = n.call(e, t, s)), null === s) return "null";
                                if ("[object Boolean]" == (u = m.call(s))) return "" + s;
                                if (u == N) return s > -1 / 0 && s < 1 / 0 ? "" + s : "null";
                                if (u == w) return I("" + s);
                                if ("object" == typeof s) {
                                    for (R = a.length; R--;)
                                        if (a[R] === s) throw f();
                                    if (a.push(s), O = [], L = o, o += r, u == k) {
                                        for (x = 0, R = s.length; x < R; x++) E = P(x, s, n, i, r, o, a), O.push(E === p ? "null" : E);
                                        j = O.length ? r ? "[\n" + o + O.join(",\n" + o) + "\n" + L + "]" : "[" + O.join(",") + "]" : "[]"
                                    } else g(i || s, function(t) {
                                        var e = P(t, s, n, i, r, o, a);
                                        e !== p && O.push(I(t) + ":" + (r ? " " : "") + e)
                                    }), j = O.length ? r ? "{\n" + o + O.join(",\n" + o) + "\n" + L + "}" : "{" + O.join(",") + "}" : "{}";
                                    return a.pop(), j
                                }
                            };
                        e.stringify = function(t, e, i) {
                            var r, o, a, s;
                            if (n[typeof e] && e)
                                if ((s = m.call(e)) == C) o = e;
                                else if (s == k) {
                                a = {};
                                for (var u, c = 0, f = e.length; c < f; u = e[c++], ((s = m.call(u)) == w || s == N) && (a[u] = 1));
                            }
                            if (i)
                                if ((s = m.call(i)) == N) {
                                    if ((i -= i % 1) > 0)
                                        for (r = "", i > 10 && (i = 10); r.length < i; r += " ");
                                } else s == w && (r = i.length <= 10 ? i : i.slice(0, 10));
                            return P("", ((u = {})[""] = t, u), o, a, r, "", [])
                        }
                    }
                    if (!b("json-parse")) {
                        var x, R, L = o.fromCharCode,
                            j = {
                                92: "\\",
                                34: '"',
                                47: "/",
                                98: "\b",
                                116: "\t",
                                110: "\n",
                                102: "\f",
                                114: "\r"
                            },
                            V = function() {
                                throw x = R = null, c()
                            },
                            U = function() {
                                for (var t, e, n, i, r, o = R, a = o.length; x < a;) switch (r = o.charCodeAt(x)) {
                                    case 9:
                                    case 10:
                                    case 13:
                                    case 32:
                                        x++;
                                        break;
                                    case 123:
                                    case 125:
                                    case 91:
                                    case 93:
                                    case 58:
                                    case 44:
                                        return t = y ? o.charAt(x) : o[x], x++, t;
                                    case 34:
                                        for (t = "@", x++; x < a;)
                                            if ((r = o.charCodeAt(x)) < 32) V();
                                            else if (92 == r) switch (r = o.charCodeAt(++x)) {
                                            case 92:
                                            case 34:
                                            case 47:
                                            case 98:
                                            case 116:
                                            case 110:
                                            case 102:
                                            case 114:
                                                t += j[r], x++;
                                                break;
                                            case 117:
                                                for (e = ++x, n = x + 4; x < n; x++)(r = o.charCodeAt(x)) >= 48 && r <= 57 || r >= 97 && r <= 102 || r >= 65 && r <= 70 || V();
                                                t += L("0x" + o.slice(e, x));
                                                break;
                                            default:
                                                V()
                                        } else {
                                            if (34 == r) break;
                                            for (r = o.charCodeAt(x), e = x; r >= 32 && 92 != r && 34 != r;) r = o.charCodeAt(++x);
                                            t += o.slice(e, x)
                                        }
                                        if (34 == o.charCodeAt(x)) return x++, t;
                                        V();
                                    default:
                                        if (e = x, 45 == r && (i = !0, r = o.charCodeAt(++x)), r >= 48 && r <= 57) {
                                            for (48 == r && ((r = o.charCodeAt(x + 1)) >= 48 && r <= 57) && V(), i = !1; x < a && ((r = o.charCodeAt(x)) >= 48 && r <= 57); x++);
                                            if (46 == o.charCodeAt(x)) {
                                                for (n = ++x; n < a && ((r = o.charCodeAt(n)) >= 48 && r <= 57); n++);
                                                n == x && V(), x = n
                                            }
                                            if (101 == (r = o.charCodeAt(x)) || 69 == r) {
                                                for (43 != (r = o.charCodeAt(++x)) && 45 != r || x++, n = x; n < a && ((r = o.charCodeAt(n)) >= 48 && r <= 57); n++);
                                                n == x && V(), x = n
                                            }
                                            return +o.slice(e, x)
                                        }
                                        if (i && V(), "true" == o.slice(x, x + 4)) return x += 4, !0;
                                        if ("false" == o.slice(x, x + 5)) return x += 5, !1;
                                        if ("null" == o.slice(x, x + 4)) return x += 4, null;
                                        V()
                                }
                                return "$"
                            },
                            D = function(t) {
                                var e, n;
                                if ("$" == t && V(), "string" == typeof t) {
                                    if ("@" == (y ? t.charAt(0) : t[0])) return t.slice(1);
                                    if ("[" == t) {
                                        for (e = [];
                                            "]" != (t = U()); n || (n = !0)) n && ("," == t ? "]" == (t = U()) && V() : V()), "," == t && V(), e.push(D(t));
                                        return e
                                    }
                                    if ("{" == t) {
                                        for (e = {};
                                            "}" != (t = U()); n || (n = !0)) n && ("," == t ? "}" == (t = U()) && V() : V()), "," != t && "string" == typeof t && "@" == (y ? t.charAt(0) : t[0]) && ":" == U() || V(), e[t.slice(1)] = D(U());
                                        return e
                                    }
                                    V()
                                }
                                return t
                            },
                            q = function(t, e, n) {
                                var i = W(t, e, n);
                                i === p ? delete t[e] : t[e] = i
                            },
                            W = function(t, e, n) {
                                var i, r = t[e];
                                if ("object" == typeof r && r)
                                    if (m.call(r) == k)
                                        for (i = r.length; i--;) q(r, i, n);
                                    else g(r, function(t) {
                                        q(r, t, n)
                                    });
                                return n.call(t, e, r)
                            };
                        e.parse = function(t, e) {
                            var n, i;
                            return x = 0, R = "" + t, n = D(U()), "$" != U() && V(), x = R = null, e && m.call(e) == C ? W(((i = {})[""] = n, i), "", e) : n
                        }
                    }
                }
                return e.runInContext = a, e
            }
            if (!o || o.global !== o && o.window !== o && o.self !== o || (r = o), i && !e) a(r, i);
            else {
                var s = r.JSON,
                    u = r.JSON3,
                    c = !1,
                    f = a(r, r.JSON3 = {
                        noConflict: function() {
                            return c || (c = !0, r.JSON = s, r.JSON3 = u, s = u = null), f
                        }
                    });
                r.JSON = {
                    parse: f.parse,
                    stringify: f.stringify
                }
            }
            e && define(function() {
                return f
            })
        }).call(this), JSON_PIWIK = t
    }(), "object" != typeof _paq && (_paq = []), "object" != typeof window.Piwik && (window.Piwik = function() {
        var t, e, n, i = {},
            r = {},
            o = document,
            a = navigator,
            s = screen,
            u = window,
            c = u.performance || u.mozPerformance || u.msPerformance || u.webkitPerformance,
            f = u.encodeURIComponent,
            l = u.decodeURIComponent,
            h = (unescape, []),
            d = [],
            g = 0,
            p = !1;

        function v(t) {
            try {
                return l(t)
            } catch (e) {
                return unescape(t)
            }
        }

        function m(t) {
            return "undefined" !== typeof t
        }

        function T(t) {
            return "function" == typeof t
        }

        function b(t) {
            return "object" == typeof t
        }

        function C(t) {
            return "string" == typeof t || t instanceof String
        }

        function N(t) {
            "undefined" !== typeof console && console && console.error && console.error(t)
        }

        function w() {
            var t, e, i, r, o;
            for (t = 0; t < arguments.length; t += 1) {
                var a, s;
                if (o = null, arguments[t] && arguments[t].slice && (o = arguments[t].slice()), C(i = (r = arguments[t]).shift()) && i.indexOf("::") > 0) s = (a = i.split("::"))[0], i = a[1], "object" == typeof n[s] && "function" == typeof n[s][i] ? n[s][i].apply(n[s], r) : o && d.push(o);
                else
                    for (e = 0; e < h.length; e++)
                        if (C(i)) {
                            s = h[e];
                            var u = i.indexOf(".") > 0;
                            if (u)
                                if (a = i.split("."), s && "object" == typeof s[a[0]]) s = s[a[0]], i = a[1];
                                else if (o) {
                                d.push(o);
                                break
                            }
                            if (s[i]) s[i].apply(s, r);
                            else {
                                var c = "The method '" + i + '\' was not found in "_paq" variable.  Please have a look at the Piwik tracker documentation: https://developer.piwik.org/api-reference/tracking-javascript';
                                if (N(c), !u) throw new TypeError(c)
                            }
                            if ("addTracker" === i) break;
                            if ("setTrackerUrl" === i || "setSiteId" === i) break
                        } else i.apply(h[e], r)
            }
        }

        function k(t, e, n, i) {
            return t.addEventListener ? (t.addEventListener(e, n, i), !0) : t.attachEvent ? t.attachEvent("on" + e, n) : void(t["on" + e] = n)
        }

        function y(t) {
            "complete" === o.readyState ? t() : u.addEventListener ? u.addEventListener("load", t) : u.attachEvent && u.attachEvent("onload", t)
        }

        function A(t) {
            var e = !1;
            (e = o.attachEvent ? "complete" === o.readyState : "loading" !== o.readyState) ? t(): (o.addEventListener ? k(o, "DOMContentLoaded", function n() {
                o.removeEventListener("DOMContentLoaded", n, !1), e || (e = !0, t())
            }) : o.attachEvent && (o.attachEvent("onreadystatechange", function n() {
                "complete" === o.readyState && (o.detachEvent("onreadystatechange", n), e || (e = !0, t()))
            }), o.documentElement.doScroll && u === u.top && function n() {
                if (!e) {
                    try {
                        o.documentElement.doScroll("left")
                    } catch (t) {
                        return void setTimeout(n, 0)
                    }
                    e = !0, t()
                }
            }()), k(u, "load", function() {
                e || (e = !0, t())
            }, !1))
        }

        function O(t, e, n) {
            if (!t) return "";
            var r, o, a = "";
            for (r in i) Object.prototype.hasOwnProperty.call(i, r) && (i[r] && "function" == typeof i[r][t]) && (o = (0, i[r][t])(e || {}, n)) && (a += o);
            return a
        }

        function _(t) {
            var e = new RegExp("^([a-z]+):").exec(t);
            return e ? e[1] : null
        }

        function E(t) {
            var e = new RegExp("^(?:(?:https?|ftp):)/*(?:[^@]+@)?([^:/#]+)").exec(t);
            return e ? e[1] : t
        }

        function S(t, e) {
            return 0 === (t = String(t)).lastIndexOf(e, 0)
        }

        function I(t, e) {
            return -1 !== (t = String(t)).indexOf(e, t.length - e.length)
        }

        function P(t, e) {
            return (t = String(t)).substr(0, t.length - e)
        }

        function x(t, e) {
            if (-1 === (t = String(t)).indexOf("?" + e + "=") && -1 === t.indexOf("&" + e + "=")) return t;
            var n = t.indexOf("?");
            if (-1 === n) return t;
            var i = t.substr(n + 1),
                r = t.substr(0, n);
            if (i) {
                var o = "",
                    a = i.indexOf("#"); - 1 !== a && (o = i.substr(a + 1), i = i.substr(0, a));
                for (var s = i.split("&"), u = s.length - 1; u >= 0; u--) s[u].split("=")[0] === e && s.splice(u, 1);
                var c = s.join("&");
                c && (r = r + "?" + c), o && (r += "#" + o)
            }
            return r
        }

        function R(t, e) {
            var n = new RegExp("[\\?&#]" + e + "=([^&#]*)").exec(t);
            return n ? l(n[1]) : ""
        }

        function L(t) {
            return t && String(t) === t ? t.replace(/^\s+|\s+$/g, "") : t
        }

        function j(t) {
            var e, n, i, r, o, a, s, u, c, l, h = function(t, e) {
                    return t << e | t >>> 32 - e
                },
                d = function(t) {
                    var e, n = "";
                    for (e = 7; e >= 0; e--) n += (t >>> 4 * e & 15).toString(16);
                    return n
                },
                g = [],
                p = 1732584193,
                v = 4023233417,
                m = 2562383102,
                T = 271733878,
                b = 3285377520,
                C = [];
            for (l = (t = unescape(f(t))).length, n = 0; n < l - 3; n += 4) i = t.charCodeAt(n) << 24 | t.charCodeAt(n + 1) << 16 | t.charCodeAt(n + 2) << 8 | t.charCodeAt(n + 3), C.push(i);
            switch (3 & l) {
                case 0:
                    n = 2147483648;
                    break;
                case 1:
                    n = t.charCodeAt(l - 1) << 24 | 8388608;
                    break;
                case 2:
                    n = t.charCodeAt(l - 2) << 24 | t.charCodeAt(l - 1) << 16 | 32768;
                    break;
                case 3:
                    n = t.charCodeAt(l - 3) << 24 | t.charCodeAt(l - 2) << 16 | t.charCodeAt(l - 1) << 8 | 128
            }
            for (C.push(n); 14 != (15 & C.length);) C.push(0);
            for (C.push(l >>> 29), C.push(l << 3 & 4294967295), e = 0; e < C.length; e += 16) {
                for (n = 0; n < 16; n++) g[n] = C[e + n];
                for (n = 16; n <= 79; n++) g[n] = h(g[n - 3] ^ g[n - 8] ^ g[n - 14] ^ g[n - 16], 1);
                for (r = p, o = v, a = m, s = T, u = b, n = 0; n <= 19; n++) c = h(r, 5) + (o & a | ~o & s) + u + g[n] + 1518500249 & 4294967295, u = s, s = a, a = h(o, 30), o = r, r = c;
                for (n = 20; n <= 39; n++) c = h(r, 5) + (o ^ a ^ s) + u + g[n] + 1859775393 & 4294967295, u = s, s = a, a = h(o, 30), o = r, r = c;
                for (n = 40; n <= 59; n++) c = h(r, 5) + (o & a | o & s | a & s) + u + g[n] + 2400959708 & 4294967295, u = s, s = a, a = h(o, 30), o = r, r = c;
                for (n = 60; n <= 79; n++) c = h(r, 5) + (o ^ a ^ s) + u + g[n] + 3395469782 & 4294967295, u = s, s = a, a = h(o, 30), o = r, r = c;
                p = p + r & 4294967295, v = v + o & 4294967295, m = m + a & 4294967295, T = T + s & 4294967295, b = b + u & 4294967295
            }
            return (c = d(p) + d(v) + d(m) + d(T) + d(b)).toLowerCase()
        }

        function V(t) {
            var e = t.length;
            return "." === t.charAt(--e) && (t = t.slice(0, e)), "*." === t.slice(0, 2) && (t = t.slice(1)), -1 !== t.indexOf("/") && (t = t.substr(0, t.indexOf("/"))), t
        }

        function U(t) {
            return t ? !m(t.children) && m(t.childNodes) ? t.children : m(t.children) ? t.children : [] : []
        }

        function D(t, e) {
            if (t && t.indexOf) return t.indexOf(e);
            if (!m(t) || null === t) return -1;
            if (!t.length) return -1;
            var n = t.length;
            if (0 === n) return -1;
            for (var i = 0; i < n;) {
                if (t[i] === e) return i;
                i++
            }
            return -1
        }

        function q(t) {
            if (!t) return !1;

            function e(t, e) {
                return u.getComputedStyle ? o.defaultView.getComputedStyle(t, null)[e] : t.currentStyle ? t.currentStyle[e] : void 0
            }
            return function n(i, r, a, s, u, c, f) {
                var l = i.parentNode;
                return !! function(t) {
                    for (t = t.parentNode; t;) {
                        if (t === o) return !0;
                        t = t.parentNode
                    }
                    return !1
                }(i) && (9 === l.nodeType || "0" !== e(i, "opacity") && "none" !== e(i, "display") && "hidden" !== e(i, "visibility") && (m(r) && m(a) && m(s) && m(u) && m(c) && m(f) || (r = i.offsetTop, u = i.offsetLeft, s = r + i.offsetHeight, a = u + i.offsetWidth, c = i.offsetWidth, f = i.offsetHeight), (t !== i || 0 !== f && 0 !== c || "hidden" !== e(i, "overflow")) && (!l || ("hidden" !== e(l, "overflow") && "scroll" !== e(l, "overflow") || !(u + 1 > l.offsetWidth + l.scrollLeft || u + c - 1 < l.scrollLeft || r + 1 > l.offsetHeight + l.scrollTop || r + f - 1 < l.scrollTop)) && (i.offsetParent === l && (u += l.offsetLeft, r += l.offsetTop), n(l, r, a, s, u, c, f)))))
            }(t)
        }
        var W = {
                htmlCollectionToArray: function(t) {
                    var e, n = [];
                    if (!t || !t.length) return n;
                    for (e = 0; e < t.length; e++) n.push(t[e]);
                    return n
                },
                find: function(t) {
                    if (!document.querySelectorAll || !t) return [];
                    var e = document.querySelectorAll(t);
                    return this.htmlCollectionToArray(e)
                },
                findMultiple: function(t) {
                    if (!t || !t.length) return [];
                    var e, n, i = [];
                    for (e = 0; e < t.length; e++) n = this.find(t[e]), i = i.concat(n);
                    return i = this.makeNodesUnique(i)
                },
                findNodesByTagName: function(t, e) {
                    if (!t || !e || !t.getElementsByTagName) return [];
                    var n = t.getElementsByTagName(e);
                    return this.htmlCollectionToArray(n)
                },
                makeNodesUnique: function(t) {
                    var e = [].concat(t);
                    if (t.sort(function(t, n) {
                            if (t === n) return 0;
                            var i = D(e, t),
                                r = D(e, n);
                            return i === r ? 0 : i > r ? -1 : 1
                        }), t.length <= 1) return t;
                    var n, i = 0,
                        r = 0,
                        o = [];
                    for (n = t[i++]; n;) n === t[i] && (r = o.push(i)), n = t[i++] || null;
                    for (; r--;) t.splice(o[r], 1);
                    return t
                },
                getAttributeValueFromNode: function(t, e) {
                    if (this.hasNodeAttribute(t, e)) {
                        if (t && t.getAttribute) return t.getAttribute(e);
                        if (t && t.attributes)
                            if ("undefined" !== typeof t.attributes[e]) {
                                if (t.attributes[e].value) return t.attributes[e].value;
                                if (t.attributes[e].nodeValue) return t.attributes[e].nodeValue;
                                var n, i = t.attributes;
                                if (i) {
                                    for (n = 0; n < i.length; n++)
                                        if (i[n].nodeName === e) return i[n].nodeValue;
                                    return null
                                }
                            }
                    }
                },
                hasNodeAttributeWithValue: function(t, e) {
                    return !!this.getAttributeValueFromNode(t, e)
                },
                hasNodeAttribute: function(t, e) {
                    return t && t.hasAttribute ? t.hasAttribute(e) : !(!t || !t.attributes) && "undefined" !== typeof t.attributes[e]
                },
                hasNodeCssClass: function(t, e) {
                    if (t && e && t.className && -1 !== D("string" == typeof t.className ? t.className.split(" ") : [], e)) return !0;
                    return !1
                },
                findNodesHavingAttribute: function(t, e, n) {
                    if (n || (n = []), !t || !e) return n;
                    var i, r, o = U(t);
                    if (!o || !o.length) return n;
                    for (i = 0; i < o.length; i++) r = o[i], this.hasNodeAttribute(r, e) && n.push(r), n = this.findNodesHavingAttribute(r, e, n);
                    return n
                },
                findFirstNodeHavingAttribute: function(t, e) {
                    if (t && e) {
                        if (this.hasNodeAttribute(t, e)) return t;
                        var n = this.findNodesHavingAttribute(t, e);
                        return n && n.length ? n[0] : void 0
                    }
                },
                findFirstNodeHavingAttributeWithValue: function(t, e) {
                    if (t && e) {
                        if (this.hasNodeAttributeWithValue(t, e)) return t;
                        var n, i = this.findNodesHavingAttribute(t, e);
                        if (i && i.length)
                            for (n = 0; n < i.length; n++)
                                if (this.getAttributeValueFromNode(i[n], e)) return i[n]
                    }
                },
                findNodesHavingCssClass: function(t, e, n) {
                    if (n || (n = []), !t || !e) return n;
                    if (t.getElementsByClassName) {
                        var i = t.getElementsByClassName(e);
                        return this.htmlCollectionToArray(i)
                    }
                    var r, o, a = U(t);
                    if (!a || !a.length) return [];
                    for (r = 0; r < a.length; r++) o = a[r], this.hasNodeCssClass(o, e) && n.push(o), n = this.findNodesHavingCssClass(o, e, n);
                    return n
                },
                findFirstNodeHavingClass: function(t, e) {
                    if (t && e) {
                        if (this.hasNodeCssClass(t, e)) return t;
                        var n = this.findNodesHavingCssClass(t, e);
                        return n && n.length ? n[0] : void 0
                    }
                },
                isLinkElement: function(t) {
                    if (!t) return !1;
                    return -1 !== D(["a", "area"], String(t.nodeName).toLowerCase())
                },
                setAnyAttribute: function(t, e, n) {
                    t && e && (t.setAttribute ? t.setAttribute(e, n) : t[e] = n)
                }
            },
            F = {
                CONTENT_ATTR: "data-track-content",
                CONTENT_CLASS: "piwikTrackContent",
                CONTENT_NAME_ATTR: "data-content-name",
                CONTENT_PIECE_ATTR: "data-content-piece",
                CONTENT_PIECE_CLASS: "piwikContentPiece",
                CONTENT_TARGET_ATTR: "data-content-target",
                CONTENT_TARGET_CLASS: "piwikContentTarget",
                CONTENT_IGNOREINTERACTION_ATTR: "data-content-ignoreinteraction",
                CONTENT_IGNOREINTERACTION_CLASS: "piwikContentIgnoreInteraction",
                location: void 0,
                findContentNodes: function() {
                    var t = "." + this.CONTENT_CLASS,
                        e = "[" + this.CONTENT_ATTR + "]";
                    return W.findMultiple([t, e])
                },
                findContentNodesWithinNode: function(t) {
                    if (!t) return [];
                    var e, n = W.findNodesHavingCssClass(t, this.CONTENT_CLASS),
                        i = W.findNodesHavingAttribute(t, this.CONTENT_ATTR);
                    if (i && i.length)
                        for (e = 0; e < i.length; e++) n.push(i[e]);
                    return W.hasNodeAttribute(t, this.CONTENT_ATTR) ? n.push(t) : W.hasNodeCssClass(t, this.CONTENT_CLASS) && n.push(t), n = W.makeNodesUnique(n)
                },
                findParentContentNode: function(t) {
                    if (t)
                        for (var e = t, n = 0; e && e !== o && e.parentNode;) {
                            if (W.hasNodeAttribute(e, this.CONTENT_ATTR)) return e;
                            if (W.hasNodeCssClass(e, this.CONTENT_CLASS)) return e;
                            if (e = e.parentNode, n > 1e3) break;
                            n++
                        }
                },
                findPieceNode: function(t) {
                    var e;
                    return (e = W.findFirstNodeHavingAttribute(t, this.CONTENT_PIECE_ATTR)) || (e = W.findFirstNodeHavingClass(t, this.CONTENT_PIECE_CLASS)), e || t
                },
                findTargetNodeNoDefault: function(t) {
                    if (t) {
                        var e = W.findFirstNodeHavingAttributeWithValue(t, this.CONTENT_TARGET_ATTR);
                        return e || ((e = W.findFirstNodeHavingAttribute(t, this.CONTENT_TARGET_ATTR)) ? e : (e = W.findFirstNodeHavingClass(t, this.CONTENT_TARGET_CLASS)) || void 0)
                    }
                },
                findTargetNode: function(t) {
                    var e = this.findTargetNodeNoDefault(t);
                    return e || t
                },
                findContentName: function(t) {
                    if (t) {
                        var e = W.findFirstNodeHavingAttributeWithValue(t, this.CONTENT_NAME_ATTR);
                        if (e) return W.getAttributeValueFromNode(e, this.CONTENT_NAME_ATTR);
                        var n = this.findContentPiece(t);
                        if (n) return this.removeDomainIfIsInLink(n);
                        if (W.hasNodeAttributeWithValue(t, "title")) return W.getAttributeValueFromNode(t, "title");
                        var i = this.findPieceNode(t);
                        if (W.hasNodeAttributeWithValue(i, "title")) return W.getAttributeValueFromNode(i, "title");
                        var r = this.findTargetNode(t);
                        return W.hasNodeAttributeWithValue(r, "title") ? W.getAttributeValueFromNode(r, "title") : void 0
                    }
                },
                findContentPiece: function(t) {
                    if (t) {
                        var e = W.findFirstNodeHavingAttributeWithValue(t, this.CONTENT_PIECE_ATTR);
                        if (e) return W.getAttributeValueFromNode(e, this.CONTENT_PIECE_ATTR);
                        var n = this.findPieceNode(t),
                            i = this.findMediaUrlInNode(n);
                        return i ? this.toAbsoluteUrl(i) : void 0
                    }
                },
                findContentTarget: function(t) {
                    if (t) {
                        var e, n = this.findTargetNode(t);
                        if (W.hasNodeAttributeWithValue(n, this.CONTENT_TARGET_ATTR)) return W.getAttributeValueFromNode(n, this.CONTENT_TARGET_ATTR);
                        if (W.hasNodeAttributeWithValue(n, "href")) return e = W.getAttributeValueFromNode(n, "href"), this.toAbsoluteUrl(e);
                        var i = this.findPieceNode(t);
                        return W.hasNodeAttributeWithValue(i, "href") ? (e = W.getAttributeValueFromNode(i, "href"), this.toAbsoluteUrl(e)) : void 0
                    }
                },
                isSameDomain: function(t) {
                    if (!t || !t.indexOf) return !1;
                    if (0 === t.indexOf(this.getLocation().origin)) return !0;
                    var e = t.indexOf(this.getLocation().host);
                    return 8 >= e && 0 <= e
                },
                removeDomainIfIsInLink: function(t) {
                    return t && t.search && -1 !== t.search(new RegExp("^https?://[^/]+")) && this.isSameDomain(t) && ((t = t.replace(new RegExp("^.*//[^/]+"), "")) || (t = "/")), t
                },
                findMediaUrlInNode: function(t) {
                    if (t) {
                        var e = t.nodeName.toLowerCase();
                        if (-1 !== D(["img", "embed", "video", "audio"], e) && W.findFirstNodeHavingAttributeWithValue(t, "src")) {
                            var n = W.findFirstNodeHavingAttributeWithValue(t, "src");
                            return W.getAttributeValueFromNode(n, "src")
                        }
                        if ("object" === e && W.hasNodeAttributeWithValue(t, "data")) return W.getAttributeValueFromNode(t, "data");
                        if ("object" === e) {
                            var i, r = W.findNodesByTagName(t, "param");
                            if (r && r.length)
                                for (i = 0; i < r.length; i++)
                                    if ("movie" === W.getAttributeValueFromNode(r[i], "name") && W.hasNodeAttributeWithValue(r[i], "value")) return W.getAttributeValueFromNode(r[i], "value");
                            var o = W.findNodesByTagName(t, "embed");
                            if (o && o.length) return this.findMediaUrlInNode(o[0])
                        }
                    }
                },
                trim: function(t) {
                    return L(t)
                },
                isOrWasNodeInViewport: function(t) {
                    if (!t || !t.getBoundingClientRect || 1 !== t.nodeType) return !0;
                    var e = t.getBoundingClientRect(),
                        n = o.documentElement || {},
                        i = e.top < 0;
                    i && t.offsetTop && (i = t.offsetTop + e.height > 0);
                    var r = n.clientWidth;
                    u.innerWidth && r > u.innerWidth && (r = u.innerWidth);
                    var a = n.clientHeight;
                    return u.innerHeight && a > u.innerHeight && (a = u.innerHeight), (e.bottom > 0 || i) && e.right > 0 && e.left < r && (e.top < a || i)
                },
                isNodeVisible: function(t) {
                    var e = q(t),
                        n = this.isOrWasNodeInViewport(t);
                    return e && n
                },
                buildInteractionRequestParams: function(t, e, n, i) {
                    var r = "";
                    return t && (r += "c_i=" + f(t)), e && (r && (r += "&"), r += "c_n=" + f(e)), n && (r && (r += "&"), r += "c_p=" + f(n)), i && (r && (r += "&"), r += "c_t=" + f(i)), r
                },
                buildImpressionRequestParams: function(t, e, n) {
                    var i = "c_n=" + f(t) + "&c_p=" + f(e);
                    return n && (i += "&c_t=" + f(n)), i
                },
                buildContentBlock: function(t) {
                    if (t) {
                        var e = this.findContentName(t),
                            n = this.findContentPiece(t),
                            i = this.findContentTarget(t);
                        return e = this.trim(e), n = this.trim(n), i = this.trim(i), {
                            name: e || "Unknown",
                            piece: n || "Unknown",
                            target: i || ""
                        }
                    }
                },
                collectContent: function(t) {
                    if (!t || !t.length) return [];
                    var e, n, i = [];
                    for (e = 0; e < t.length; e++) m(n = this.buildContentBlock(t[e])) && i.push(n);
                    return i
                },
                setLocation: function(t) {
                    this.location = t
                },
                getLocation: function() {
                    var t = this.location || u.location;
                    return t.origin || (t.origin = t.protocol + "//" + t.hostname + (t.port ? ":" + t.port : "")), t
                },
                toAbsoluteUrl: function(t) {
                    if ((!t || String(t) !== t) && "" !== t) return t;
                    if ("" === t) return this.getLocation().href;
                    if (-1 !== t.search(/^\/\//)) return this.getLocation().protocol + t;
                    if (-1 !== t.search(/:\/\//)) return t;
                    if (0 === t.indexOf("#")) return this.getLocation().origin + this.getLocation().pathname + t;
                    if (0 === t.indexOf("?")) return this.getLocation().origin + this.getLocation().pathname + t;
                    if (0 === t.search("^[a-zA-Z]{2,11}:")) return t;
                    if (-1 !== t.search(/^\//)) return this.getLocation().origin + t;
                    return this.getLocation().origin + this.getLocation().pathname.match(new RegExp("(.*/)"))[0] + t
                },
                isUrlToCurrentDomain: function(t) {
                    var e = this.toAbsoluteUrl(t);
                    if (!e) return !1;
                    var n = this.getLocation().origin;
                    return n === e || 0 === String(e).indexOf(n) && ":" !== String(e).substr(n.length, 1)
                },
                setHrefAttribute: function(t, e) {
                    t && e && W.setAnyAttribute(t, "href", e)
                },
                shouldIgnoreInteraction: function(t) {
                    var e = W.hasNodeAttribute(t, this.CONTENT_IGNOREINTERACTION_ATTR),
                        n = W.hasNodeCssClass(t, this.CONTENT_IGNOREINTERACTION_CLASS);
                    return e || n
                }
            };

        function M(t, e) {
            if (e) return e;
            if (t = F.toAbsoluteUrl(t), i = t, r = "?", -1 !== (i = String(i)).indexOf(r)) {
                var n = t.indexOf("?");
                t = t.slice(0, n)
            }
            var i, r;
            if (I(t, "piwik.php")) t = P(t, "piwik.php".length);
            else if (I(t, ".php")) {
                var o = t.lastIndexOf("/");
                t = t.slice(0, o + 1)
            }
            return I(t, "/js/") && (t = P(t, "js/".length)), t
        }

        function H(t) {
            var e = "Piwik_Overlay",
                n = new RegExp("index\\.php\\?module=Overlay&action=startOverlaySession&idSite=([0-9]+)&period=([^&]+)&date=([^&]+)(&segment=.*)?$").exec(o.referrer);
            if (n) {
                if (n[1] !== String(t)) return !1;
                var i = n[2],
                    r = n[3],
                    a = n[4];
                a ? 0 === a.indexOf("&segment=") && (a = a.substr("&segment=".length)) : a = "", u.name = e + "###" + i + "###" + r + "###" + a
            }
            var s = u.name.split("###");
            return 4 === s.length && s[0] === e
        }

        function J(t, e, n) {
            var i, r, a, s = u.name.split("###"),
                c = s[1],
                f = s[2],
                l = s[3],
                h = M(t, e);
            i = h + "plugins/Overlay/client/client.js?v=1", r = function() {
                Piwik_Overlay_Client.initialize(h, n, c, f, l)
            }, (a = o.createElement("script")).type = "text/javascript", a.src = i, a.readyState ? a.onreadystatechange = function() {
                var t = this.readyState;
                "loaded" !== t && "complete" !== t || (a.onreadystatechange = null, r())
            } : a.onload = r, o.getElementsByTagName("head")[0].appendChild(a)
        }

        function G(e, r) {
            var d, w, P, U, q, B, z, K, $, Z, X, Y, Q, tt, et, nt, it, rt, ot, at = this,
                st = "mtm_consent",
                ut = "mtm_consent_removed",
                ct = (it = o.domain, rt = u.location.href, ot = function() {
                    var t = "";
                    try {
                        t = u.top.document.referrer
                    } catch (e) {
                        if (u.parent) try {
                            t = u.parent.document.referrer
                        } catch (e) {
                            t = ""
                        }
                    }
                    return "" === t && (t = o.referrer), t
                }(), it || (it = ""), rt || (rt = ""), "translate.googleusercontent.com" === it ? ("" === ot && (ot = rt), it = E(rt = R(rt, "u"))) : "cc.bingj.com" !== it && "webcache.googleusercontent.com" !== it && "74.6." !== it.slice(0, 5) || (it = E(rt = o.links[0].href)), [it, rt, ot]),
                ft = V(ct[0]),
                lt = v(ct[1]),
                ht = v(ct[2]),
                dt = !1,
                gt = "GET",
                pt = "application/x-www-form-urlencoded; charset=UTF-8",
                vt = pt,
                mt = e || "",
                Tt = "",
                bt = "",
                Ct = r || "",
                Nt = "",
                wt = "",
                kt = "",
                yt = ["7z", "aac", "apk", "arc", "arj", "asf", "asx", "avi", "azw3", "bin", "csv", "deb", "dmg", "doc", "docx", "epub", "exe", "flv", "gif", "gz", "gzip", "hqx", "ibooks", "jar", "jpg", "jpeg", "js", "mobi", "mp2", "mp3", "mp4", "mpg", "mpeg", "mov", "movie", "msi", "msp", "odb", "odf", "odg", "ods", "odt", "ogg", "ogv", "pdf", "phps", "png", "ppt", "pptx", "qt", "qtm", "ra", "ram", "rar", "rpm", "sea", "sit", "tar", "tbz", "tbz2", "bz", "bz2", "tgz", "torrent", "txt", "wav", "wma", "wmv", "wpd", "xls", "xlsx", "xml", "z", "zip"],
                At = [ft],
                Ot = [],
                _t = [],
                Et = [],
                St = 500,
                It = ["pk_campaign", "piwik_campaign", "utm_campaign", "utm_source", "utm_medium"],
                Pt = ["pk_kwd", "piwik_kwd", "utm_term"],
                xt = "_pk_",
                Rt = "pk_vid",
                Lt = 180,
                jt = !1,
                Vt = !1,
                Ut = 339552e5,
                Dt = 18e5,
                qt = 15768e6,
                Wt = !0,
                Ft = 0,
                Mt = !1,
                Ht = !1,
                Jt = {},
                Gt = {},
                Bt = {},
                zt = {},
                Kt = {},
                $t = [],
                Zt = !1,
                Xt = !1,
                Yt = !1,
                Qt = !1,
                te = !1,
                ee = !1,
                ne = function() {
                    var t;
                    try {
                        t = u.frameElement
                    } catch (t) {
                        return !0
                    }
                    if (m(t)) return !(!t || "iframe" !== String(t.nodeName).toLowerCase());
                    try {
                        return u.self !== u.top
                    } catch (t) {
                        return !0
                    }
                }(),
                ie = null,
                re = j,
                oe = 0,
                ae = ["id", "ses", "cvar", "ref"],
                se = null,
                ue = [];
            try {
                kt = o.title
            } catch (t) {
                kt = ""
            }

            function ce(t, e, n, i, r, a) {
                var s;
                Vt || (n && (s = new Date).setTime(s.getTime() + n), o.cookie = t + "=" + f(e) + (n ? ";expires=" + s.toGMTString() : "") + ";path=" + (i || "/") + (r ? ";domain=" + r : "") + (a ? ";secure" : ""))
            }

            function fe(t) {
                if (Vt) return 0;
                var e = new RegExp("(^|;)[ ]*" + t + "=([^;]*)").exec(o.cookie);
                return e ? l(e[2]) : 0
            }

            function le(t) {
                var e;
                return t = x(t, Rt), U ? (e = new RegExp("#.*"), t.replace(e, "")) : t
            }

            function he(t, e) {
                var n;
                if ((t = String(t).toLowerCase()) === (e = String(e).toLowerCase())) return !0;
                if ("." === e.slice(0, 1)) {
                    if (t === e.slice(1)) return !0;
                    if ((n = t.length - e.length) > 0 && t.slice(n) === e) return !0
                }
                return !1
            }

            function de(t) {
                var e = document.createElement("a");
                return 0 !== t.indexOf("//") && 0 !== t.indexOf("http") && (0 === t.indexOf("*") && (t = t.substr(1)), 0 === t.indexOf(".") && (t = t.substr(1)), t = "http://" + t), e.href = F.toAbsoluteUrl(t), e.pathname ? e.pathname : ""
            }

            function ge(t, e) {
                S(e, "/") || (e = "/" + e), S(t, "/") || (t = "/" + t);
                var n = "/" === e || "/*" === e;
                return !!n || (t === e || (e = String(e).toLowerCase(), t = String(t).toLowerCase(), I(e, "*") ? !!(n = !(e = e.slice(0, -1)) || "/" === e) || (t === e || 0 === t.indexOf(e)) : (I(t, "/") || (t += "/"), I(e, "/") || (e += "/"), 0 === t.indexOf(e))))
            }

            function pe(t, e) {
                var n, i, r;
                for (n = 0; n < At.length; n++)
                    if (i = V(At[n]), r = de(At[n]), he(t, i) && ge(e, r)) return !0;
                return !1
            }

            function ve(t) {
                var e, n, i;
                for (e = 0; e < At.length; e++) {
                    if (t === (n = V(At[e].toLowerCase()))) return !0;
                    if ("." === n.slice(0, 1)) {
                        if (t === n.slice(1)) return !0;
                        if ((i = t.length - n.length) > 0 && t.slice(i) === n) return !0
                    }
                }
                return !1
            }

            function me(t, e) {
                t = t.replace("send_image=1", "send_image=0");
                var n = new XMLHttpRequest;
                n.open("GET", mt + (mt.indexOf("?") < 0 ? "?" : "&") + t, !0), n.send()
            }

            function Te(t) {
                if (!("object" == typeof a && "function" == typeof a.sendBeacon && "function" == typeof Blob)) return !1;
                var e = !1;
                try {
                    var n = new Blob([t], {
                        type: "application/x-www-form-urlencoded; charset=UTF-8"
                    });
                    e = a.sendBeacon(mt, n)
                } catch (t) {
                    return !1
                }
                return e
            }

            function be(t, e, n) {
                m(n) && null !== n || (n = !0), p && Te(t) || setTimeout(function() {
                    if (!p || !Te(t)) try {
                        var i = u.XMLHttpRequest ? new u.XMLHttpRequest : u.ActiveXObject ? new ActiveXObject("Microsoft.XMLHTTP") : null;
                        i.open("POST", mt, !0), i.onreadystatechange = function() {
                            4 !== this.readyState || this.status >= 200 && this.status < 300 ? 4 === this.readyState && "function" == typeof e && e() : !(p && Te(t)) && n && me(t)
                        }, i.setRequestHeader("Content-Type", vt), i.send(t)
                    } catch (e) {
                        !(p && Te(t)) && n && me(t)
                    }
                }, 50)
            }

            function Ce(e) {
                var n = (new Date).getTime() + e;
                (!t || n > t) && (t = n)
            }

            function Ne(t) {
                !Y && w && se && (Y = setTimeout(function() {
                    if (Y = null, ne || (ne = !o.hasFocus || o.hasFocus()), ne) {
                        if (!P()) {
                            var t = new Date,
                                e = w - (t.getTime() - ie);
                            Ne(e = Math.min(w, e))
                        }
                    } else Ne(w)
                }, t || w))
            }

            function we() {
                Y && (clearTimeout(Y), Y = null)
            }

            function ke() {
                ne = !0, P() || Ne()
            }

            function ye() {
                we()
            }

            function Ae() {
                !ee && w && (ee = !0, k(u, "focus", ke), k(u, "blur", ye), Ne())
            }

            function Oe(t) {
                var e = (new Date).getTime();
                if (ie = e, Xt && e < Xt) {
                    var n = Xt - e;
                    return setTimeout(t, n), Ce(n + 50), void(Xt += 50)
                }
                if (!1 === Xt) {
                    Xt = e + 800
                }
                t()
            }

            function _e(t, e, n) {
                se ? (!K && t && Oe(function() {
                    "POST" === gt || String(t).length > 2e3 ? be(t, n) : me(t), Ce(e)
                }), ee ? Ne() : Ae()) : ue.push(t)
            }

            function Ee(t, e) {
                var n;
                if (n = t, !K && n && n.length)
                    if (se) {
                        var i = '{"requests":["?' + t.join('","?') + '"]}';
                        Oe(function() {
                            be(i, null, !1), Ce(e)
                        })
                    } else ue.push(t)
            }

            function Se(t) {
                return xt + t + "." + Ct + "." + et
            }

            function Ie() {
                if (Vt) return "0";
                if (!m(a.cookieEnabled)) {
                    var t = Se("testcookie");
                    return ce(t, "1"), "1" === fe(t) ? "1" : "0"
                }
                return a.cookieEnabled ? "1" : "0"
            }

            function Pe() {
                et = re((B || ft) + (z || "/")).slice(0, 4)
            }

            function xe() {
                var t = fe(Se("cvar"));
                return t.length && b(t = JSON_PIWIK.parse(t)) ? t : {}
            }

            function Re() {
                !1 === Ht && (Ht = xe())
            }

            function Le() {
                return re((a.userAgent || "") + (a.platform || "") + JSON_PIWIK.stringify(Kt)).slice(0, 6)
            }

            function je() {
                return Math.floor((new Date).getTime() / 1e3)
            }

            function Ve(t) {
                if (!te) return "";
                var e = R(t, Rt);
                if (!e) return "";
                e = String(e);
                var n = new RegExp("^[a-zA-Z0-9]+$");
                if (32 === e.length && n.test(e) && function(t) {
                        t = String(t);
                        var e = Le(),
                            n = e.length,
                            i = t.substr(-1 * n, n),
                            r = parseInt(t.substr(0, t.length - n), 10);
                        if (r && i && i === e) {
                            var o = je();
                            if (Lt <= 0) return !0;
                            if (o >= r && o <= r + Lt) return !0
                        }
                        return !1
                    }(e.substr(16, 32))) return e.substr(0, 16);
                return ""
            }

            function Ue() {
                wt || (wt = Ve(lt));
                var t, e = new Date,
                    n = Math.round(e.getTime() / 1e3),
                    i = fe(Se("id"));
                return i ? ((t = i.split(".")).unshift("0"), wt.length && (t[1] = wt), t) : t = ["1", wt.length ? wt : "0" === Ie() ? "" : re((a.userAgent || "") + (a.platform || "") + JSON_PIWIK.stringify(Kt) + (new Date).getTime() + Math.random()).slice(0, 16), n, 0, n, "", ""]
            }

            function De() {
                var t = Ue(),
                    e = t[0],
                    n = t[1],
                    i = t[2],
                    r = t[3],
                    o = t[4],
                    a = t[5];
                return m(t[6]) || (t[6] = ""), {
                    newVisitor: e,
                    uuid: n,
                    createTs: i,
                    visitCount: r,
                    currentVisitTs: o,
                    lastVisitTs: a,
                    lastEcommerceOrderTs: t[6]
                }
            }

            function qe(t) {
                if (Ct) {
                    var e = new Date,
                        n = Math.round(e.getTime() / 1e3);
                    m(t) || (t = De());
                    var i, r, o = t.uuid + "." + t.createTs + "." + t.visitCount + "." + n + "." + t.lastVisitTs + "." + t.lastEcommerceOrderTs;
                    ce(Se("id"), o, (i = (new Date).getTime(), r = De().createTs, 1e3 * parseInt(r, 10) + Ut - i), z, B, jt)
                }
            }

            function We() {
                var t = fe(Se("ref"));
                if (t.length) try {
                    if (b(t = JSON_PIWIK.parse(t))) return t
                } catch (t) {}
                return ["", "", 0, ""]
            }

            function Fe(t, e, n) {
                ce(t, "", -86400, e, n)
            }

            function Me() {
                var t, e, n = Vt;
                for (Vt = !1, t = 0; t < ae.length; t++)(e = Se(ae[t])) !== ut && e !== st && 0 !== fe(e) && Fe(e, z, B);
                Vt = n
            }

            function He(t) {
                if (t && b(t)) {
                    var e, n = [];
                    for (e in t) Object.prototype.hasOwnProperty.call(t, e) && n.push(e);
                    var i = {};
                    n.sort();
                    var r, o = n.length;
                    for (r = 0; r < o; r++) i[n[r]] = t[n[r]];
                    return i
                }
            }

            function Je(t, e, n, i) {
                var r, a, s, u, l, h, g, p = new Date,
                    v = Math.round(p.getTime() / 1e3),
                    b = Ht,
                    C = Se("ses"),
                    N = Se("ref"),
                    w = Se("cvar"),
                    k = fe(C),
                    y = We(),
                    A = d || lt;
                if (Vt && Me(), K) return "";
                var _ = De();
                m(i) || (i = "");
                var S = o.characterSet || o.charset;
                if (S && "utf-8" !== S.toLowerCase() || (S = null), h = y[0], g = y[1], a = y[2], s = y[3], !k) {
                    var I = Dt / 1e3;
                    if ((!_.lastVisitTs || v - _.lastVisitTs > I) && (_.visitCount++, _.lastVisitTs = _.currentVisitTs), !Z || !h.length) {
                        for (r in It)
                            if (Object.prototype.hasOwnProperty.call(It, r) && (h = R(A, It[r])).length) break;
                        for (r in Pt)
                            if (Object.prototype.hasOwnProperty.call(Pt, r) && (g = R(A, Pt[r])).length) break
                    }
                    u = E(ht), l = s.length ? E(s) : "", !u.length || ve(u) || Z && l.length && !ve(l) || (s = ht), (s.length || h.length) && (y = [h, g, a = v, le(s.slice(0, 1024))], ce(N, JSON_PIWIK.stringify(y), qt, z, B))
                }
                t += "&idsite=" + Ct + "&rec=1&r=" + String(Math.random()).slice(2, 8) + "&h=" + p.getHours() + "&m=" + p.getMinutes() + "&s=" + p.getSeconds() + "&url=" + f(le(A)) + (ht.length ? "&urlref=" + f(le(ht)) : "") + (Nt && Nt.length ? "&uid=" + f(Nt) : "") + "&_id=" + _.uuid + "&_idts=" + _.createTs + "&_idvc=" + _.visitCount + "&_idn=" + _.newVisitor + (h.length ? "&_rcn=" + f(h) : "") + (g.length ? "&_rck=" + f(g) : "") + "&_refts=" + a + "&_viewts=" + _.lastVisitTs + (String(_.lastEcommerceOrderTs).length ? "&_ects=" + _.lastEcommerceOrderTs : "") + (String(s).length ? "&_ref=" + f(le(s.slice(0, 1024))) : "") + (S ? "&cs=" + f(S) : "") + "&send_image=0";
                for (r in Kt) Object.prototype.hasOwnProperty.call(Kt, r) && (t += "&" + r + "=" + Kt[r]);
                var P = [];
                if (e)
                    for (r in e)
                        if (Object.prototype.hasOwnProperty.call(e, r) && /^dimension\d+$/.test(r)) {
                            var x = r.replace("dimension", "");
                            P.push(parseInt(x, 10)), P.push(String(x)), t += "&" + r + "=" + e[r], delete e[r]
                        } e && function(t) {
                    if (!t) return !0;
                    var e, n = !0;
                    for (e in t) Object.prototype.hasOwnProperty.call(t, e) && (n = !1);
                    return n
                }(e) && (e = null);
                for (r in Bt) {
                    if (Object.prototype.hasOwnProperty.call(Bt, r)) - 1 === D(P, r) && (t += "&dimension" + r + "=" + Bt[r])
                }

                function L(t, e) {
                    var n = JSON_PIWIK.stringify(t);
                    return n.length > 2 ? "&" + e + "=" + f(n) : ""
                }
                e ? t += "&data=" + f(JSON_PIWIK.stringify(e)) : q && (t += "&data=" + f(JSON_PIWIK.stringify(q)));
                var j = He(Jt),
                    V = He(Gt);
                if (t += L(j, "cvar"), t += L(V, "e_cvar"), Ht) {
                    t += L(Ht, "_cvar");
                    for (r in b) Object.prototype.hasOwnProperty.call(b, r) && ("" !== Ht[r][0] && "" !== Ht[r][1] || delete Ht[r]);
                    Mt && ce(w, JSON_PIWIK.stringify(Ht), Dt, z, B)
                }
                return Wt && (Ft ? t += "&gt_ms=" + Ft : c && c.timing && c.timing.requestStart && c.timing.responseEnd && (t += "&gt_ms=" + (c.timing.responseEnd - c.timing.requestStart))), nt && (t += "&pv_id=" + nt), _.lastEcommerceOrderTs = m(i) && String(i).length ? i : _.lastEcommerceOrderTs, qe(_), ce(Se("ses"), "*", Dt, z, B, jt), t += O(n, {
                    tracker: at,
                    request: t
                }), bt.length && (t += "&" + bt), T(X) && (t = X(t)), t
            }

            function Ge(t, e, n, i, r, o) {
                var a, s, u = "idgoal=0",
                    c = new Date,
                    l = [],
                    h = String(t).length;
                if (h && (u += "&ec_id=" + f(t), a = Math.round(c.getTime() / 1e3)), u += "&revenue=" + e, String(n).length && (u += "&ec_st=" + n), String(i).length && (u += "&ec_tx=" + i), String(r).length && (u += "&ec_sh=" + r), String(o).length && (u += "&ec_dt=" + o), zt) {
                    for (s in zt) Object.prototype.hasOwnProperty.call(zt, s) && (m(zt[s][1]) || (zt[s][1] = ""), m(zt[s][2]) || (zt[s][2] = ""), m(zt[s][3]) && 0 !== String(zt[s][3]).length || (zt[s][3] = 0), m(zt[s][4]) && 0 !== String(zt[s][4]).length || (zt[s][4] = 1), l.push(zt[s]));
                    u += "&ec_items=" + f(JSON_PIWIK.stringify(l))
                }
                _e(u = Je(u, q, "ecommerce", a), St), h && (zt = {})
            }

            function Be(t, e, n) {
                nt = function() {
                    var t, e = "",
                        n = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ",
                        i = n.length;
                    for (t = 0; t < 6; t++) e += n.charAt(Math.floor(Math.random() * i));
                    return e
                }(), _e(Je("action_name=" + f(function(t) {
                    if (!C(t = t && t.text ? t.text : t)) {
                        var e = o.getElementsByTagName("title");
                        e && m(e[0]) && (t = e[0].text)
                    }
                    return t
                }(t || kt)), e, "log"), St, n)
            }

            function ze(t, e) {
                var n, i = "(^| )(piwik[_-]" + e;
                if (t)
                    for (n = 0; n < t.length; n++) i += "|" + t[n];
                return i += ")( |$)", new RegExp(i)
            }

            function Ke(t) {
                return mt && t && 0 === String(t).indexOf(mt)
            }

            function $e(t) {
                var e;
                for (e = t.parentNode; null !== e && m(e) && !W.isLinkElement(t);) e = (t = e).parentNode;
                return t
            }

            function Ze(t) {
                if ((t = $e(t), W.hasNodeAttribute(t, "href")) && (m(t.href) && !Ke(W.getAttributeValueFromNode(t, "href")))) {
                    var e = t.pathname || de(t.href),
                        n = t.hostname || E(t.href),
                        i = n.toLowerCase(),
                        r = t.href.replace(n, i);
                    if (!new RegExp("^(javascript|vbscript|jscript|mocha|livescript|ecmascript|mailto|tel):", "i").test(r)) {
                        var o = function(t, e, n, i) {
                            if (Ke(e)) return 0;
                            var r = ze(_t, "download"),
                                o = ze(Et, "link"),
                                a = new RegExp("\\.(" + yt.join("|") + ")([?&#]|$)", "i");
                            return o.test(t) ? "link" : i || r.test(t) || a.test(e) ? "download" : n ? 0 : "link"
                        }(t.className, r, pe(i, e), W.hasNodeAttribute(t, "download"));
                        if (o) return {
                            type: o,
                            href: r
                        }
                    }
                }
            }

            function Xe(t, e, n, i) {
                var r = F.buildInteractionRequestParams(t, e, n, i);
                if (r) return Je(r, null, "contentInteraction")
            }

            function Ye(t, e) {
                if (!t || !e) return !1;
                var n, i, r = F.findTargetNode(t);
                return !F.shouldIgnoreInteraction(r) && !((r = F.findTargetNodeNoDefault(t)) && (n = r, i = e, !(n && i && (n.contains ? n.contains(i) : n === i || n.compareDocumentPosition && 16 & n.compareDocumentPosition(i)))))
            }

            function Qe(t) {
                if (!$t || !$t.length) return !1;
                var e, n;
                for (e = 0; e < $t.length; e++)
                    if ((n = $t[e]) && n.name === t.name && n.piece === t.piece && n.target === t.target) return !0;
                return !1
            }

            function tn(t) {
                if (!t) return !1;
                var e = F.findTargetNode(t);
                if (!e || F.shouldIgnoreInteraction(e)) return !1;
                var n = Ze(e);
                if (Qt && n && n.type) return !1;
                if (W.isLinkElement(e) && W.hasNodeAttributeWithValue(e, "href")) {
                    var i = String(W.getAttributeValueFromNode(e, "href"));
                    if (0 === i.indexOf("#")) return !1;
                    if (Ke(i)) return !0;
                    if (!F.isUrlToCurrentDomain(i)) return !1;
                    var r = F.buildContentBlock(t);
                    if (!r) return;
                    var o = r.name,
                        a = r.piece,
                        s = r.target;
                    W.hasNodeAttributeWithValue(e, F.CONTENT_TARGET_ATTR) && !e.wasContentTargetAttrReplaced || (e.wasContentTargetAttrReplaced = !0, s = F.toAbsoluteUrl(i), W.setAnyAttribute(e, F.CONTENT_TARGET_ATTR, s));
                    var u = function(t, e, n, i, r) {
                        if (m(t)) {
                            if (Ke(t)) return t;
                            var o = F.toAbsoluteUrl(t),
                                a = "redirecturl=" + f(o) + "&";
                            a += Xe(e, n, i, r || t);
                            var s = "&";
                            return mt.indexOf("?") < 0 && (s = "?"), mt + s + a
                        }
                    }(i, "click", o, a, s);
                    return F.setHrefAttribute(e, u), !0
                }
                return !1
            }

            function en(t) {
                return function(e) {
                    if (t) {
                        var n, i = F.findParentContentNode(t);
                        if (e && (n = e.target || e.srcElement), n || (n = t), Ye(i, n)) {
                            if (Ce(St), W.isLinkElement(t) && W.hasNodeAttributeWithValue(t, "href") && W.hasNodeAttributeWithValue(t, F.CONTENT_TARGET_ATTR)) !Ke(W.getAttributeValueFromNode(t, "href")) && t.wasContentTargetAttrReplaced && W.setAnyAttribute(t, F.CONTENT_TARGET_ATTR, "");
                            var r = Ze(t);
                            if (Yt && r && r.type) return r.type;
                            if (tn(i)) return "href";
                            var o = F.buildContentBlock(i);
                            if (o) {
                                var a = Xe("click", o.name, o.piece, o.target);
                                return _e(a, St), a
                            }
                        }
                    }
                }
            }

            function nn(t, e) {
                if (!t || !t.length) return [];
                var n, i;
                for (n = 0; n < t.length; n++) Qe(t[n]) ? (t.splice(n, 1), n--) : $t.push(t[n]);
                if (!t || !t.length) return [];
                ! function(t) {
                    var e;
                    if (t && t.length)
                        for (e = 0; e < t.length; e++) tn(t[e])
                }(e),
                function(t) {
                    var e, n;
                    if (t && t.length)
                        for (e = 0; e < t.length; e++)(n = F.findTargetNode(t[e])) && !n.contentInteractionTrackingSetupDone && (n.contentInteractionTrackingSetupDone = !0, k(n, "click", en(n)))
                }(e);
                var r = [];
                for (n = 0; n < t.length; n++)(i = Je(F.buildImpressionRequestParams(t[n].name, t[n].piece, t[n].target), void 0, "contentImpressions")) && r.push(i);
                return r
            }

            function rn(t) {
                return nn(F.collectContent(t), t)
            }

            function on(t) {
                if (!t || !t.length) return [];
                var e;
                for (e = 0; e < t.length; e++) F.isNodeVisible(t[e]) || (t.splice(e, 1), e--);
                return t && t.length ? rn(t) : []
            }

            function an(t, e, n, i, r, o) {
                if (0 === L(String(t)).length || 0 === L(String(e)).length) return N("Error while logging event: Parameters `category` and `action` must not be empty or filled with whitespaces"), !1;
                var a, s, u;
                _e(Je((a = e, s = n, u = i, "e_c=" + f(t) + "&e_a=" + f(a) + (m(s) ? "&e_n=" + f(s) : "") + (m(u) ? "&e_v=" + f(u) : "")), r, "event"), St, o)
            }

            function sn(t, e, n, i, r) {
                var o = e + "=" + f(le(t)),
                    a = function(t, e, n) {
                        if (t) {
                            var i = F.findParentContentNode(t);
                            if (i && Ye(i, t)) {
                                var r = F.buildContentBlock(i);
                                if (r) return !r.target && n && (r.target = n), F.buildInteractionRequestParams(e, r.name, r.piece, r.target)
                            }
                        }
                    }(r, "click", t);
                a && (o += "&" + a), _e(Je(o, n, "link"), St, i)
            }

            function un(t, e) {
                return "" !== t ? t + e.charAt(0).toUpperCase() + e.slice(1) : e
            }

            function cn(t) {
                var e, n, i, r = ["", "webkit", "ms", "moz"];
                if (!$)
                    for (n = 0; n < r.length; n++)
                        if (i = r[n], Object.prototype.hasOwnProperty.call(o, un(i, "hidden"))) {
                            "prerender" === o[un(i, "visibilityState")] && (e = !0);
                            break
                        } e ? k(o, i + "visibilitychange", function e() {
                    o.removeEventListener(i + "visibilitychange", e, !1), t()
                }) : t()
            }

            function fn() {
                var t, e;
                return De().uuid + (t = je(), e = Le(), String(t) + e)
            }

            function ln(t) {
                if (t && W.hasNodeAttribute(t, "href")) {
                    var e = W.getAttributeValueFromNode(t, "href");
                    if (e && !Ke(e)) {
                        (e = x(e, Rt)).indexOf("?") > 0 ? e += "&" : e += "?";
                        var n = fn();
                        e = function(t, e, n) {
                            t = String(t), n || (n = "");
                            var i = t.indexOf("#"),
                                r = t.length; - 1 === i && (i = r);
                            var o = t.substr(0, i),
                                a = t.substr(i, r - i);
                            return -1 === o.indexOf("?") ? o += "?" : I(o, "?") || (o += "&"), o + f(e) + "=" + f(n) + a
                        }(e, Rt, n), W.setAnyAttribute(t, "href", e)
                    }
                }
            }

            function hn(t) {
                var e = Ze(t);
                if (e && e.type) return e.href = v(e.href), void sn(e.href, e.type, void 0, null, t);
                te && function(t) {
                    var e = W.getAttributeValueFromNode(t, "href");
                    if (!e) return !1;
                    if (0 !== (e = String(e)).indexOf("//") && 0 !== e.indexOf("http://") && 0 !== e.indexOf("https://")) return !1;
                    var n = t.pathname || de(t.href),
                        i = (t.hostname || E(t.href)).toLowerCase();
                    return !!pe(i, n) && !he(ft, V(i))
                }(t = $e(t)) && ln(t)
            }

            function dn(t) {
                var e = t.which,
                    n = typeof t.button;
                return e || "undefined" === n || (o.all && !o.addEventListener ? 1 & t.button ? e = 1 : 2 & t.button ? e = 3 : 4 & t.button && (e = 2) : 0 === t.button || "0" === t.button ? e = 1 : 1 & t.button ? e = 2 : 2 & t.button && (e = 3)), e
            }

            function gn(t) {
                return function(e) {
                    var n, i = function(t) {
                            switch (dn(t)) {
                                case 1:
                                    return "left";
                                case 2:
                                    return "middle";
                                case 3:
                                    return "right"
                            }
                        }(e = e || u.event),
                        r = (n = e).target || n.srcElement;
                    if ("click" === e.type) {
                        var o = !1;
                        t && "middle" === i && (o = !0), r && !o && hn(r)
                    } else "mousedown" === e.type ? "middle" === i && r ? (Q = i, tt = r) : Q = tt = null : "mouseup" === e.type ? (i === Q && r === tt && hn(r), Q = tt = null) : "contextmenu" === e.type && hn(r)
                }
            }

            function pn(t, e) {
                "undefined" === typeof e && (e = !0), k(t, "click", gn(e), !1), e && (k(t, "mouseup", gn(e), !1), k(t, "mousedown", gn(e), !1), k(t, "contextmenu", gn(e), !1))
            }
            se = !fe(ut), P = function() {
                    var t = new Date;
                    return ie + w <= t.getTime() && (_e(Je("ping=1", null, "ping"), St), !0)
                },
                function() {
                    var t, e, n = {
                        pdf: "application/pdf",
                        qt: "video/quicktime",
                        realp: "audio/x-pn-realaudio-plugin",
                        wma: "application/x-mplayer2",
                        dir: "application/x-director",
                        fla: "application/x-shockwave-flash",
                        java: "application/x-java-vm",
                        gears: "application/x-googlegears",
                        ag: "application/x-silverlight"
                    };
                    if (!new RegExp("MSIE").test(a.userAgent)) {
                        if (a.mimeTypes && a.mimeTypes.length)
                            for (t in n) Object.prototype.hasOwnProperty.call(n, t) && (e = a.mimeTypes[n[t]], Kt[t] = e && e.enabledPlugin ? "1" : "0");
                        !new RegExp("Edge[ /](\\d+[\\.\\d]+)").test(a.userAgent) && "unknown" != typeof navigator.javaEnabled && m(a.javaEnabled) && a.javaEnabled() && (Kt.java = "1"), T(u.GearsFactory) && (Kt.gears = "1"), Kt.cookie = Ie()
                    }
                    var i = parseInt(s.width, 10),
                        r = parseInt(s.height, 10);
                    Kt.res = parseInt(i, 10) + "x" + parseInt(r, 10)
                }(), Pe(), qe(), this.getVisitorId = function() {
                    return De().uuid
                }, this.getVisitorInfo = function() {
                    return Ue()
                }, this.getAttributionInfo = function() {
                    return We()
                }, this.getAttributionCampaignName = function() {
                    return We()[0]
                }, this.getAttributionCampaignKeyword = function() {
                    return We()[1]
                }, this.getAttributionReferrerTimestamp = function() {
                    return We()[2]
                }, this.getAttributionReferrerUrl = function() {
                    return We()[3]
                }, this.setTrackerUrl = function(t) {
                    mt = t
                }, this.getTrackerUrl = function() {
                    return mt
                }, this.getPiwikUrl = function() {
                    return M(this.getTrackerUrl(), Tt)
                }, this.addTracker = function(t, e) {
                    if (!e) throw new Error("A siteId must be given to add a new tracker");
                    m(t) && null !== t || (t = this.getTrackerUrl());
                    var n = new G(t, e);
                    return h.push(n), n
                }, this.getSiteId = function() {
                    return Ct
                }, this.setSiteId = function(t) {
                    Ct = t, qe()
                }, this.resetUserId = function() {
                    Nt = ""
                }, this.setUserId = function(t) {
                    m(t) && t.length && (Nt = t)
                }, this.getUserId = function() {
                    return Nt
                }, this.setCustomData = function(t, e) {
                    b(t) ? q = t : (q || (q = {}), q[t] = e)
                }, this.getCustomData = function() {
                    return q
                }, this.setCustomRequestProcessing = function(t) {
                    X = t
                }, this.appendToTrackingUrl = function(t) {
                    bt = t
                }, this.getRequest = function(t) {
                    return Je(t)
                }, this.addPlugin = function(t, e) {
                    i[t] = e
                }, this.setCustomDimension = function(t, e) {
                    (t = parseInt(t, 10)) > 0 && (m(e) || (e = ""), C(e) || (e = String(e)), Bt[t] = e)
                }, this.getCustomDimension = function(t) {
                    if ((t = parseInt(t, 10)) > 0 && Object.prototype.hasOwnProperty.call(Bt, t)) return Bt[t]
                }, this.deleteCustomDimension = function(t) {
                    (t = parseInt(t, 10)) > 0 && delete Bt[t]
                }, this.setCustomVariable = function(t, e, n, i) {
                    var r;
                    m(i) || (i = "visit"), m(e) && (m(n) || (n = ""), t > 0 && (e = C(e) ? e : String(e), n = C(n) ? n : String(n), r = [e.slice(0, 200), n.slice(0, 200)], "visit" === i || 2 === i ? (Re(), Ht[t] = r) : "page" === i || 3 === i ? Jt[t] = r : "event" === i && (Gt[t] = r)))
                }, this.getCustomVariable = function(t, e) {
                    var n;
                    return m(e) || (e = "visit"), "page" === e || 3 === e ? n = Jt[t] : "event" === e ? n = Gt[t] : "visit" !== e && 2 !== e || (Re(), n = Ht[t]), !(!m(n) || n && "" === n[0]) && n
                }, this.deleteCustomVariable = function(t, e) {
                    this.getCustomVariable(t, e) && this.setCustomVariable(t, "", "", e)
                }, this.deleteCustomVariables = function(t) {
                    "page" === t || 3 === t ? Jt = {} : "event" === t ? Gt = {} : "visit" !== t && 2 !== t || (Ht = {})
                }, this.storeCustomVariablesInCookie = function() {
                    Mt = !0
                }, this.setLinkTrackingTimer = function(t) {
                    St = t
                }, this.getLinkTrackingTimer = function() {
                    return St
                }, this.setDownloadExtensions = function(t) {
                    C(t) && (t = t.split("|")), yt = t
                }, this.addDownloadExtensions = function(t) {
                    var e;
                    for (C(t) && (t = t.split("|")), e = 0; e < t.length; e++) yt.push(t[e])
                }, this.removeDownloadExtensions = function(t) {
                    var e, n = [];
                    for (C(t) && (t = t.split("|")), e = 0; e < yt.length; e++) - 1 === D(t, yt[e]) && n.push(yt[e]);
                    yt = n
                }, this.setDomains = function(t) {
                    At = C(t) ? [t] : t;
                    for (var e, n = !1, i = 0; i < At.length; i++) {
                        if (e = String(At[i]), he(ft, V(e))) {
                            n = !0;
                            break
                        }
                        var r = de(e);
                        if (r && "/" !== r && "/*" !== r) {
                            n = !0;
                            break
                        }
                    }
                    n || At.push(ft)
                }, this.enableCrossDomainLinking = function() {
                    te = !0
                }, this.disableCrossDomainLinking = function() {
                    te = !1
                }, this.isCrossDomainLinkingEnabled = function() {
                    return te
                }, this.setCrossDomainLinkingTimeout = function(t) {
                    Lt = t
                }, this.getCrossDomainLinkingUrlParameter = function() {
                    return f(Rt) + "=" + f(fn())
                }, this.setIgnoreClasses = function(t) {
                    Ot = C(t) ? [t] : t
                }, this.setRequestMethod = function(t) {
                    gt = t || "GET"
                }, this.setRequestContentType = function(t) {
                    vt = t || pt
                }, this.setReferrerUrl = function(t) {
                    ht = t
                }, this.setCustomUrl = function(t) {
                    var e, n, i;
                    e = lt, d = _(n = t) ? n : "/" === n.slice(0, 1) ? _(e) + "://" + E(e) + n : ((i = (e = le(e)).indexOf("?")) >= 0 && (e = e.slice(0, i)), (i = e.lastIndexOf("/")) !== e.length - 1 && (e = e.slice(0, i + 1)), e + n)
                }, this.getCurrentUrl = function() {
                    return d || lt
                }, this.setDocumentTitle = function(t) {
                    kt = t
                }, this.setAPIUrl = function(t) {
                    Tt = t
                }, this.setDownloadClasses = function(t) {
                    _t = C(t) ? [t] : t
                }, this.setLinkClasses = function(t) {
                    Et = C(t) ? [t] : t
                }, this.setCampaignNameKey = function(t) {
                    It = C(t) ? [t] : t
                }, this.setCampaignKeywordKey = function(t) {
                    Pt = C(t) ? [t] : t
                }, this.discardHashTag = function(t) {
                    U = t
                }, this.setCookieNamePrefix = function(t) {
                    xt = t, Ht = xe()
                }, this.setCookieDomain = function(t) {
                    var e, n, i = V(t);
                    ce("test", n = "testvalue", 1e4, null, e = i), fe("test") === n && (Fe("test", null, e), 1) && (B = i, Pe())
                }, this.getCookieDomain = function() {
                    return B
                }, this.hasCookies = function() {
                    return "1" === Ie()
                }, this.setSessionCookie = function(t, e, n) {
                    if (!t) throw new Error("Missing cookie name");
                    m(n) || (n = Dt), ae.push(t), ce(Se(t), e, n, z, B)
                }, this.getCookie = function(t) {
                    var e = fe(Se(t));
                    return 0 === e ? null : e
                }, this.setCookiePath = function(t) {
                    z = t, Pe()
                }, this.getCookiePath = function(t) {
                    return z
                }, this.setVisitorCookieTimeout = function(t) {
                    Ut = 1e3 * t
                }, this.setSessionCookieTimeout = function(t) {
                    Dt = 1e3 * t
                }, this.getSessionCookieTimeout = function() {
                    return Dt
                }, this.setReferralCookieTimeout = function(t) {
                    qt = 1e3 * t
                }, this.setConversionAttributionFirstReferrer = function(t) {
                    Z = t
                }, this.setSecureCookie = function(t) {
                    jt = t
                }, this.disableCookies = function() {
                    Vt = !0, Kt.cookie = "0", Ct && Me()
                }, this.deleteCookies = function() {
                    Me()
                }, this.setDoNotTrack = function(t) {
                    var e = a.doNotTrack || a.msDoNotTrack;
                    (K = t && ("yes" === e || "1" === e)) && this.disableCookies()
                }, this.addListener = function(t, e) {
                    pn(t, e)
                }, this.enableLinkTracking = function(t) {
                    Qt = !0;
                    var e = this;
                    cn(function() {
                        A(function() {
                            ! function(t, e) {
                                Yt = !0;
                                var n, i = ze(Ot, "ignore"),
                                    r = o.links,
                                    a = null;
                                if (r)
                                    for (n = 0; n < r.length; n++) a = r[n], i.test(a.className) || (void 0 === a.piwikTrackers && (a.piwikTrackers = []), -1 === D(a.piwikTrackers, e) && (a.piwikTrackers.push(e), pn(a, t)))
                            }(t, e)
                        })
                    })
                }, this.enableJSErrorTracking = function() {
                    if (!dt) {
                        dt = !0;
                        var t = u.onerror;
                        u.onerror = function(e, n, i, r, o) {
                            return cn(function() {
                                var t = n + ":" + i;
                                r && (t += ":" + r), an("JavaScript Errors", t, e)
                            }), !!t && t(e, n, i, r, o)
                        }
                    }
                }, this.disablePerformanceTracking = function() {
                    Wt = !1
                }, this.setGenerationTimeMs = function(t) {
                    Ft = parseInt(t, 10)
                }, this.enableHeartBeatTimer = function(t) {
                    t = Math.max(t, 1), w = 1e3 * (t || 15), null !== ie && Ae()
                }, this.disableHeartBeatTimer = function() {
                    we(), (w || ee) && (u.removeEventListener ? (u.removeEventListener("focus", ke, !0), u.removeEventListener("blur", ye, !0)) : u.detachEvent && (u.detachEvent("onfocus", ke), u.detachEvent("onblur", ye))), w = null, ee = !1
                }, this.killFrame = function() {
                    u.location !== u.top.location && (u.top.location = u.location)
                }, this.redirectFile = function(t) {
                    "file:" === u.location.protocol && (u.location = t)
                }, this.setCountPreRendered = function(t) {
                    $ = t
                }, this.trackGoal = function(t, e, n) {
                    cn(function() {
                        var i;
                        _e(Je("idgoal=" + t + ((i = e) ? "&revenue=" + i : ""), n, "goal"), St)
                    })
                }, this.trackLink = function(t, e, n, i) {
                    cn(function() {
                        sn(t, e, n, i)
                    })
                }, this.getNumTrackedPageViews = function() {
                    return oe
                }, this.trackPageView = function(t, e, n) {
                    $t = [], ue = [], H(Ct) ? cn(function() {
                        J(mt, Tt, Ct)
                    }) : cn(function() {
                        oe++, Be(t, e, n)
                    })
                }, this.trackAllContentImpressions = function() {
                    H(Ct) || cn(function() {
                        A(function() {
                            Ee(rn(F.findContentNodes()), St)
                        })
                    })
                }, this.trackVisibleContentImpressions = function(t, e) {
                    H(Ct) || (m(t) || (t = !0), m(e) || (e = 750), function(t, e, n) {
                        if (Zt) return !0;
                        Zt = !0;
                        var i, r, a = !1;

                        function s() {
                            a = !0
                        }
                        y(function() {
                            if (t) {
                                for (i = ["scroll", "resize"], r = 0; r < i.length; r++) o.addEventListener ? o.addEventListener(i[r], s) : u.attachEvent("on" + i[r], s);
                                ! function t(e) {
                                    setTimeout(function() {
                                        Zt && (a && (a = !1, n.trackVisibleContentImpressions()), t(e))
                                    }, e)
                                }(100)
                            }
                            e && e > 0 && function t(e) {
                                setTimeout(function() {
                                    Zt && (a = !1, n.trackVisibleContentImpressions(), t(e))
                                }, e)
                            }(e = parseInt(e, 10))
                        })
                    }(t, e, this), cn(function() {
                        y(function() {
                            Ee(on(F.findContentNodes()), St)
                        })
                    }))
                }, this.trackContentImpression = function(t, e, n) {
                    H(Ct) || (t = L(t), e = L(e), n = L(n), t && (e = e || "Unknown", cn(function() {
                        var i, r, o;
                        _e((i = t, r = e, o = n, Je(F.buildImpressionRequestParams(i, r, o), null, "contentImpression")), St)
                    })))
                }, this.trackContentImpressionsWithinNode = function(t) {
                    !H(Ct) && t && cn(function() {
                        Zt ? y(function() {
                            Ee(on(F.findContentNodesWithinNode(t)), St)
                        }) : A(function() {
                            Ee(rn(F.findContentNodesWithinNode(t)), St)
                        })
                    })
                }, this.trackContentInteraction = function(t, e, n, i) {
                    H(Ct) || (t = L(t), e = L(e), n = L(n), i = L(i), t && e && (n = n || "Unknown", cn(function() {
                        _e(Xe(t, e, n, i), St)
                    })))
                }, this.trackContentInteractionNode = function(t, e) {
                    !H(Ct) && t && cn(function() {
                        _e(function(t, e) {
                            if (t) {
                                var n = F.findParentContentNode(t),
                                    i = F.buildContentBlock(n);
                                if (i) return e || (e = "Unknown"), Xe(e, i.name, i.piece, i.target)
                            }
                        }(t, e), St)
                    })
                }, this.logAllContentBlocksOnPage = function() {
                    var t = F.findContentNodes(),
                        e = F.collectContent(t);
                    "undefined" !== typeof console && console && console.log && console.log(e)
                }, this.trackEvent = function(t, e, n, i, r, o) {
                    cn(function() {
                        an(t, e, n, i, r, o)
                    })
                }, this.trackSiteSearch = function(t, e, n, i) {
                    cn(function() {
                        var r, o, a;
                        r = e, o = n, a = i, _e(Je("search=" + f(t) + (r ? "&search_cat=" + f(r) : "") + (m(o) ? "&search_count=" + o : ""), a, "sitesearch"), St)
                    })
                }, this.setEcommerceView = function(t, e, n, i) {
                    m(n) && n.length ? n instanceof Array && (n = JSON_PIWIK.stringify(n)) : n = "", Jt[5] = ["_pkc", n], m(i) && String(i).length && (Jt[2] = ["_pkp", i]), (m(t) && t.length || m(e) && e.length) && (m(t) && t.length && (Jt[3] = ["_pks", t]), m(e) && e.length || (e = ""), Jt[4] = ["_pkn", e])
                }, this.addEcommerceItem = function(t, e, n, i, r) {
                    t.length && (zt[t] = [t, e, n, i, r])
                }, this.trackEcommerceOrder = function(t, e, n, i, r, o) {
                    var a, s, u, c, f, l;
                    a = t, s = e, u = n, c = i, f = r, l = o, String(a).length && m(s) && Ge(a, s, u, c, f, l)
                }, this.trackEcommerceCartUpdate = function(t) {
                    var e;
                    m(e = t) && Ge("", e, "", "", "", "")
                }, this.trackRequest = function(t, e, n, i) {
                    cn(function() {
                        _e(Je(t, e, i), St, n)
                    })
                }, this.getRememberedConsent = function() {
                    var t = fe(st);
                    return fe(ut) ? (t && Fe(st, z, B), null) : t && 0 !== t ? t : null
                }, this.hasRememberedConsent = function() {
                    return !!this.getRememberedConsent()
                }, this.requireConsent = function() {
                    se = this.hasRememberedConsent(), i["CoreConsent" + ++g] = {
                        unload: function() {
                            se || Me()
                        }
                    }
                }, this.setConsentGiven = function() {
                    var t, e;
                    for (se = !0, Fe(ut, z, B), t = 0; t < ue.length; t++) "string" === (e = typeof ue[t]) ? _e(ue[t], St) : "object" === e && Ee(ue[t], St);
                    ue = []
                }, this.rememberConsentGiven = function(t) {
                    if (Vt) N("rememberConsentGiven is called but cookies are disabled, consent will not be remembered");
                    else {
                        t && (t = 60 * t * 60 * 1e3), this.setConsentGiven();
                        var e = (new Date).getTime();
                        ce(st, e, t, z, B, jt)
                    }
                }, this.forgetConsentGiven = function() {
                    Vt ? N("forgetConsentGiven is called but cookies are disabled, consent will not be forgotten") : (Fe(st, z, B), ce(ut, (new Date).getTime(), 0, z, B, jt), this.requireConsent())
                }, this.isUserOptedOut = function() {
                    return !se
                }, this.optUserOut = this.forgetConsentGiven, this.forgetUserOptOut = this.rememberConsentGiven, n.trigger("TrackerSetup", [this])
        }
        var B = ["addTracker", "disableCookies", "setTrackerUrl", "setAPIUrl", "enableCrossDomainLinking", "setCrossDomainLinkingTimeout", "setSecureCookie", "setCookiePath", "setCookieDomain", "setDomains", "setUserId", "setSiteId", "enableLinkTracking", "requireConsent", "setConsentGiven"];

        function z(t, n) {
            var i = new G(t, n);
            for (h.push(i), _paq = function(t, e) {
                    var n, i, r = {};
                    for (n = 0; n < e.length; n++) {
                        var o = e[n];
                        for (r[o] = 1, i = 0; i < t.length; i++)
                            if (t[i] && t[i][0]) {
                                var a = t[i][0];
                                o === a && (w(t[i]), delete t[i], r[a] > 1 && "addTracker" !== a && N("The method " + a + ' is registered more than once in "_paq" variable. Only the last call has an effect. Please have a look at the multiple Piwik trackers documentation: https://developer.piwik.org/guides/tracking-javascript-guide#multiple-piwik-trackers'), r[a]++)
                            }
                    }
                    return t
                }(_paq, B), e = 0; e < _paq.length; e++) _paq[e] && w(_paq[e]);
            return _paq = new function() {
                return {
                    push: w
                }
            }, i
        }
        return k(u, "beforeunload", function() {
            var e;
            if (p = !0, O("unload"), t)
                do {
                    e = new Date
                } while (e.getTimeAlias() < t)
        }, !1), Date.prototype.getTimeAlias = Date.prototype.getTime, n = {
            initialized: !1,
            JSON: JSON_PIWIK,
            DOM: {
                addEventListener: function(t, e, n, i) {
                    "undefined" === typeof i && (i = !1), k(t, e, n, i)
                },
                onLoad: y,
                onReady: A,
                isNodeVisible: q,
                isOrWasNodeVisible: F.isNodeVisible
            },
            on: function(t, e) {
                r[t] || (r[t] = []), r[t].push(e)
            },
            off: function(t, e) {
                if (r[t])
                    for (var n = 0; n < r[t].length; n++) r[t][n] === e && r[t].splice(n, 1)
            },
            trigger: function(t, e, n) {
                if (r[t])
                    for (var i = 0; i < r[t].length; i++) r[t][i].apply(n || u, e)
            },
            addPlugin: function(t, e) {
                i[t] = e
            },
            getTracker: function(t, e) {
                return m(e) || (e = this.getAsyncTracker().getSiteId()), m(t) || (t = this.getAsyncTracker().getTrackerUrl()), new G(t, e)
            },
            getAsyncTrackers: function() {
                return h
            },
            addTracker: function(t, e) {
                return h.length ? h[0].addTracker(t, e) : z(t, e)
            },
            getAsyncTracker: function(t, e) {
                var n;
                if (!(h && h.length && h[0])) return z(t, e);
                if (n = h[0], !e && !t) return n;
                m(e) && null !== e || !n || (e = n.getSiteId()), m(t) && null !== t || !n || (t = n.getTrackerUrl());
                for (var i, r = 0; r < h.length; r++)
                    if ((i = h[r]) && String(i.getSiteId()) === String(e) && i.getTrackerUrl() === t) return i
            },
            retryMissedPluginCalls: function() {
                var t = d;
                d = [];
                for (var e = 0; e < t.length; e++) w(t[e])
            }
        }, "function" == typeof define && define.amd && define("piwik", [], function() {
            return n
        }), n
    }()),
    function() {
        if (window && "object" == typeof window.piwikPluginAsyncInit && window.piwikPluginAsyncInit.length)
            for (var t = 0; t < window.piwikPluginAsyncInit.length; t++) "function" == typeof window.piwikPluginAsyncInit[t] && window.piwikPluginAsyncInit[t]();
        window && window.piwikAsyncInit && window.piwikAsyncInit(), window.Piwik.getAsyncTrackers().length || ("object" == typeof _paq && void 0 !== _paq.length && _paq.length ? window.Piwik.addTracker() : _paq = {
            push: function(t) {
                "undefined" !== typeof console && console && console.error && console.error("_paq.push() was used but Piwik tracker was not initialized before the piwik.js file was loaded. Make sure to configure the tracker via _paq.push before loading piwik.js. Alternatively, you can create a tracker via Piwik.addTracker() manually and then use _paq.push but it may not fully work as tracker methods may not be executed in the correct order.", t)
            }
        }), window.Piwik.trigger("PiwikInitialized", []), window.Piwik.initialized = !0
    }(), "undefined" == typeof AnalyticsTracker && (AnalyticsTracker = window.Piwik), "function" != typeof piwik_log && (piwik_log = function(t, e, n, i) {
        function r(t) {
            try {
                if (window["piwik_" + t]) return window["piwik_" + t]
            } catch (t) {}
        }
        var o, a = window.Piwik.getTracker(n, e);
        a.setDocumentTitle(t), a.setCustomData(i), (o = r("tracker_pause")) && a.setLinkTrackingTimer(o), (o = r("download_extensions")) && a.setDownloadExtensions(o), (o = r("hosts_alias")) && a.setDomains(o), (o = r("ignore_classes")) && a.setIgnoreClasses(o), a.trackPageView(), r("install_tracker") && (piwik_track = function(t, e, n, i) {
            a.setSiteId(e), a.setTrackerUrl(n), a.trackLink(t, i)
        }, a.enableLinkTracking())
    });
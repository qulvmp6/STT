/* 當 MODE = DEV，電文回傳mock資料
   當 MODE = DEV_WITH_CONTROL，電文回傳mock資料，timer倒數機制與頁面流程控制啟用
   當 MODE = UAT_SELF，為本機測試模式
   當 MODE = UAT，為兆豐測試模式
   當 MODE = PDT，為兆豐正式模式 */
var Environment = {
	MODE: "PDT"
};

// 一般通用常數
var CommonConstant = {
	HOME_PAGE_URL: "https://www.megabank.com.tw/",
	PC_VERSION_URL: "https://ebank.megabank.com.tw/global2/as/as05/PAS50_Login.faces?_ga=2.185744489.1535354578.1512538345-1638537417.1509085628",
	SERVICE_LOCATION_URL: "https://www.megabank.com.tw/about/about04.asp",
	// ONLINE_DOCUMENT_URL: "https://creditcard.megabank.com.tw/megaweb/Index_CardApply.asp",
	
	GATEWAY_PDT_URL: "https://ebank.megabank.com.tw/MegaMCreditCard/rest/creditcard/",
	GATEWAY_UAT_URL: "https://192.168.53.157:452/MegaMCreditCard/rest/creditcard/",
	
	IFRAME_PDT_USERVRFY: "https://netbank.megabank.com.tw/natm/NETATM?channelID=UserVrfy&SourceID=001&SourceType=D",
	IFRAME_UAT_USERVRFY: "https://192.168.53.157:452/natm/NETATM?channelID=UserVrfy&SourceID=001&SourceType=D",

	DOC_RESEND_MAILTO: "mailto:is@megacard.com.tw?subject=Apply for credit card&body=Name:",
	
	ARTICLE_CODE_PREFIX: "article_",
	ARTICLE_CODE_COBRANDER: "CoBrander",
	
	CARD_TYPE_MEGABANK: "1",
	CARD_TYPE_OTHERS: "9",
	CARD_TYPE_USERVRFY: "17",
	// CARD_TYPE_ONLINE_DOCUMENT: "999",
	
	IDENTIFY_TYPE_MEGABANK: "2",
	IDENTIFY_TYPE_OTHERS: "3",
	IDENTIFY_TYPE_USERVRFY: "5",
	
	// 本行正卡申請IS_ORIGIN，他行IS_NOT_ORIGIN，存戶IS_USERVRFY
	IS_ORIGIN: "1",
	IS_NOT_ORIGIN: "0",
	IS_USERVRFY: "2",

	// 行業類別選單，對應代碼
	MENU_BUSINESS_STUDENT: "11",
	MENU_BUSINESS_OTHERS: "46",
	MENU_BUSINESS_FREELANCE: "34",

	// 職務類別選單，對應代碼
	MENU_JOB_STUDENT: "AAQ",
	MENU_JOB_OTHERS: "ABO",
	MENU_JOB_FREELANCE: "ABG",

	MENU_JOB_DESC_STUDENT: "學生",
	MENU_JOB_DESC_OTHERS: "家管/無業/退休",
	MENU_JOB_DESC_FREELANCE: "自由業",
	
	// 信用卡領取方式
	CARD_TO_BY_POST: "1",
	CARD_TO_BY_SELF: "4",

	// 簡訊OTP完整倒數秒數
	DEFAULT_SMS_OTP_COUNTDOWN_SEC: 180,

	UPLOAD_PIC_PREFIX: "P5_",
	UPLOAD_PIC_EXT: ".jpg",
	UPLOAD_XML_POSTFIX_WITH_FILE_EXT: "M.xml"
};

// 定義LocalStorage key
var LSKey = {
	ERROR_MSG: "errorMsg",

	QUERY_CODE: "queryCode",

	CM010_RQ_DATA: "CM010RqData",
	VR011_RQ_DATA: "VR011RqData",
	VR012_RQ_DATA: "VR012RqData",
	
	CM002_RS_DATA: "CM002RsData",
	VR012_RS_DATA: "VR012RsData",

	TOKEN_ID: "tokenID",
	TOKEN_TIME: "tokenTime",
	TIMEOUT_ALERT_TIME: "timeoutAlertTime",
	AES_KEY: "aesKey",

	CURRENT_HTML: "currentHtml",
	PREVIOUS_HTML: "previousHtml",
	
	TARGET_CREDIT_CARD: "targetCreditCard",

	IMAGE_IDFILE_F: "idFileF",
	IMAGE_IDFILE_B: "idFileB",
	ATTACHEMENTS_NAME_ARY: "attachmentsNameAry",

	ADDR1_CITY: "cPrimAddr1City",
	ADDR2_CITY: "cPrimAddr2City",
	ADDR3_CITY: "cPrimAddr3City",

	HAS_APPLICATION_SUBMIT: "hasApplicationSubmit",
	APPLICATION_FAIL_COUNT: "applicationFailCount",

	CARD_FRIEND_INFO: "cardFriendInfo",
	SMS_OTP_INFO: "smsOtpInfo"
};

/** 逾時倒數控制 */
function startTimer() {
	var singletonTimer = SingletonTimer.getInstance();
	singletonTimer.clear();
	singletonTimer.start();
}

function stopTimer() {
	var singletonTimer = SingletonTimer.getInstance();
	singletonTimer.clear();
}

function restartTimer() {
	var singletonTimer = SingletonTimer.getInstance();
	singletonTimer.restart();
}

// slide 方向 上-下 的toast訊息
function showToast(message) {
	if($(".c-toast-loader").length == 0) {
		$(".c-page-container").append("<div class='c-toast-loader'></div>");
	}

	var toastLoader = $(".c-toast-loader");
	toastLoader.empty();
	toastLoader.load("components/toast.html", function() {
		// 僅控制非disabled狀態的按鈕
		var $targetBtn = $(".c-btn--purple:not(:disabled)");
		$targetBtn.prop('disabled', true);

		$(".c-toast__message").text(message);
		toastLoader.addClass("slide-in__top");
		toastLoader.show();

		setTimeout(function() {
			toastLoader.addClass("slide-out__top");

			setTimeout(function() {
		    	toastLoader.hide();
		    	toastLoader.removeClass("slide-in__top");
				toastLoader.removeClass("slide-out__top");

				$targetBtn.prop('disabled', false);
			}, 500);
		}, 5000);
	});
}

// 錯誤彈出訊息
function showErrAlert(error){
	var errContent = '';

	if($.type(error) == 'string'){
		errContent = error;
	}else{
		var errorMsgAry = [];
		$.each(error,function(index,value){
			// 避免訊息重複
			var msg = error[index].message;
			var idx = errorMsgAry.indexOf(msg);
			if(idx === -1) {
				errContent += '<div style="margin-bottom: .5em;">' + msg + '</div>';
				errorMsgAry.push(msg);
			}
		});
	}

	if($(".errMsg").length == 0) {
		$(".c-page-container").append("<div class='c-modal u-display--none errMsg'></div>");
	}

	var errMsgView = $(".errMsg");
	errMsgView.empty();
	errMsgView.load("components/errorMsg.html", function() {
	
		$("#errContent").html(errContent);

		$(".errMsg .c-modal__act-bar .c-btn").unbind();
	    $(".errMsg .c-modal__act-bar .c-btn").bind("click", function() {
	    	$.unblockUI();
	    });
		
	});

	if($(".errMsg").length != 0) {

		var modal = $(".errMsg");
	    $.blockUI({
			message : modal,
			fadeIn: 0,
			baseZ: 998,
			css : {
				cursor : null,
				height : modal.height() + 'px',
				top : '12%',
				left : '50%',
				width : '80%',
				maxWidth : '800px',
				transform : 'translate(-50%,-50%)',
				border: 'none',
				'-webkit-border-radius': '5px',
				'-moz-border-radius': '5px',
				'border-radius': '5px',
				backgroundColor: 'white'
			}
		});
	}

}

/* 
* 比對頁面元件(element)是否存在於jquery.validate錯誤列表(errorList)中
* 若存在，回傳非-1 index
*/
function matchErrorElementByName(errorList, element) {
	var index = -1;

	if(element && errorList && errorList.length > 0) {
		for(var i = 0; i != errorList.length; i++) {
			if(errorList[i].element.name === element.name) {
				index = i;
				break;
			}
		}
	}

	return index;
}

//展開條款內容
function expendArticle(element){
	var articleKey = element.data("article-key");
	var htmlContent = decodeArticleContent(articleKey);

	if($(".c-article-expender-"+articleKey).length == 0) { 
		element.parent().after("<div class='c-article-expender c-article-expender-"+articleKey+"'></div>");
	}
	var windowHeight = $(window).height();
	//綁定底下條文區塊
	var articleExpender = $(".c-article-expender-"+articleKey);
	articleExpender.height(windowHeight*0.3);
	articleExpender.html(stripXSS(htmlContent));
	element.addClass('expend-up');
	articleExpender.show();
	
	element.bind("click", hideArticle);
	
}

//縮起條款內容
function hideArticle(){
	var articleKey = $(this).data("article-key");

	var articleExpender = $(".c-article-expender-"+articleKey);
	articleExpender.hide();
	$(this).removeClass("expend-up");
	$(this).unbind("click", hideArticle);
}

//指定收合條款內容
function hideArticleByKey(articleKey){
	var articleExpender = $(".c-article-expender-"+articleKey);
	articleExpender.hide();

	var $articleTitleElem = $('.c-article-item__title[data-article-key="' + articleKey + '"]');
	$articleTitleElem.removeClass("expend-up");
	$articleTitleElem.unbind("click", hideArticle);
}

// 條款項目與checkbox連動控制
function setArticleControl() {
	// 條款項目點擊後連動勾選checkbox
	$(".c-article-item__title").bind("click", function() {
		expendArticle($(this));
		$("#" + $(this).data("article-key")).prop("checked", true);
	});

	// checkbox勾選連動帶出條款內容頁
	$(".c-article-item__checkbox input[type='checkbox']").change(function() {
		if($(this).prop("checked")) {
			var articleKey = $(this).prop('name');
			var $articleTitleElem = $('.c-article-item__title[data-article-key="' + articleKey + '"]');

			expendArticle($articleTitleElem);
		}
	});
}

// 條款全部同意控制
function setAgreeAllArticleControl($agreeAllCheckboxElement) {
	if(!$agreeAllCheckboxElement) {
		return;
	}

	$agreeAllCheckboxElement.change(function() {
		if($(this).prop("checked")) {
			//同意並展開所有條款
			$('.c-article-item__title').each(function(index, articleTitleElem) {
				var articleKey = articleTitleElem.getAttribute('data-article-key');
				expendArticle($(articleTitleElem));

				var $articleCheckboxElemList = $('.c-article-item__checkbox input[type="checkbox"][name="' + articleKey + '"]');
				if($articleCheckboxElemList && $articleCheckboxElemList.length > 0) {
					$articleCheckboxElemList.eq(0).prop('checked', true);

					var lengthOfElem = $articleCheckboxElemList.length;
					if(lengthOfElem > 1) {
						for(var i = 1; i !== lengthOfElem; i++) {
							$articleCheckboxElemList.eq(i).prop('checked', false);
						}
					}
				}
			});
		} else {
			//初始化checkbox並收合所有條款
			$('.c-article-item__title').each(function(index, articleTitleElem) {
				var articleKey = articleTitleElem.getAttribute('data-article-key');
				hideArticleByKey(articleKey);

				var $articleCheckboxElemList = $('.c-article-item__checkbox input[type="checkbox"][name="' + articleKey + '"]');
				if($articleCheckboxElemList && $articleCheckboxElemList.length > 0) {
					var lengthOfElem = $articleCheckboxElemList.length;
					for(var i = 0; i !== lengthOfElem; i++) {
						$articleCheckboxElemList.eq(i).prop('checked', false);
					}
				}
			});
		}
	});
}

// 將checkbox設置為單選
function setCheckBoxExclusive(checkBoxName) {
	$("input[name='" + checkBoxName + "']").each(function() {
		$(this).bind("click", function() {
			$("input[name='" + checkBoxName + "']:checked").prop("checked", false);
			$(this).prop("checked", true);
		});
	});
}

// 組成下拉選單
function setDropdownList($selectElement, optionObjAry, emptyOptionObj) {
	if($selectElement) {
		var emptyOptionKey = (emptyOptionObj && emptyOptionObj.key) ? emptyOptionObj.key : '';
		var emptyOptionValue = (emptyOptionObj && emptyOptionObj.value) ? emptyOptionObj.value : '請選擇';

		$selectElement.empty();
		$selectElement.append("<option value='" + emptyOptionKey + "'>" + emptyOptionValue + "</option>");

		if(optionObjAry && optionObjAry.length > 0) {
			optionObjAry.forEach(function(optionObj) {
				$selectElement.append("<option value='" + optionObj.key + "'>" + optionObj.value + "</option>");
			});
		}
	}
}

// 設置下拉選單disabled屬性
function setDropdownListEnable($selectElement, isSetEnable) {
	if($selectElement) {
		if(isSetEnable) {
			$selectElement.prop("disabled", false);
			$selectElement.parent().removeClass("c-select-wrapper__disabled");
		} else {
			$selectElement.prop("disabled", true);
			$selectElement.parent().addClass("c-select-wrapper__disabled");
		}
	}
}

// 設定進度條圖示，本行卡申請流程或其他
function setProcessImg(isOrigin) {
	if(CommonConstant.IS_ORIGIN === isOrigin) {
		$("img[data-name='isOrigin']").show();
	} else {
		$("img[data-name='isNotOrigin']").show();
	}
}

// LocalStorage記錄目前與前一頁面
function updatePageNavInfo() {
	var currentUrl = document.location.pathname;
	var currentUrlSplit = currentUrl.split("/");
	var currentHtml = currentUrlSplit[currentUrlSplit.length - 1]

	if(currentHtml !== localStorage.getItem(LSKey.CURRENT_HTML)) {
		localStorage.setItem(LSKey.PREVIOUS_HTML, localStorage.getItem(LSKey.CURRENT_HTML));
		localStorage.setItem(LSKey.CURRENT_HTML, currentHtml);
	}
}

function doCancel() {
	clearWebStorage();
	location.href = CommonConstant.HOME_PAGE_URL;
}

// 字串左邊補0直到字串長度為totalLength
function appendPrefixZero(content, totalLength) {
	var result = "";
	if(content) {
		var count = totalLength - content.length;
		var zeroStr = "";
		if(count > 0) {
			for(var i = 0; i < count; i++) {
				zeroStr += "0";
			}
		}
		result = zeroStr + content;
	}
	return result;
}

function removePrefixZero(content) {
	return parseInt(content).toString();
}

// 字串隱碼處理 getStrMask('A123456789', 5, 7, '*') => A123***789
function getStrMask(inputStr, start, end, tokenChar) {
	var result = "";
	if(inputStr){
		var tokenLength = end - start + 1;
		if(tokenLength && tokenLength > 0) {
			var strPrefix = inputStr.substring(0, start - 1);
			var strPostfix = inputStr.substring(end);
			var tokenText = '';

			for(var i = 0; i != tokenLength; i++) {
				tokenText += tokenChar;
			}
			result = strPrefix + tokenText + strPostfix;
		}
	}
	return result;
}

function decodeArticleContent(articleKey) {
	var articleJSON = localStorage.getItem(articleKey);

	if(Environment.MODE === "DEV" || Environment.MODE === "DEV_WITH_CONTROL") {
		return JSON.parse(articleJSON).article;
	} else if(articleKey === (CommonConstant.ARTICLE_CODE_PREFIX + CommonConstant.ARTICLE_CODE_COBRANDER)) {
		return JSON.parse(articleJSON).article;
	} else {
		return decodeURIComponent(window.atob(JSON.parse(articleJSON).article).replace(/\+/g, "%20"));
	}
}

function showErrorPage(errorMsg) {
	// 保留query code，供錯誤頁返回時串接參數
	var queryCodeJSON = localStorage.getItem(LSKey.QUERY_CODE);

	clearWebStorage();

	if(queryCodeJSON) {
		localStorage.setItem(LSKey.QUERY_CODE, queryCodeJSON);
	}

	localStorage.setItem(LSKey.ERROR_MSG, errorMsg);
	location.href = "errorPage.html";
	throw new Error();
}

function clearWebStorage() {
	localStorage.clear();
	sessionStorage.clear();
}

// 檢核必要的LocalStorage data是否存在
function checkLocalStorage(LSKeyArray) {
	var isValid = true;
	if(LSKeyArray && LSKeyArray.length > 0) {
		for(var i = 0; i != LSKeyArray.length; i++) {
			var itemKey = LSKeyArray[i];
			if(!localStorage.getItem(itemKey)) {
				isValid = false;
				showErrorPage("驗證資訊有誤！請重新申請");
				break;
			}
		}
	}
	return isValid;
}

// 判斷使用的瀏覽器是否為行動裝置的瀏覽器
function checkUserAgent() {
	if(Environment.MODE !== "PDT") {
		return true;
	}

	var isValid = true;
	var userAgent = navigator.userAgent;
	if(!/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent)) {
		isValid = false;
		showErrorPage("請使用電腦版申請頁面進行信用卡線上申請");
	}
	return isValid;
}

// 判斷是否為手機裝置
function isMobile() {
	var isMobileFlag = false;
	var userAgent = navigator.userAgent;
	if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent)) {
		isMobileFlag = true;
	}
	return isMobileFlag;
}

// 畫面scroll至頁面元件，主要用在表單欄位檢核
(function($) {
    $.fn.goTo = function() {
    	var offset = 0;
    	if($(this).is(":visible")) {
			offset = $(this).offset().top;
    	} else {
			offset = $(this).parent().offset().top;
    	}

        $('html, body').animate({
            scrollTop: offset - 65 + 'px'	// 避免被toast覆蓋
        }, 'fast');
        return this;
    }
})(jQuery);

// 字串全域替換
String.prototype.replaceAll = function(search, replacement) {
	var target = this;
	return target.replace(new RegExp(search, 'g'), replacement);
};

// 上一步鈕
function goBack() {
	window.history.back();
}

// 以選單文字取得option jquery物件
function jqGetOptionbyText(selectName, text) {
	return $("select[name='" + selectName + "'] option").filter(function () {
		return $(this).html() == text;
	});
}

// XSS過濾
function stripXSS(content) {
	var result = content;
	var patterns = [
		/<script[\s\S]*?>[\s\S]*?<\/script>/gi, 
		/eval\((.*?)\)/gi, 
		/expression\((.*?)\)/gi, 
		/javascript:/gi, 
		/vbscript:/gi, 
		/onload(.*?)=/gi
	];
	patterns.forEach(function(pattern) {
		result = result.replace(pattern, "");
	});

	return result;
}

function showLoadingView() {
	if($("#loader").length == 0) {
		$(".c-page-container").append('<div id="loader"></div>');
	}

	var modal = $("#loader");
	modal.addClass("loading__circle");
	$.blockUI({
		message : modal,
		fadeIn: 0,
		baseZ: 998,
		css : {
			cursor : null,
			width : ($(window).width() * 0.7) + 'px',
			height : modal.height() + 'px',
			top : '25%',
			left : (($(window).width() * 0.3) / 2) + 'px',
			border: 'none',
			backgroundColor: 'transparent'
		}
	});
}

function hideLoadingView() {
	$.unblockUI();
	$("#loader").removeClass("loading__circle");
}

//email格式：須包含一個「＠」與一個（含）以上的「.」
function isEmailValid(email) {
	var isEmailValid = false;
	var atSignCount = email.length - email.replaceAll("@", "").length;
	if(atSignCount === 1 && email.indexOf(".") !== -1 && 
		email.indexOf(".@") === -1 && email.indexOf("@.") === -1 &&
		email.indexOf(" ") === -1) {
		isEmailValid = /^[^\u4E00-\u9FA5]*$/g.test(email);
	}
	return isEmailValid;
}

// 設置email autocomplete提示清單
function initEmailAutocomplete($emailInputElem) {
	if(!$emailInputElem) {
		return;
	}

	var autocompleteHostList = ["gmail.com", "hotmail.com", "yahoo.com.tw", "yahoo.com", 
		"pchome.com.tw", "msn.com", "livemail.tw", "outlook.com", "msa.hinet.net"];

	$emailInputElem.autocomplete({
		autoFocus: true,
		source: function (request, response) {
			var inputValue = request.term;
			var indexOfAtSign = inputValue.indexOf("@");
			var addressPart = inputValue;
			var hostPart = "";
			var result = [];

			result.push(inputValue);

			// 若已輸入@，取得address與host
			if (indexOfAtSign > -1) {
				addressPart = inputValue.slice(0, indexOfAtSign);
				hostPart = inputValue.slice(indexOfAtSign + 1);
			}

			if (addressPart) {
				// 取出相似於host的候選清單
				// 若未輸入host部分，則整個autocompleteHostList皆為候選清單
				var findedHosts = (hostPart ? $.grep(autocompleteHostList, function (value) {
					return value.indexOf(hostPart) > -1;
				}) : autocompleteHostList);

				// 將host候選清單與address部分組合，得到完整autocomplete清單
				var findedResults = $.map(findedHosts, function (value) {
					return addressPart + "@" + value;
				});

				result = result.concat($.makeArray(findedResults));
			}

			response(result);
		}
	});
}

function iFrameUrl() {
	if(Environment.MODE === "PDT") {
		return CommonConstant.IFRAME_PDT_USERVRFY;
	} else if (Environment.MODE === "UAT"){
		return CommonConstant.IFRAME_UAT_USERVRFY;
	} else {
		return "http://127.0.0.1:8080/MegaMCreditCardWeb/test_iframe.html?channelID=UserVrfy&SourceID=001&SourceType=D";
	}
}

function geteway_url() {
	if(Environment.MODE === "PDT") {
		return CommonConstant.GATEWAY_PDT_URL;
	} else if (Environment.MODE === "UAT") {
		return CommonConstant.GATEWAY_UAT_URL;
	} else if (Environment.MODE === "UAT_SELF"){
		return "http://127.0.0.1:8080/MegaMCreditCard/rest/creditcard/";
	} else {
		return "";
	}
}

// 將數位軌跡(Piwik)setSiteId與環境變數連動
function getPiwikSiteId() {
	if(Environment.MODE === "PDT") {
		return '3';
	} else if(Environment.MODE === "UAT") {
		return '4';
	} else {
		return '';
	}
}

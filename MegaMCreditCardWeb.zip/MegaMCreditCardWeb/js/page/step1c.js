var hasNotified = false;

$(document).ready(function(){
	if(checkLocalStorage([LSKey.VR011_RQ_DATA, LSKey.CM010_RQ_DATA])) {
		VR011RqDataObj = JSON.parse(localStorage.getItem(LSKey.VR011_RQ_DATA));
		CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));

		apiService = new ApiService();
		
		setProcessImg(CM010RqDataObj.isOrigin);

		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl(CM010RqDataObj.isOrigin);
		PageNavigationHandler.backControl();

		init();
		initValidate();

		startTimer();
	}
});

function init() {
	var smsOtpInfoObj = JSON.parse(localStorage.getItem(LSKey.SMS_OTP_INFO));

	if(smsOtpInfoObj) {
		$('#maskPhone').text(smsOtpInfoObj.maskPhone);
		$('#seqNo').text(smsOtpInfoObj.seqNo);
		$('#smsOtpCountdownSec').text(smsOtpInfoObj.smsOtpCountdownSec);

		if(smsOtpInfoObj.smsOtpCountdownSec && smsOtpInfoObj.smsOtpCountdownSec > 0) {
			$('#sendOtpBtn').prop('disabled', true);
			$('#nextBtn').prop('disabled', false);

			doSmsOtpCountdown();
		} else {
			$('#sendOtpBtn').prop('disabled', false);
			$('#nextBtn').prop('disabled', true);
		}
	} else {
		sendSmsOtp();
	}

	$("#sendOtpBtn").bind("click", function() {
		return sendSmsOtp();
	});
}

// 發送簡訊OTP
function sendSmsOtp() {
	$.Deferred().resolve().promise()
	.then(function() {
		var VR003RqDataObj = new VR003RqData();
		VR003RqDataObj.custID = CM010RqDataObj.cPrimId;
		VR003RqDataObj.birthday = CM010RqDataObj.cPrimBirthday;
		VR003RqDataObj.phoneNo = VR011RqDataObj.phoneNo; // 以使用者輸入的手機號碼發送OTP

		var VR003RqDataJSON = JSON.stringify(VR003RqDataObj);
		return apiService.doVR003(VR003RqDataJSON);
	})
	.then(function(rsDataJSON) {
		// 簡訊OTP發送成功，更新畫面資訊、清空簡訊密碼輸入框，並啟動倒數
		var VR003RsDataObj = JSON.parse(rsDataJSON);
		var countdownSec = CommonConstant.DEFAULT_SMS_OTP_COUNTDOWN_SEC;
		var smsOtpInfoObj = {
			seqNo: VR003RsDataObj.seqNo,
			maskPhone: VR003RsDataObj.maskPhone,
			smsOtpCountdownSec: countdownSec
		};

		localStorage.setItem(LSKey.SMS_OTP_INFO, JSON.stringify(smsOtpInfoObj));

		$('#maskPhone').text(smsOtpInfoObj.maskPhone);
		$('#seqNo').text(smsOtpInfoObj.seqNo);
		$('#smsOtpCountdownSec').text(countdownSec);
		$('input[name="otpPwd"]').val('');

		$('#sendOtpBtn').prop('disabled', true);
		$('#nextBtn').prop('disabled', false);

		doSmsOtpCountdown();
	});
}

// 簡訊OTP有效秒數倒數
function doSmsOtpCountdown() {
	countdownInterval = setInterval(function() {
		var smsOtpInfoObj = JSON.parse(localStorage.getItem(LSKey.SMS_OTP_INFO));
		var countdownSec = smsOtpInfoObj.smsOtpCountdownSec;

		if(countdownSec > 0) {
			countdownSec--;
			$("#smsOtpCountdownSec").text(countdownSec);

			smsOtpInfoObj.smsOtpCountdownSec = countdownSec;
			localStorage.setItem(LSKey.SMS_OTP_INFO, JSON.stringify(smsOtpInfoObj));
		} else {
			clearInterval(countdownInterval);

			$('#sendOtpBtn').prop('disabled', false);
			$('#nextBtn').prop('disabled', true);
		}
	}, 1000);
}

function doSubmit() {
	$.Deferred().resolve().promise()
	.then(function() {
		var smsOtpInfoObj = JSON.parse(localStorage.getItem(LSKey.SMS_OTP_INFO));
		var VR004RqDataObj = new VR004RqData();
		VR004RqDataObj.custID = CM010RqDataObj.cPrimId;
		VR004RqDataObj.birthday = CM010RqDataObj.cPrimBirthday;
		VR004RqDataObj.seqNo = smsOtpInfoObj.seqNo;
		VR004RqDataObj.otpCode = $('input[name="otpPwd"]').val();
		VR004RqDataObj.isGetCardFriendData = 'N'; // 存款帳戶驗證，在step1b便會取得卡友資訊，此處不需要取

		var VR004RqDataJSON = JSON.stringify(VR004RqDataObj);
		return apiService.doVR004(VR004RqDataJSON);
	})
	.then(function(response) {
		var returnCode = response.responseHeader.returnCode;
		if(returnCode === apiService.returnCode.SUCCESS) {
			localStorage.removeItem(LSKey.SMS_OTP_INFO);

			if(CM010RqDataObj.isOrigin === CommonConstant.IS_ORIGIN) {
				localStorage.setItem(LSKey.CURRENT_HTML, "otpVerify.html");
			}

			location.href = "step2_1.html";
		} else if(returnCode === apiService.returnCode.SMS_OTP_PWD_INVALID) {
			// 簡訊驗證碼輸入有誤，驗證失敗，popup提示
			showErrAlert(response.responseHeader.returnMsg);
		} else {
			// 其他錯誤，導錯誤頁
			showErrorPage(response.responseHeader.returnMsg);
		}
	});
}

function initValidate() {
	/** Validation */
	$("#page-form").validate({
		onclick: false,
		onkeyup: false,
		onfocusout: false,
		focusInvalid: false,
		ignore: [], //for checkbox hidden
		rules: {
			otpPwd: {
				required: true,
				digits: true
			}
		},
		messages: {
			otpPwd: {
				required: "請輸入簡訊密碼",
				digits: "僅限輸入數字"
			}
		},
		submitHandler: function() {
			doSubmit();
		},
		invalidHandler: function(event, validator){
			var errorList = validator.errorList;
			// 判斷沒有在errorList之後清掉invalid class
			if($('.is-invalid').length > 0){
				$.each($('.is-invalid'),function(index,element){
					var invalidIdx = matchErrorElementByName(errorList, element);
					if(invalidIdx < 0) {
						$(element).removeClass('is-invalid');
						$('.is-label--'+ element.name).removeClass('is-invalid--label');
					}
				});
			}
		},
		showErrors: function(errorMap, errorList){
			if(errorList.length > 0) {
				$.each(errorList,function(index,invalidObj){
					var element = invalidObj.element;
					$(element).addClass('is-invalid');
					$('.is-label--'+ element.name).addClass('is-invalid--label');
				});
				$(errorList[0].element).goTo();
				showErrAlert(errorList);
			}
		}
	});
}



$(document).ready(function(){
	if(checkLocalStorage([LSKey.CM010_RQ_DATA, LSKey.TARGET_CREDIT_CARD])) {
		CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));
		apiService = new ApiService();

		setProcessImg(CM010RqDataObj.isOrigin);

		targetCard = JSON.parse(localStorage.getItem(LSKey.TARGET_CREDIT_CARD));

		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl(CM010RqDataObj.isOrigin);

		init();
		initValidate();

		startTimer();
	}
});

function init() {
	setArticleControl();
	setAgreeAllArticleControl($("#agreeAll"));
	initCoBranderCardArticle();
	setCheckBoxExclusive("article_AC6");
	setCheckBoxExclusive("article_CoBrander");
}

// 聯名卡同意條款初始化
function initCoBranderCardArticle() {
	var CM005RqDataObj = new CM005RqData();
	CM005RqDataObj.cardCode = CM010RqDataObj.cardCode;
	apiService.doCM005(JSON.stringify(CM005RqDataObj)).then(function(rsDataJSON) {
		if(rsDataJSON) {
			var CM005RsDataObj = JSON.parse(rsDataJSON);
			var articleCoBranderObj = {
				article: CM005RsDataObj.article,
				articleCode: CommonConstant.ARTICLE_CODE_COBRANDER,
				version: ''
			};
			localStorage.setItem(CommonConstant.ARTICLE_CODE_PREFIX + CommonConstant.ARTICLE_CODE_COBRANDER,
				JSON.stringify(articleCoBranderObj));

			$("#cbcArticleLeadingText").text(CM005RsDataObj.leadingText);
			$(".cbcArticleDiv").toggleClass('u-display--none');
		} else {
			// 非聯名卡
			$(".cbcArticleDiv").hide();
		}
	});
}

function doSubmit() {
	updateCM010RqDataObj();

	localStorage.setItem(LSKey.HAS_APPLICATION_SUBMIT, "N");
	localStorage.setItem(LSKey.APPLICATION_FAIL_COUNT, "0");

	apiService.doSC002().then(function() {
		location.href = "step3_2.html";
	});
}

function updateCM010RqDataObj() {
	if($("#article_AC6_Y:checked").length > 0) {
		CM010RqDataObj.agreeThirdParty = "1";
	} else {
		CM010RqDataObj.agreeThirdParty = "0";
	}

	if($(".cbcArticleDiv:visible").length > 0) {
		if($("#article_CoBrander_Y:checked").length > 0) {
			CM010RqDataObj.cBrandedCardFlag = "1";
		} else {
			CM010RqDataObj.cBrandedCardFlag = "2";
		}
	} else {
		// 	非聯名卡
		CM010RqDataObj.cBrandedCardFlag = "0";
	}

	localStorage.setItem(LSKey.CM010_RQ_DATA, JSON.stringify(CM010RqDataObj));
}

function isCoBranderCardArticleAgree() {
	return $("#article_CoBrander_Y:checked").length > 0;
}

function initValidate() {
	/** 聯名卡條款必須同意 */
	$.validator.addMethod('mustAgree', function(value,element) {
		return isCoBranderCardArticleAgree();
	},'不同意聯名卡同意條款則無法申辦本聯名卡');

	$("#page-form").validate({
		onclick: false,
		onkeyup: false,
		onfocusout: false,
		focusInvalid: false,
		ignore: [], //for checkbox hidden
		rules: {
			article_AC6: {
				required: true
			},
			article_CoBrander: {
				required: {
					depends: function() {
						return $(".cbcArticleDiv:visible").length > 0;
					}
				},
				mustAgree: {
					depends: function() {
						return $(".cbcArticleDiv:visible").length > 0;
					}
				}
			}
		},
		messages: {
			article_AC5: {
				required: "請先閱讀聲明同意條款"
			},
			article_AC6: {
				required: "請勾選共同行銷/特約合作之第三人行銷同意事項"
			},
			article_CoBrander: {
				required: "請選擇是否同意聯名卡同意條款，如不同意則無法申辦本聯名卡"
			}
		},
		submitHandler: function() {
			doSubmit();
		},
		invalidHandler: function(event, validator){
			var errorList = validator.errorList;
			// 判斷沒有在errorList之後清掉invalid class
			if($('.is-invalid').length > 0){
				$.each($('.is-invalid'),function(index,element){
					var invalidIdx = matchErrorElementByName(errorList, element);
					if(invalidIdx < 0) {
						$(element).removeClass('is-invalid');
						$('.is-label--'+ element.name).removeClass('is-invalid--label');
					}
				});
			}
		},
		showErrors: function(errorMap, errorList){
			if(errorList.length > 0) {
				$.each(errorList,function(index,invalidObj){
					var element = invalidObj.element;
					$(element).addClass('is-invalid');
					$('.is-label--'+ element.name).addClass('is-invalid--label');
				});
				$(errorList[0].element).goTo();
				// showToast(errorList[0].message);
				showErrAlert(errorList);
			}
		}
	});
}

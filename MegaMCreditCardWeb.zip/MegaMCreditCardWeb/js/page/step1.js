$(document).ready(function(){
	if(checkLocalStorage([LSKey.CM010_RQ_DATA])) {
		CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));
		apiService = new ApiService();

		if(CM010RqDataObj.mIdentifyType === CommonConstant.IDENTIFY_TYPE_MEGABANK) {
			$("img[data-name='isOrigin']").show();
		} else {
			$("img[data-name='isNotOrigin']").show();
		}

		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl();
		PageNavigationHandler.backControl();

		doSC001();
		init();
		initValidate();
	}
});

function init() {
	var articleLoaders = $(".articleLoader");
	articleLoaders.each(function() {
		$(this).empty();
		$(this).append(decodeArticleContent($(this).data("article-key")));
	});

	if(isCardTypeOthers()) {
		$("div[data-card-type='others']").show();
		$("div[data-card-type='others']").css('display','inline-block');
	} else {
		$(".pc-step1-adjust-right").css('float','none');
	}

	var nowDate = new Date();
	var nowDateYear = nowDate.getFullYear();	// 西元年
	var nowDateCYear = nowDateYear - 1911;		// 民國年
	
	initBirthdayInput();
	initDueDateSelectList(nowDateYear);
	initCreditCardInput();
	setCheckBoxExclusive("validationAgreement");
}

function doSC001() {
	apiService.doSC001().then(function(rsDataJSON) {
		var SC001RsDataObj = JSON.parse(rsDataJSON);
		localStorage.setItem(LSKey.TOKEN_ID, SC001RsDataObj.tokenID);
		localStorage.setItem(LSKey.TOKEN_TIME, SC001RsDataObj.tokenTime);
		localStorage.setItem(LSKey.TIMEOUT_ALERT_TIME, SC001RsDataObj.timeoutAlertTime);
		localStorage.setItem(LSKey.AES_KEY, SC001RsDataObj.aesKey);

		$("img[data-name='gOTP']").attr("src", SC001RsDataObj.gOTP);

		startTimer();
	});
}

function initBirthdaySelectList(nowDateCYear) {
	var birthdayYearList = $("select[name='birthday_Y']");
	for(var i = nowDateCYear - 100; i < nowDateCYear - 19; i++) {
		birthdayYearList.append("<option value='" + i + "'>" + i + "</option>");
	}

	birthdayYearList.focus(function() {
		if($(this).data("focused") !==  true) {
			birthdayYearList.children("option[value='" + (nowDateCYear - 30) + "']").prop('selected', true);
		}
	});

	birthdayYearList.blur(function() {
		$(this).data('focused', false); 
	});

	for(var i = 1; i <= 12; i++) {
		$("select[name='birthday_M']").append("<option value='" + i + "'>" + i + "</option>");
	}

	for(var i = 1; i <= 31; i++) {
		$("select[name='birthday_D']").append("<option value='" + i + "'>" + i + "</option>");
	}
}

function initDueDateSelectList(nowDateYear) {
	for(var i = 1; i <= 12; i++) {
		$("select[name='dueDate_M']").append("<option value='" + i + "'>" + i + "</option>");
	}

	var dueDateYearList = $("select[name='dueDate_Y']");
	for(var i = nowDateYear; i <= nowDateYear + 10; i++) {
		var year = nowDateYear + i;
		dueDateYearList.append("<option value='" + i + "'>" + i + "</option>");
	}

	dueDateYearList.focus(function() {
		if($(this).data("focused") !==  true) {
			$(this).data("focused", true);  
			dueDateYearList.children("option[value='" + nowDateYear + "']").prop('selected', true);
		}
	});

	dueDateYearList.blur(function() {
		$(this).data('focused', false); 
	});
}

function initCreditCardInput() {
	$("input[name='creditCard_1']").on("keyup", function(e){
		e.preventDefault();
		if($(this).val().length >= parseInt($(this).attr("maxlength"), 10)) {
			$("input[name='creditCard_2']").focus();
		}
	});

	$("input[name='creditCard_2']").on("keyup", function(e){
		e.preventDefault();
		if($(this).val().length >= parseInt($(this).attr("maxlength"), 10)) {
			$("input[name='creditCard_3']").focus();
		}
	});

	$("input[name='creditCard_3']").on("keyup", function(e){
		e.preventDefault();
		if($(this).val().length >= parseInt($(this).attr("maxlength"), 10)) {
			$("input[name='creditCard_4']").focus();
		}
	});
}

function initBirthdayInput() {
	$("input[name='birthday_Y']").on("keyup", function(e){
		e.preventDefault();
		if($(this).val().length == parseInt($(this).attr("maxlength"), 10)) {
			$("input[name='birthday_M']").focus();
		}
	});
	$("input[name='birthday_M']").on("keyup", function(e){
		e.preventDefault();
		if($(this).val().length == parseInt($(this).attr("maxlength"), 10)) {
			$("input[name='birthday_D']").focus();
		}
	});
	$("input[name='birthday_M']").on("focusout", function(e){
		e.preventDefault();
		if($(this).val().length == 1 && /\b[1-9]\b/gm.test($(this).val()) ) {			
			$(this).val(appendPrefixZero($(this).val(), 2));
		}
	});
	$("input[name='birthday_D']").on("focusout", function(e){
		e.preventDefault();
		if($(this).val().length == 1 && /\b[1-9]\b/gm.test($(this).val()) ) {			
			$(this).val(appendPrefixZero($(this).val(), 2));
		}
	});

}

function doSubmit() {
	var validationInfoObj = collectValidationInfo();

	$.Deferred().resolve().promise()
	.then(function() {
		CM010RqDataObj.cPrimBirthday = validationInfoObj.birthday;
		CM010RqDataObj.cPrimId = validationInfoObj.primID;
		CM010RqDataObj.cAccount = validationInfoObj.creditCard;
		localStorage.setItem(LSKey.CM010_RQ_DATA, JSON.stringify(CM010RqDataObj));
		showLoadingView();
		if(isCardTypeOthers()) {
			// 他行驗證
			var VR001RqDataObj = new VR001RqData();
			VR001RqDataObj.primID = validationInfoObj.primID;
			VR001RqDataObj.birthday = validationInfoObj.birthday;
			VR001RqDataObj.creditCard = validationInfoObj.creditCard;
			VR001RqDataObj.dueDate = validationInfoObj.dueDate;
			VR001RqDataObj.checkCode = validationInfoObj.checkCode;
			VR001RqDataObj.otp = validationInfoObj.otp;

			var VR001RqDataJSON = JSON.stringify(VR001RqDataObj);
			return apiService.doVR001(VR001RqDataJSON);
		} else {
			// 本行驗證
			var VR002RqDataObj = new VR002RqData();
			VR002RqDataObj.primID = validationInfoObj.primID;
			VR002RqDataObj.birthday = validationInfoObj.birthday;
			VR002RqDataObj.otp = validationInfoObj.otp;

			var VR002RqDataJSON = JSON.stringify(VR002RqDataObj);
			return apiService.doVR002(VR002RqDataJSON);
		}
	})
	.then(function(rsDataJSON) {
		hideLoadingView();
		if(isCardTypeOthers()) {
			// 他行驗證 - 判斷驗證結果，cardFlag為0表示本行卡友
			var VR001RsDataObj = JSON.parse(rsDataJSON);
			if(VR001RsDataObj.cardFlag === "0") {
				CM010RqDataObj.isOrigin = CommonConstant.IS_ORIGIN;
				CM010RqDataObj.cPrimChName = VR001RsDataObj.primChName;
				CM010RqDataObj.cPrimCellulaNo1 = VR001RsDataObj.phoneNo;
				CM010RqDataObj.cPrimEmail = VR001RsDataObj.email;

				localStorage.setItem(LSKey.CURRENT_HTML, "otpVerify.html");
			} else {
				CM010RqDataObj.isOrigin = CommonConstant.IS_NOT_ORIGIN;
			}

			var cardFriendInfoObj = {
				primChName: VR001RsDataObj.primChName,
				cardFlag: VR001RsDataObj.cardFlag,
				billAddr: VR001RsDataObj.billAddr,
				autoPayIndicator: VR001RsDataObj.autoPayIndicator,
				autoPayAcctBank: VR001RsDataObj.autoPayAcctBank,
				autoPayAcctNo: VR001RsDataObj.autoPayAcctNo,
				phoneNo: VR001RsDataObj.phoneNo,
				email: VR001RsDataObj.email
			};

			localStorage.setItem(LSKey.CM010_RQ_DATA, JSON.stringify(CM010RqDataObj));
			localStorage.setItem(LSKey.CARD_FRIEND_INFO, JSON.stringify(cardFriendInfoObj));

			location.href = "step2_1.html";
			return $.Deferred().resolve();
		} else {
			location.href = "otpVerify.html";
			return $.Deferred().resolve();
		}
	});
}

function collectValidationInfo() {
	var birthday_Y = appendPrefixZero($("input[name='birthday_Y']").val(), 3);
	var birthday_M = appendPrefixZero($("input[name='birthday_M']").val(), 2);
	var birthday_D = appendPrefixZero($("input[name='birthday_D']").val(), 2);

	var dueDate_Y = $("select[name='dueDate_Y']").val().substring(2);
	var dueDate_M = appendPrefixZero($("select[name='dueDate_M']").val(), 2);

	var validationInfo = {
		primID: $("input[name='primID']").val(),
		birthday: birthday_Y + birthday_M + birthday_D,
		creditCard: $("input[name='creditCard_1']").val() + $("input[name='creditCard_2']").val() + $("input[name='creditCard_3']").val() + $("input[name='creditCard_4']").val(),
		dueDate: dueDate_M + dueDate_Y,
		checkCode: $("input[name='checkCode']").val(),
		otp: $("input[name='otp']").val()
	};

	return validationInfo;
}


function isValidYearStr() {
	return $('[name=birthday_Y]').val()>0;
}

function isValidMonthStr() {
	return $('[name=birthday_M]').val()>0 && $('[name=birthday_M]').val()<=12;
}

function isValidDayStr() {
	return $('[name=birthday_D]').val()>0 && $('[name=birthday_D]').val()<=31;
}

function isExistDate() {
	var birthday_Y =  (parseInt($('[name=birthday_Y]').val(),10) + 1911);
	var birthday_M = $('[name=birthday_M]').val();
	var birthday_D = $('[name=birthday_D]').val();
	var limitForEachMonth = [31,28,31,30,31,30,31,31,30,31,30,31];
	var isLeap = new Date(birthday_Y, 1, 29).getDate() === 29;
	if(isLeap) limitForEachMonth[1] = 29;	
	return birthday_D <= limitForEachMonth[birthday_M-1];
}

function isLegalAdulthood() {
	var today = new Date();
	var rocYear = today.getFullYear() - 1911;
	var birthday_Y = $('[name=birthday_Y]').val() ? (parseInt($('[name=birthday_Y]').val(),10) + 1911) : today.getFullYear();
	var birthday_M = $('[name=birthday_M]').val() || '01';
	var birthday_D = $('[name=birthday_D]').val() || '01'; 
	var birthday = new Date(birthday_Y+'/'+birthday_M+'/'+birthday_D);
	var age = today.getFullYear() - birthday.getFullYear();
	birthday.setFullYear(today.getFullYear());
	if(today < birthday) age --;
	return age >= 20;
}

function isCardTypeOthers() {
	return CM010RqDataObj.mIdentifyType === CommonConstant.IDENTIFY_TYPE_OTHERS;
}

function isIdentityVerificationAgree() {
	return $("#accept:checked").length > 0;
}

function initValidate() {
	/** 身分證檢核 */
	$.validator.addMethod('rocID', function(value,element) {
		return /^[a-z]{1,1}[1-2]{1,1}\d{8,8}$/gi.test(value);
	},'請輸入正確身分證字號');
	
	$.validator.addMethod('validDateStr', function(value,element) {
		var digits = value.split('');
		return !isNaN(digits[0]) && (typeof digits[1] !== "undefined" ? !isNaN(digits[1]) : true);
	},'請輸入數字');
	
	$.validator.addMethod('validYearStr', function(value,element) {
		return isValidYearStr();
	},'請輸入正確的年份');
	
	$.validator.addMethod('validMonthStr', function(value,element) {
		return isValidMonthStr();
	},'請輸入正確的月份');
	
	$.validator.addMethod('validDayStr', function(value,element) {
		return isValidDayStr();
	},'請輸入正確的日期');
	
	$.validator.addMethod('existDate', function(value,element) {
		return isExistDate();
	},'請輸入正確的生日');

	/** 檢核正卡申請人需年滿20歲 */
	$.validator.addMethod('legalAdulthood', function(value,element) {
		return isLegalAdulthood();
	},'正卡申請人須年滿20歲');

	/** 身分驗證條款必須同意 */
	$.validator.addMethod('mustAgree', function(value,element) {
		return isIdentityVerificationAgree();
	},'不同意身分驗證條款則無法繼續申請本行信用卡，請改用其他管道申請');

	/** Validation */
	$("#page-form").validate({
		onclick: false,
		onkeyup: false,
		onfocusout: false,
		focusInvalid: false,
		ignore: [], //for checkbox hidden
		rules: {
			primID: {
				required: true,
				rocID: true
			},
			validationAgreement: {
				required: {
					depends: function() { //他行身份驗證
						return isCardTypeOthers();
					}
				},
				mustAgree: {
					depends: function() {
						return isCardTypeOthers();
					}
				}
			},
			birthday_Y: {
				required: true,
				validDateStr: true,
				validYearStr: true,
				existDate: {
					depends: function(element){ return isValidMonthStr() && isValidDayStr();  }
				},
				legalAdulthood: {
					depends: function(element){ return isValidMonthStr() && isValidDayStr() && isExistDate();  }
				}		
			},
			birthday_M: {
				required: true,
				validDateStr: true,
				validMonthStr: true,
				existDate: {
					depends: function(element){ return isValidYearStr() && isValidDayStr();  }
				},
				legalAdulthood: {
					depends: function(element){ return isValidYearStr() && isValidDayStr() && isExistDate();  }
				}
			},
			birthday_D: {
				required: true,
				validDateStr: true,
				validDayStr: true,
				existDate: {
					depends: function(element){ return isValidYearStr() && isValidMonthStr();  }
				},
				legalAdulthood: {
					depends: function(element){ return isValidYearStr() && isValidMonthStr() && isExistDate();  }
				}
			},
			creditCard_1: {
				required: {
					depends: function() {
						return isCardTypeOthers();
					}
				},
				digits: true
			},
			creditCard_2: {
				required: {
					depends: function() {
						return isCardTypeOthers();
					}
				},
				digits: true
			},
			creditCard_3: {
				required: {
					depends: function() {
						return isCardTypeOthers();
					}
				},
				digits: true
			},
			creditCard_4: {
				required: {
					depends: function() {
						return isCardTypeOthers();
					}
				},
				digits: true
			},
			dueDate_M: {
				required: {
					depends: function() {
						return isCardTypeOthers();
					}
				}
			},
			dueDate_Y: {
				required: {
					depends: function() {
						return isCardTypeOthers();
					}
				}
			},
			checkCode: {
				required: {
					depends: function() {
						return isCardTypeOthers();
					}
				},
				digits: true
			}
		},
		messages: {
			primID: {
				required: "請輸入身分證字號"
			},
			birthday_Y: {
				required: "請輸入完整出生年月日"
			},
			birthday_M: {
				required: "請輸入完整出生年月日"
			},
			birthday_D: {
				required: "請輸入完整出生年月日"
			},
			creditCard_1: {
				required: "請輸入完整信用卡卡號",
				digits: "僅限輸入數字"
			},
			creditCard_2: {
				required: "請輸入完整信用卡卡號",
				digits: "僅限輸入數字"
			},
			creditCard_3: {
				required: "請輸入完整信用卡卡號",
				digits: "僅限輸入數字"
			},
			creditCard_4: {
				required: "請輸入完整信用卡卡號",
				digits: "僅限輸入數字"
			},
			dueDate_Y: {
				required: "請輸入卡片到期月年"
			},
			dueDate_M: {
				required: "請輸入卡片到期月年"
			},
			checkCode: {
				required: "請輸入卡片背面檢核碼",
				digits: "僅限輸入數字"
			},
			otp: {
				required: "請輸入圖形驗證碼"
			},
			validationAgreement: {
				required: "請選擇是否同意身分驗證條款，如不同意則無法繼續申請本行信用卡"
			}
		},
		submitHandler: function() {
			doSubmit();
		},
		invalidHandler: function(event, validator){
			var errorList = validator.errorList;
			// 判斷沒有在errorList之後清掉invalid class
			if($('.is-invalid').length > 0){
				$.each($('.is-invalid'),function(index,element){
					var invalidIdx = matchErrorElementByName(errorList, element);
					if(invalidIdx < 0) {
						$(element).removeClass('is-invalid');
						$('.is-label--'+ element.name).removeClass('is-invalid--label');
					}
				});
			}
		},
		showErrors: function(errorMap, errorList){
			if(errorList.length > 0) {
				$.each(errorList,function(index,invalidObj){
					var element = invalidObj.element;
					$(element).addClass('is-invalid');
					$('.is-label--'+ element.name).addClass('is-invalid--label');
				});
				$(errorList[0].element).goTo();
				//showToast(errorList[0].message);
				showErrAlert(errorList);
			}
		}
	});
}





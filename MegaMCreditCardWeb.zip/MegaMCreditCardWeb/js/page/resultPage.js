$(document).ready(function(){
	if(checkLocalStorage([LSKey.CM010_RQ_DATA])) {
		CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));
		apiService = new ApiService();

		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl(CM010RqDataObj.isOrigin);
		PageNavigationHandler.backControl();

		init();

		startTimer();
	}
});

function init() {
	var modal = $("#loader");
	modal.addClass("loading__circle");
	$.blockUI({
		message : modal,
		fadeIn: 0,
		css : {
			cursor : null,
			width : ($(window).width() * 0.7) + 'px',
			height : modal.height() + 'px',
			top : '25%',
			left : (($(window).width() * 0.3) / 2) + 'px',
			border: 'none',
			backgroundColor: 'transparent'
		}
	});

	// 呼叫CM010，取得PDF結果
	CM010RqDataObj.toPDF = "1";
	apiService.doCM010(JSON.stringify(CM010RqDataObj)).then(function(rsDataJSON) {
		CM010RsDataObj = JSON.parse(rsDataJSON);
		renderPDF();
	});
}

// 繪製pdf並帶有可點擊的anchor連結
function renderPDF() {
	var container = document.getElementById("canvasContainer");
	var viewer = document.createElement('div');
	viewer.id = "viewer";
	viewer.classList.add("pdfViewer");
	container.appendChild(viewer);

	var pdfLinkService = new PDFJS.PDFLinkService();

	var pdfViewer = new PDFJS.PDFViewer({
		container: container,
		linkService: pdfLinkService,
		removePageBorders: true
	});
	pdfLinkService.setViewer(pdfViewer);

	container.addEventListener("pagesinit", function () {
		pdfViewer.currentScaleValue = "page-actual";
	});

	var pdfData = atob(CM010RsDataObj.resultPDF);
	PDFJS.externalLinkTarget = PDFJS.LinkTarget.BLANK;	// anchor連結外開
	PDFJS.getDocument({data: pdfData}).then(function (pdfDocument) {
		pdfViewer.setDocument(pdfDocument);
		pdfLinkService.setDocument(pdfDocument, null);

		$.unblockUI();
	});
}

function doFinish() {
	clearWebStorage();
	location.href = CommonConstant.HOME_PAGE_URL;
}

function doDownload() {
	var blob = base64ToBlob(CM010RsDataObj.resultPDF, "application/pdf");
	var blobUrl = URL.createObjectURL(blob);
	var pdfFileName = "resultPDF.pdf";

	// for IE
	if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(blob, pdfFileName);
    } else { // other browsers
    	var dlnk = document.getElementById("downloadLink");
		dlnk.href = blobUrl;
		dlnk.download = pdfFileName;
		dlnk.click();
    }

	// $.ajax({
	// 	url : "assets/testBase64Pdf.txt",
	// 	dataType: "text",
	// 	success : function (data) {
	// 		var blob = base64ToBlob(data, "application/pdf");
	// 		var blobUrl = URL.createObjectURL(blob);

	// 		var dlnk = document.getElementById('downloadLink');
	// 		dlnk.href = blobUrl;
	// 		dlnk.download = "testPDF.pdf";
	// 		dlnk.click();
	// 	}
	// });
}

function base64ToBlob(b64Data, contentType, sliceSize) {
	contentType = contentType || '';
	sliceSize = sliceSize || 512;

	var byteCharacters = atob(b64Data);
	var byteArrays = [];

	for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
		var slice = byteCharacters.slice(offset, offset + sliceSize);

		var byteNumbers = new Array(slice.length);
		for (var i = 0; i < slice.length; i++) {
			byteNumbers[i] = slice.charCodeAt(i);
		}

		var byteArray = new Uint8Array(byteNumbers);
		byteArrays.push(byteArray);
	}

	var blob = new Blob(byteArrays, {type: contentType});
	return blob;
}

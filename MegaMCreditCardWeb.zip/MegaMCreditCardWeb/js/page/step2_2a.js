var mBillDesc = '';

 $.pageshow = function (fn) {
            if (typeof window.onpageshow == "undefined")
                $(document).ready(fn);
            else
                $(window).bind("pageshow", fn);
        };

$.pageshow(function(event) {
	if(checkLocalStorage([LSKey.CM010_RQ_DATA])) {
		CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));
		CardFriendInfoObj = JSON.parse(localStorage.getItem(LSKey.CARD_FRIEND_INFO));
		VR012RsDataObj = JSON.parse(localStorage.getItem(LSKey.VR012_RS_DATA));

		apiService = new ApiService();

		targetCard = JSON.parse(localStorage.getItem(LSKey.TARGET_CREDIT_CARD));

		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl(CM010RqDataObj.isOrigin);

		init();
		initValidate();

		startTimer();
	}
});

function init() {
	var cPrimCellulaNo1 = (CM010RqDataObj.cPrimCellulaNo1) ? CM010RqDataObj.cPrimCellulaNo1 : "";
	var cPrimEmail = (CM010RqDataObj.cPrimEmail) ? CM010RqDataObj.cPrimEmail : "";

	// 本行手機號碼，不可修改
	if((CardFriendInfoObj && CardFriendInfoObj.phoneNo) || (VR012RsDataObj && VR012RsDataObj.phoneNo)) {
		$("input[name='cPrimCellulaNo1']").prop('disabled', true);
		cPrimCellulaNo1 = getStrMask(cPrimCellulaNo1, 5, 7, '*');
	}

	$("input[name='cPrimCellulaNo1']").val(cPrimCellulaNo1);
	$("input[name='cPrimEmail']").val(cPrimEmail);

	initEbillArticle();
	initEmailAutocomplete($("input[name='cPrimEmail']"));
}

function initEbillArticle() {
	// 電子帳單同意條款
	if(targetCard.eBill === "Y") {
		mBillDesc = "申請" + targetCard.cardName + "者，其帳單均預設為以電子郵件方式寄送。";
		$("#mBillDesc_isEbill").text(mBillDesc);
		$("#mBillDesc_isEbill").show();
	} else {
		setCheckBoxExclusive("mBillByMail");

		if(CM010RqDataObj.mBillByMail && CM010RqDataObj.mBillByMail === "0") {
			$("#mBillByMail_Y").prop("checked", false);
			$("#mBillByMail_N").prop("checked", true);
		} else {
			$("#mBillByMail_Y").prop("checked", true);
			$("#mBillByMail_N").prop("checked", false);
		}
		$("#mBillDesc_notEbill").show();
	}
}

function doSubmit() {
	var phoneNo = '';
	if(CardFriendInfoObj && CardFriendInfoObj.phoneNo) {
		phoneNo = CardFriendInfoObj.phoneNo;
	} else if(VR012RsDataObj && VR012RsDataObj.phoneNo) {
		phoneNo = VR012RsDataObj.phoneNo;
	} else {
		phoneNo = $("input[name='cPrimCellulaNo1']").val();
	}

	CM010RqDataObj.cPrimCellulaNo1 = phoneNo;
	CM010RqDataObj.cPrimEmail = $("input[name='cPrimEmail']").val();

	// 當eBill為Y時，其帳單預設為以電子郵件方式寄送
	if(targetCard.eBill === "Y") {
		CM010RqDataObj.mBillDesc = mBillDesc;
		CM010RqDataObj.mBillByMail = "1";
	} else {
		CM010RqDataObj.mBillDesc = "";
		
		if($("#mBillByMail_N:checked").length > 0) {
			CM010RqDataObj.mBillByMail = "0";
		} else {
			CM010RqDataObj.mBillByMail = "1";
		}
	}

	localStorage.setItem(LSKey.CM010_RQ_DATA, JSON.stringify(CM010RqDataObj));

	apiService.doSC002().then(function() {
		location.href = "step3_1.html";
	});
}

function initValidate() {
	//email格式：須包含一個「＠」與一個（含）以上的「.」
	$.validator.addMethod('strictEmail', function(value){
		return isEmailValid(value);
	});
	//若信用卡強制為電子帳單or信用卡非電子帳單但使用者同意電子帳單，email必填
	var isEmailRequired = function() {
		return targetCard.eBill === "Y" || $("#mBillByMail_Y:checked").length > 0;
	};

	$("#page-form").validate({
		onclick: false,
		onkeyup: false,
		onfocusout: false,
		focusInvalid: false,
		ignore: [], //for checkbox hidden
		rules: {
			cPrimCellulaNo1: {
				digits: true
			},
			cPrimEmail: {
				required: {
					depends: function() {
						return isEmailRequired();
					}
				},
				strictEmail: {
					depends: function() {
						return ($("input[name='cPrimEmail']").val()).length > 0;
					}
				}
			},
			mBillByMail: {
				required: {
					depends: function() {
						return targetCard.eBill !== "Y";
					}
				}
			}
		},
		messages: {
			cPrimCellulaNo1: {
				required: "請輸入行動電話",
				digits: "僅限輸入數字"
			},
			cPrimEmail: {
				required: "請輸入E-mail",
				strictEmail: "請輸入正確E-mail格式"
			},
			mBillByMail: {
				required: "請選擇是否同意電子帳單"
			}
		},
		submitHandler: function() {
			doSubmit();
		},
		invalidHandler: function(event, validator){
			var errorList = validator.errorList;
			// 判斷沒有在errorList之後清掉invalid class
			if($('.is-invalid').length > 0){
				$.each($('.is-invalid'),function(index,element){
					var invalidIdx = matchErrorElementByName(errorList, element);
					if(invalidIdx < 0) {
						$(element).removeClass('is-invalid');
						$('.is-label--'+ element.name).removeClass('is-invalid--label');
					}
				});
			}
		},
		showErrors: function(errorMap, errorList){
			if(errorList.length > 0) {
				$.each(errorList,function(index,invalidObj){
					var element = invalidObj.element;
					$(element).addClass('is-invalid');
					$('.is-label--'+ element.name).addClass('is-invalid--label');
				});
				$(errorList[0].element).goTo();
				// showToast(errorList[0].message);
				showErrAlert(errorList);
			}
		}
	});
}
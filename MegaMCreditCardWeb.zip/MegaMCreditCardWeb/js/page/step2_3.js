var gOptionAryStudent = [];

var gOptionAryOthers = [];

var gOptionAryFreelance = [];

var gPreBussCode = null;

 $.pageshow = function (fn) {
            if (typeof window.onpageshow == "undefined")
                $(document).ready(fn);
            else
                $(window).bind("pageshow", fn);
        };

$.pageshow(function(event) {
	if(checkLocalStorage([LSKey.CM010_RQ_DATA, LSKey.CM002_RS_DATA])) {
		CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));
		CM002RsDataObj = JSON.parse(localStorage.getItem(LSKey.CM002_RS_DATA));
		apiService = new ApiService();

		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl(CM010RqDataObj.isOrigin);

		init();
		initValidate();

		startTimer();
	}
});

function init() {
	initOptionAry();
	initFormControl();
	restoreInputForm();
}

function initOptionAry() {
	gOptionAryStudent.push({
		key: CommonConstant.MENU_JOB_STUDENT,
		value: CommonConstant.MENU_JOB_DESC_STUDENT
	});

	gOptionAryOthers.push({
		key: CommonConstant.MENU_JOB_OTHERS,
		value: CommonConstant.MENU_JOB_DESC_OTHERS
	});

	gOptionAryFreelance.push({
		key: CommonConstant.MENU_JOB_FREELANCE,
		value: CommonConstant.MENU_JOB_DESC_FREELANCE
	});
}

function initFormControl() {
	addrZoneMap = {};

	var addrZoneList = CM002RsDataObj.addrZone;
	addrZoneList.forEach(function(addrZone) {
		addrZoneMap[addrZone.city] =  addrZone.dists;

		$("select[name='cPrimAddr3City']").append("<option value='" + addrZone.city + "'>" + addrZone.city + "</option>");
	});
	$("select[name='cPrimAddr3City']").change(function() {
		updateAddrZipSelectList($("select[name='cPrimAddr3Zip']"), $(this).val());
	})

	var nowDate = new Date();
	var nowDateYear = nowDate.getFullYear();	// 西元年
	var nowDateCYear = nowDateYear - 1911;		// 民國年
	for(var i = nowDateCYear; i <= nowDateCYear + 10; i++) {
		$("select[name='cPrimGraduateDate_Y']").append("<option value='" + i + "'>" + i + "</option>");
	}
	for(var i = 1; i <= 12; i++) {
		$("select[name='cPrimGraduateDate_M']").append("<option value='" + i + "'>" + i + "</option>");
	}

	var telZoneNumList = CM002RsDataObj.telZoneNum;
	telZoneNumList.forEach(function(telZoneNum) {
		$("select[name='cPrimOfficeTelNo1a']").append("<option value='" + telZoneNum.key + "'>" + telZoneNum.value + "</option>");
	});

	// 行業類別選單
	var busInessList = CM002RsDataObj.busIness;
	var $cPrimBussCodeSelect = $("select[name='cPrimBussCode']");
	// 職務類別選單
	var jobList = CM002RsDataObj.job;
	var $cPrimJobTitleCodeSelect = $("select[name='cPrimJobTitleCode']");

	busInessList.forEach(function(busInessInfo) {
		$cPrimBussCodeSelect.append("<option value='" + busInessInfo.key + "'>" + busInessInfo.value + "</option>");
	});

	$cPrimBussCodeSelect.change(function() {
		if($(this).val() === CommonConstant.MENU_BUSINESS_STUDENT) {
			// 重組職務類別選單，鎖定選項-學生
			setDropdownList($cPrimJobTitleCodeSelect, gOptionAryStudent, null);
			setDropdownListEnable($cPrimJobTitleCodeSelect, false);
			$cPrimJobTitleCodeSelect.val(CommonConstant.MENU_JOB_STUDENT);

			setPageElement(true);

			clearJobInfoInCase();

			$('.hideWhenBusinessOthers').show();
		} else if($(this).val() === CommonConstant.MENU_BUSINESS_OTHERS) {
			// 重組職務類別選單，鎖定選項-家管
			setDropdownList($cPrimJobTitleCodeSelect, gOptionAryOthers, null);
			setDropdownListEnable($cPrimJobTitleCodeSelect, false);
			$cPrimJobTitleCodeSelect.val(CommonConstant.MENU_JOB_OTHERS);

			setPageElement(false);

			$("input[name='cNote4']").val("0");
			$("input[name='cPrimCompany']").val("家管");
			$("input[name='cPrimJobTitle']").val("家管");

			$('.hideWhenBusinessOthers').hide();
		} else if($(this).val() === CommonConstant.MENU_BUSINESS_FREELANCE) {
			// 重組職務類別選單，鎖定選項-自由業
			setDropdownList($cPrimJobTitleCodeSelect, gOptionAryFreelance, null);
			setDropdownListEnable($cPrimJobTitleCodeSelect, false);
			$cPrimJobTitleCodeSelect.val(CommonConstant.MENU_JOB_FREELANCE);

			setPageElement(false);

			$("input[name='cNote4']").val("0");

			clearJobInfoInCase();

			$('.hideWhenBusinessOthers').show();
		} else {
			// 重組職務類別選單，開放選單
			setDropdownList($cPrimJobTitleCodeSelect, jobList, null);
			setDropdownListEnable($cPrimJobTitleCodeSelect, true);

			setPageElement(false);

			clearJobInfoInCase();

			$('.hideWhenBusinessOthers').show();
		}

		gPreBussCode = $(this).val();
	});

	jobList.forEach(function(jobInfo) {
		$cPrimJobTitleCodeSelect.append("<option value='" + jobInfo.key + "'>" + jobInfo.value + "</option>");
	});

	$("input[name='cPrimOfficeTelNo1b']").on("keyup", function(e){
		e.preventDefault();
		if($(this).val().length >= parseInt($(this).attr("maxlength"), 10)) {
			$("input[name='cPrimOfficeTelNo1c']").focus();
		}
	});

	if(CM010RqDataObj.isOrigin === CommonConstant.IS_ORIGIN) {
		$("div[data-group='cPrimAddr3Group']").hide();
	} else {
		initCheckbox();
	}
}

function clearJobInfoInCase() {
	// 行業類別 從 其他(家管、無業、退休) 選項，切換為別的選項時，清空 公司/學校名稱, 現任職稱/就讀系所
	if(gPreBussCode === CommonConstant.MENU_BUSINESS_OTHERS) {
		$('input[name="cPrimCompany"]').val('');
		$('input[name="cPrimJobTitle"]').val('');
	}
}

function setPageElement(isStudent) {
	if(isStudent) {
		$("input[name='cNote4']").parents(".u-width--48").hide();
		$("input[name='cNote4']").parents(".u-width--48").parent().find(".u-width--4").hide();
		$("input[name='cNote4']").parents(".u-width--48").parent().find(".u-width--52").show();
		$("#cPrimGraduateDateGroup").show();
	} else {
		$("input[name='cNote4']").parents(".u-width--48").show();
		$("input[name='cNote4']").parents(".u-width--48").parent().find(".u-width--4").show();
		$("input[name='cNote4']").parents(".u-width--48").parent().find(".u-width--52").hide();
		$("#cPrimGraduateDateGroup").hide();
	}
}

function updateAddrZipSelectList(jqTarget, city) {
	jqTarget.empty();
	jqTarget.append("<option value=''>鄉鎮市區</option>");

	if(city) {
		var dists = addrZoneMap[city];
		dists.forEach(function(distInfo) {
			jqTarget.append("<option value='" + distInfo.postalCode + "'>" + distInfo.dist + "</option>");
		});
	}
}

function initCheckbox() {
	setCheckBoxExclusive("addrForAccount");

	// 帳號寄送地址非同公司地址時，隱藏公司地址輸入欄位
	$("input[name='addrForAccount']").change(function() {
		if(this.checked) {
			if(this.id == "sameAsAddr3") {
				$("#cPrimAddr3Group").show();
			} else {
				$("#cPrimAddr3Group").hide();
			}
		}
	});
}

function restoreInputForm() {
	$("input[name='cPrimCompany']").val(CM010RqDataObj.cPrimCompany);
	$("input[name='cPrimJobTitle']").val(CM010RqDataObj.cPrimJobTitle);

	var $cPrimBussCodeSelect = $("select[name='cPrimBussCode']");
	var $cPrimJobTitleCodeSelect = $("select[name='cPrimJobTitleCode']");

	if(CM010RqDataObj.cPrimBussCode === CommonConstant.MENU_BUSINESS_STUDENT) {
		var cPrimGraduateDate = CM010RqDataObj.cPrimGraduateDate;
		var cPrimGraduateDateAry = [cPrimGraduateDate.substring(0, 3), cPrimGraduateDate.substring(3, 5)];
		$("select[name='cPrimGraduateDate_Y']").val(removePrefixZero(cPrimGraduateDateAry[0]));
		$("select[name='cPrimGraduateDate_M']").val(removePrefixZero(cPrimGraduateDateAry[1]));
		$("input[name='cNote4']").val("");

		setDropdownList($cPrimJobTitleCodeSelect, gOptionAryStudent, null);
		setDropdownListEnable($cPrimJobTitleCodeSelect, false);
		setPageElement(true);

		$('.hideWhenBusinessOthers').show();
	} else {
		if(CM010RqDataObj.cPrimBussCode === CommonConstant.MENU_BUSINESS_OTHERS) {
			setDropdownList($cPrimJobTitleCodeSelect, gOptionAryOthers, null);
			setDropdownListEnable($cPrimJobTitleCodeSelect, false);
			$cPrimJobTitleCodeSelect.val(CommonConstant.MENU_JOB_OTHERS);

			$('.hideWhenBusinessOthers').hide();
		} else if(CM010RqDataObj.cPrimBussCode === CommonConstant.MENU_BUSINESS_FREELANCE) {
			setDropdownList($cPrimJobTitleCodeSelect, gOptionAryFreelance, null);
			setDropdownListEnable($cPrimJobTitleCodeSelect, false);
			$cPrimJobTitleCodeSelect.val(CommonConstant.MENU_JOB_FREELANCE);

			$('.hideWhenBusinessOthers').show();
		} else {
			$('.hideWhenBusinessOthers').show();
		}

		$("input[name='cNote4']").val(CM010RqDataObj.cNote4);
		$("select[name='cPrimGraduateDate_Y']").val("");
		$("select[name='cPrimGraduateDate_M']").val("");

		setPageElement(false);
	}

	$cPrimBussCodeSelect.val(CM010RqDataObj.cPrimBussCode);
	$cPrimJobTitleCodeSelect.val(CM010RqDataObj.cPrimJobTitleCode);

	$("input[name='cPrimSalary']").val(CM010RqDataObj.cPrimSalary);

	var cPrimOfficeTelNo1aOption = jqGetOptionbyText("cPrimOfficeTelNo1a", CM010RqDataObj.cPrimOfficeTelNo1a);
	cPrimOfficeTelNo1aOption.prop("selected", true);
	$("input[name='cPrimOfficeTelNo1b']").val(CM010RqDataObj.cPrimOfficeTelNo1b);
	$("input[name='cPrimOfficeTelNo1c']").val(CM010RqDataObj.cPrimOfficeTelNo1c);

	if(CM010RqDataObj.isOrigin !== CommonConstant.IS_ORIGIN) {
		var mBillTo = CM010RqDataObj.mBillTo;
		if(mBillTo) {
			if(mBillTo == "3") {
				$("#sameAsAddr3").prop("checked", true);

				updateAddrZipSelectList($("select[name='cPrimAddr3Zip']"), localStorage.getItem(LSKey.ADDR3_CITY));
				$("select[name='cPrimAddr3Zip']").val(CM010RqDataObj.cPrimAddr3Zip);
				$("select[name='cPrimAddr3City']").val(localStorage.getItem(LSKey.ADDR3_CITY));
				$("input[name='cPrimAddr3']").val(CM010RqDataObj.cPrimAddr3);
				$("#cPrimAddr3Group").show();
			} else {
				if(mBillTo == "2") {
					$("#sameAsAddr1").prop("checked", true);
				} else if(mBillTo == "1") {
					$("#sameAsAddr2").prop("checked", true);
				}

				$("select[name='cPrimAddr3Zip']").val("");
				$("select[name='cPrimAddr3City']").val("");
				$("input[name='cPrimAddr3']").val("");
				$("#cPrimAddr3Group").hide();
			}
		}
	}	
}

function doSubmit() {
	updateCM010RqDataObj();

	apiService.doSC002().then(function() {
		location.href = "step3_1.html";
	});
}

function updateCM010RqDataObj() {
	CM010RqDataObj.cPrimCompany = $("input[name='cPrimCompany']").val();
	CM010RqDataObj.cPrimJobTitle = $("input[name='cPrimJobTitle']").val();
	CM010RqDataObj.cPrimSalary = $("input[name='cPrimSalary']").val();
	CM010RqDataObj.cPrimBussCode = $("select[name='cPrimBussCode']").val();
	CM010RqDataObj.cPrimJobTitleCode = $("select[name='cPrimJobTitleCode']").val();

	if(CM010RqDataObj.cPrimBussCode === CommonConstant.MENU_BUSINESS_STUDENT) {
		CM010RqDataObj.cNote4 = "";
		CM010RqDataObj.cPrimGraduateDate = appendPrefixZero($("select[name='cPrimGraduateDate_Y']").val(), 3) + 
			appendPrefixZero($("select[name='cPrimGraduateDate_M']").val(), 2);
	} else {
		CM010RqDataObj.cNote4 = $("input[name='cNote4']").val();
		CM010RqDataObj.cPrimGraduateDate = "";
	}

	CM010RqDataObj.cPrimOfficeTelNo1a = $("select[name='cPrimOfficeTelNo1a'] option:selected").val();
	CM010RqDataObj.cPrimOfficeTelNo1b = $("input[name='cPrimOfficeTelNo1b']").val();
	CM010RqDataObj.cPrimOfficeTelNo1c = $("input[name='cPrimOfficeTelNo1c']").val();

	var addrForAccountChoice = $("input[name='addrForAccount']:checked").prop("id");
	if(addrForAccountChoice == "sameAsAddr2") {
		// 同戶籍地址
		CM010RqDataObj.mBillTo = "1";
		CM010RqDataObj.cPrimAddr3Zip = "";
		CM010RqDataObj.cPrimAddr3 = "";
	} else if(addrForAccountChoice == "sameAsAddr1") {
		// 同居住地址
		CM010RqDataObj.mBillTo = "2";
		CM010RqDataObj.cPrimAddr3Zip = "";
		CM010RqDataObj.cPrimAddr3 = "";
	} else if(addrForAccountChoice == "sameAsAddr3") {
		// 同公司地址
		CM010RqDataObj.mBillTo = "3";
		CM010RqDataObj.cPrimAddr3Zip = $("select[name='cPrimAddr3Zip']").val();
		CM010RqDataObj.cPrimAddr3 = $("input[name='cPrimAddr3']").val();
		localStorage.setItem(LSKey.ADDR3_CITY, $("select[name='cPrimAddr3City']").val());
	}

	localStorage.setItem(LSKey.CM010_RQ_DATA, JSON.stringify(CM010RqDataObj));
}

function initValidate() {
	/** 是學生 */
	var isStudent = function() {
		return $("select[name='cPrimBussCode']").val() === CommonConstant.MENU_BUSINESS_STUDENT;
	};

	/** 是自由業or其他(家管、無業、退休) */
	var isFreelanceOrOthers = function() {
		return $("select[name='cPrimBussCode']").val() === CommonConstant.MENU_BUSINESS_FREELANCE || $("select[name='cPrimBussCode']").val() === CommonConstant.MENU_BUSINESS_OTHERS;
	};

	/** 寄送帳號至公司地址 */
	var sendBillToCompany = function() {
		return $('#sameAsAddr3').prop('checked');
	};

	// 地址不可以有「/」、「$」、「@」、「「」、「」」、「。」、「、」、「?」、「？」、「!」、「！」、「.」、「'」、「,」、「，」
	$.validator.addMethod('strictAddr', function(value){
		return /^[^/$@「」。、?？!！.',，]+$/g.test(value);
	});

	// 檢核字串僅能包含中、英數字
	$.validator.addMethod('strictText', function(value){
		return /^[\u4E00-\u9FA5A-Za-z0-9]+$/g.test(value);
	});
	
	$("#page-form").validate({
		onclick: false,
		onkeyup: false,
		onfocusout: false,
		focusInvalid: false,
		ignore: [], //for checkbox hidden
		rules: {
			cPrimCompany: {
				strictText: true
			},
			cPrimJobTitle: {
				strictText: true
			},
			cNote4: {
				required: {
					depends: function() { return ! isStudent();}
				},
				digits: true
			},
			cPrimSalary: {
				required: true,
				digits: true
			},
			cPrimGraduateDate_Y: {
				required: {
					depends: isStudent
				}
			},
			cPrimGraduateDate_M: {
				required: {
					depends: isStudent
				}
			},
			cPrimOfficeTelNo1a: {
				required: {
					depends: function() {
						return (!isFreelanceOrOthers() && !isStudent()) || ($('input[name="cPrimOfficeTelNo1b"]').val() || $('input[name="cPrimOfficeTelNo1c"]').val());
					}
				}
			},
			cPrimOfficeTelNo1b: {
				required: {
					depends: function() {
						return (!isFreelanceOrOthers() && !isStudent()) || ($('select[name="cPrimOfficeTelNo1a"]').val() || $('input[name="cPrimOfficeTelNo1c"]').val());
					}
				},
				digits: true
			},
			cPrimOfficeTelNo1c: {
				digits: true
			},
			addrForAccount: {
				required: {
					depends: function() {/** 非正卡持有人 */
						return CM010RqDataObj.isOrigin !== CommonConstant.IS_ORIGIN;
					}
				}
			},
			cPrimAddr3City: {
				required: {
					depends: sendBillToCompany
				}
			},
			cPrimAddr3Zip: {
				required: {
					depends: sendBillToCompany
				}
			},
			cPrimAddr3: {
				required: {
					depends: sendBillToCompany
				},
				strictAddr: {
					depends: sendBillToCompany
				}
			}
		},
		messages: {
			cPrimCompany: {
				required: "請輸入公司/學校名稱",
				strictText: "限輸入中、英數字"
			},
			cPrimJobTitle: {
				required: "請輸入現任職稱/就讀系所",
				strictText: "限輸入中、英數字"
			},
			cPrimBussCode: {
				required: "請輸入行業類別"
			},
			cPrimJobTitleCode: {
				required: "請輸入職務類別"
			},
			cNote4: {
				required: "請輸入工作年資",
				digits: "限輸入數字"
			},
			cPrimSalary: {
				required: "請輸入年收入",
				digits: "限輸入數字"
			},
			cPrimGraduateDate_Y: {
				required: "請輸入預計畢業年月（民國）"
			},
			cPrimGraduateDate_M: {
				required: "請輸入預計畢業年月（民國）"
			},
			cPrimOfficeTelNo1a: {
				required: "請輸入公司電話區碼"
			},
			cPrimOfficeTelNo1b: {
				required: "請輸入公司電話號碼",
				digits: "限輸入數字"
			},
			cPrimOfficeTelNo1c: {
				digits: "限輸入數字"
			},
			addrForAccount: {
				required: "請選擇帳單寄送地址"
			},
			cPrimAddr3City: {
				required: "請輸入完整公司地址"
			},
			cPrimAddr3Zip: {
				required: "請輸入完整公司地址"
			},
			cPrimAddr3: {
				required: "請輸入完整公司地址",
				strictAddr: "地址不可帶有特殊符號"
			}
		},
		submitHandler: function() {
			doSubmit();
		},
		invalidHandler: function(event, validator){
			var errorList = validator.errorList;
			// 判斷沒有在errorList之後清掉invalid class
			if($('.is-invalid').length > 0){
				$.each($('.is-invalid'),function(index,element){
					var invalidIdx = matchErrorElementByName(errorList, element);
					if(invalidIdx < 0) {
						$(element).removeClass('is-invalid');
						$('.is-label--'+ element.name).removeClass('is-invalid--label');
					}
				});
			}
		},
		showErrors: function(errorMap, errorList){
			if(errorList.length > 0) {
				$.each(errorList,function(index,invalidObj){
					var element = invalidObj.element;
					$(element).addClass('is-invalid');
					$('.is-label--'+ element.name).addClass('is-invalid--label');
				});
				$(errorList[0].element).goTo();
				// showToast(errorList[0].message);
				showErrAlert(errorList);
			}
		}
	});
}
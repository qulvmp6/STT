 //為了解決各瀏覽器間回上一頁觸發 ready或onpageshow的問題。
 $.pageshow = function (fn) {
            if (typeof window.onpageshow == "undefined")
                $(document).ready(fn);
            else
                $(window).bind("pageshow", fn);
        };

$.pageshow(function(event) {
	if(checkLocalStorage([LSKey.CM010_RQ_DATA])) {
		CM010RqDataObj = JSON.parse(localStorage.getItem(LSKey.CM010_RQ_DATA));
		if(CM010RqDataObj.isOrigin === CommonConstant.IS_ORIGIN) {
			CardFriendInfoObj = JSON.parse(localStorage.getItem(LSKey.CARD_FRIEND_INFO));
			VR012RsDataObj = JSON.parse(localStorage.getItem(LSKey.VR012_RS_DATA));
		}
		apiService = new ApiService();

		setProcessImg(CM010RqDataObj.isOrigin);

		MASK_CHAR = "*";

		updatePageNavInfo();
		PageNavigationHandler.walkthroughtControl(CM010RqDataObj.isOrigin);
		PageNavigationHandler.backControl();
		
		init();
		initValidate();

		startTimer();
	}
});

function init() {
	apiService.doCM002().then(function(rsDataJSON) {
		localStorage.setItem(LSKey.CM002_RS_DATA, rsDataJSON);
		var CM002RsDataObj = JSON.parse(rsDataJSON);
		var cityCardIssueList = CM002RsDataObj.cityCardIssue;
		var cardIDCFlagList = CM002RsDataObj.cardIDCFlag;
		var marriageList = CM002RsDataObj.marriage;
		var educationList = CM002RsDataObj.education;

		cityCardIssueList.forEach(function(cityCardIssue) {
			$("select[name='cCityCardIssue']").append("<option value='" + cityCardIssue.key + "'>" + cityCardIssue.value + "</option>");
		});
		cardIDCFlagList.forEach(function(cardIDCFlag) {
			$("select[name='cardIDCFlag']").append("<option value='" + cardIDCFlag.key + "'>" + cardIDCFlag.value + "</option>");
		});
		marriageList.forEach(function(marriage) {
			$("select[name='mPrimMarriage']").append("<option value='" + marriage.key + "'>" + marriage.value + "</option>");
		});
		educationList.forEach(function(education) {
			$("select[name='mPrimEducation']").append("<option value='" + education.key + "'>" + education.value + "</option>");
		});

		initFormControl();
		initIdCardSelectList();
		restoreInputForm();
	});
}

function initFormControl() {
	// 載入信用卡預覽圖示
	var targetCard = JSON.parse(localStorage.getItem(LSKey.TARGET_CREDIT_CARD));
	if(targetCard) {
		$(".c-img--credit-card-preview").prop("src", targetCard.picUrl);
		$(".c-text--apply-credit-card span[data-name='cardName']").text(targetCard.cardKind);
	}

	if(CM010RqDataObj.isOrigin === CommonConstant.IS_ORIGIN) {
		var inputCPrimChName = $("input[name='cPrimChName']");
		inputCPrimChName.val(maskPersonName(CM010RqDataObj.cPrimChName));

		inputCPrimChName.focus(function() {
			if(inputCPrimChName.val().indexOf(MASK_CHAR) !== -1) {
				inputCPrimChName.val(CM010RqDataObj.cPrimChName);
				$("input[name='cPrimEngName']").parent().show();
			}
		});
	} else {
		$("div[data-group='isOrigin']").show();
		$("input[name='cPrimEngName']").parent().show();
	}

	var cPrimBirthday = CM010RqDataObj.cPrimBirthday;
	if(cPrimBirthday) {
		var cPrimBirthdayAry = [cPrimBirthday.substring(0, 3), cPrimBirthday.substring(3, 5), cPrimBirthday.substring(5)];
		$(".c-text[data-name='cPrimBirthday']").text("民國 " + removePrefixZero(cPrimBirthdayAry[0]) + " 年 " + removePrefixZero(cPrimBirthdayAry[1]) + " 月 " + removePrefixZero(cPrimBirthdayAry[2]) + " 日");
	}
	$(".c-text[data-name='cPrimId']").text(getStrMask(CM010RqDataObj.cPrimId, 5, 7, '*'));
}

function initIdCardSelectList() {
	var nowDate = new Date();
	var nowDateYear = nowDate.getFullYear();	// 西元年
	var nowDateCYear = nowDateYear - 1911;		// 民國年

	for(var i = 94; i <= nowDateCYear; i++) {
		$("select[name='cardIDCDate_Y']").append("<option value='" + i + "'>" + i + "</option>");
	}

	for(var i = 1; i <= 12; i++) {
		$("select[name='cardIDCDate_M']").append("<option value='" + i + "'>" + i + "</option>");
	}

	for(var i = 1; i <= 31; i++) {
		$("select[name='cardIDCDate_D']").append("<option value='" + i + "'>" + i + "</option>");
	}
}

// 帶入先前填寫的資料
function restoreInputForm() {
	if(CM010RqDataObj.isOrigin === CommonConstant.IS_ORIGIN && !CM010RqDataObj.cPrimEngName) {
		$("input[name='cPrimChName']").val(maskPersonName(CM010RqDataObj.cPrimChName));
		$("input[name='cPrimEngName']").parent().hide();
	} else {
		$("input[name='cPrimChName']").val(CM010RqDataObj.cPrimChName);
		$("input[name='cPrimEngName']").val(CM010RqDataObj.cPrimEngName);
		$("input[name='cPrimEngName']").parent().show();
	}

	if(CM010RqDataObj.isOrigin !== CommonConstant.IS_ORIGIN) {
		if(CM010RqDataObj.cardIDCDate) {
			var cardIDCDate = CM010RqDataObj.cardIDCDate;
			var cardIDCDateAry = [cardIDCDate.substring(0, 3), cardIDCDate.substring(3, 5), cardIDCDate.substring(5)];
			$("select[name='cardIDCDate_Y']").val(removePrefixZero(cardIDCDateAry[0]));
			$("select[name='cardIDCDate_M']").val(removePrefixZero(cardIDCDateAry[1]));
			$("select[name='cardIDCDate_D']").val(removePrefixZero(cardIDCDateAry[2]));

			$("select[name='cCityCardIssue']").val(CM010RqDataObj.cCityCodeCardIssue);
			$("select[name='cardIDCFlag']").val(CM010RqDataObj.cardIDCFlag);
			$("select[name='mPrimMarriage']").val(CM010RqDataObj.mPrimMarriage);
			$("select[name='mPrimEducation']").val(CM010RqDataObj.mPrimEducation);
		} else {
			$("select[name='cardIDCDate_Y']").val("");
			$("select[name='cardIDCDate_M']").val("");
			$("select[name='cardIDCDate_D']").val("");
		}
	}
}

function replaceStringAt(content, index, replacement) {
	return content.substr(0, index) + replacement + content.substr(index + replacement.length);
}

function maskPersonName(pName) {
	var maskChar = MASK_CHAR;
	var maskStr = "";
	if(pName && pName.length >= 2) {
		pName = replaceStringAt(pName, 1, maskChar);
		if(pName.length >= 4) {
			var fromIndex = 2;
			var toIndex = pName.length - 1;
			for(var i = fromIndex; i != toIndex; i++) {
				maskStr = maskStr.concat(maskChar);
			}
			pName = replaceStringAt(pName, fromIndex, maskStr);
		}
	}
	return pName;
}

function doSubmit() {
	updateCM010RqDataObj();

	apiService.doSC002().then(function() {
		
		if(CM010RqDataObj.isOrigin == CommonConstant.IS_ORIGIN ) {
			location.href = "step2_2a.html";
		} else {
			location.href = "step2_2.html";
		}
	});
}


function updateCM010RqDataObj() {
	if(CM010RqDataObj.isOrigin === CommonConstant.IS_ORIGIN) {
	    if($("input[name='cPrimChName']").val().indexOf(MASK_CHAR) === -1) {
	    	CM010RqDataObj.cPrimChName = $("input[name='cPrimChName']").val();
	    	
	    	var orginChName = (CardFriendInfoObj && CardFriendInfoObj.primChName) ? CardFriendInfoObj.primChName : (VR012RsDataObj && VR012RsDataObj.primChName) ? VR012RsDataObj.primChName : "";
			var newChName = $("input[name='cPrimChName']").val();
			if(newChName === orginChName) {
				CM010RqDataObj.cPrimEngName = "";
			} else {
				CM010RqDataObj.cPrimEngName = $("input[name='cPrimEngName']").val();
			}
		} else {
			CM010RqDataObj.cPrimEngName = "";
		}
	} else {
		CM010RqDataObj.cPrimChName = $("input[name='cPrimChName']").val();
		CM010RqDataObj.cPrimEngName = $("input[name='cPrimEngName']").val();

		var cardIDCDate_Y = appendPrefixZero($("select[name='cardIDCDate_Y']").val(), 3);
		var cardIDCDate_M = appendPrefixZero($("select[name='cardIDCDate_M']").val(), 2);
		var cardIDCDate_D = appendPrefixZero($("select[name='cardIDCDate_D']").val(), 2);
		CM010RqDataObj.cardIDCDate = cardIDCDate_Y + cardIDCDate_M + cardIDCDate_D;

		CM010RqDataObj.cCityCardIssue = $("select[name='cCityCardIssue'] option:selected").text();
		CM010RqDataObj.cCityCodeCardIssue = $("select[name='cCityCardIssue']").val();
		CM010RqDataObj.cardIDCFlag = $("select[name='cardIDCFlag']").val();
		CM010RqDataObj.mPrimMarriage = $("select[name='mPrimMarriage']").val();
		CM010RqDataObj.mPrimEducation = $("select[name='mPrimEducation']").val();
	}

	localStorage.setItem(LSKey.CM010_RQ_DATA, JSON.stringify(CM010RqDataObj));
}

function initValidate() {
	/** 字串中間至少要有一碼空格 英文字母之間可放行的符號為:「/」、「-」、「,」、「’」、「.」*/
	$.validator.addMethod('eNameFormat', function(value,element) {
		return /^[a-zA-Z.,\-’\/]+( +[a-zA-Z.,\-’\/]+)+$/gi.test(value);
	},'請輸入正確英文姓名');

	var checkChNameIsEdited = function(element) {
		// 正卡持有人預設不顯示，除非使用者有異動中文姓名
		var orginChName = (CardFriendInfoObj && CardFriendInfoObj.primChName) ? CardFriendInfoObj.primChName : (VR012RsDataObj && VR012RsDataObj.primChName) ? VR012RsDataObj.primChName : "";
		var markOriginName = maskPersonName(orginChName);
		var newChName = $('[name=cPrimChName]').val();
		return (CM010RqDataObj.isOrigin === CommonConstant.IS_ORIGIN && (orginChName !== newChName && markOriginName !== newChName));
	};

	$("#page-form").validate({
		onclick: false,
		onkeyup: false,
		onfocusout: false,
		focusInvalid: false,
		ignore: [], //for checkbox hidden
		rules: {
			cPrimEngName: {
				required: {
					depends: function() {
						return CM010RqDataObj.isOrigin !== CommonConstant.IS_ORIGIN || checkChNameIsEdited();
					}
				},
				eNameFormat:{
					depends: function(element){
						return element.value;
					}
				}
			},
			cardIDCDate_Y: {
				required: {
					depends: function() {
						return CM010RqDataObj.isOrigin != CommonConstant.IS_ORIGIN;
					}
				}
			},
			cardIDCDate_M: {
				required: {
					depends: function() {
						return CM010RqDataObj.isOrigin != CommonConstant.IS_ORIGIN;
					}
				}
			},
			cardIDCDate_D: {
				required: {
					depends: function() {
						return CM010RqDataObj.isOrigin != CommonConstant.IS_ORIGIN;
					}
				}
			},
			cCityCardIssue: {
				required: {
					depends: function() {
						return CM010RqDataObj.isOrigin != CommonConstant.IS_ORIGIN;
					}
				}
			},
			cardIDCFlag: {
				required: {
					depends: function() {
						return CM010RqDataObj.isOrigin != CommonConstant.IS_ORIGIN;
					}
				}
			},
			mPrimMarriage: {
				required: {
					depends: function() {
						return CM010RqDataObj.isOrigin != CommonConstant.IS_ORIGIN;
					}
				}
			},
			mPrimEducation: {
				required: {
					depends: function() {
						return CM010RqDataObj.isOrigin != CommonConstant.IS_ORIGIN;
					}
				}
			},
		},
		messages: {
			cPrimChName: {
				required: "請輸入中文姓名",
				maxlength: "限輸入5個中文字"
			},
			cPrimEngName: {
				required: "請輸入英文姓名"
			},
			cardIDCDate_Y: {
				required: "請輸入完整身分證發證年月日"
			},
			cardIDCDate_M: {
				required: "請輸入完整身分證發證年月日"
			},
			cardIDCDate_D: {
				required: "請輸入完整身分證發證年月日"
			},
			cCityCardIssue: {
				required: "請輸入身分證發證地"
			},
			cardIDCFlag: {
				required: "請輸入身分證發證狀態"
			},
			mPrimMarriage: {
				required: "請輸入婚姻狀態"
			},
			mPrimEducation: {
				required: "請輸入教育程度"
			}
		},
		submitHandler: function() {
			doSubmit();
		},
		invalidHandler: function(event, validator){
			var errorList = validator.errorList;
			// 判斷沒有在errorList之後清掉invalid class
			if($('.is-invalid').length > 0){
				$.each($('.is-invalid'),function(index,element){
					var invalidIdx = matchErrorElementByName(errorList, element);
					if(invalidIdx < 0) {
						$(element).removeClass('is-invalid');
						$('.is-label--'+ element.name).removeClass('is-invalid--label');
					}
				});
			}
		},
		showErrors: function(errorMap, errorList){
			if(errorList.length > 0) {
				$.each(errorList,function(index,invalidObj){
					var element = invalidObj.element;
					$(element).addClass('is-invalid');
					$('.is-label--'+ element.name).addClass('is-invalid--label');
				});
				$(errorList[0].element).goTo();
				// showToast(errorList[0].message);
				showErrAlert(errorList);
			}
		}
	});
}
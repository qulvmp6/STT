package com.mitake.clundcounter.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {

	private static final String FULL_AD_1 = "yyyy-MM-dd HH:mm:ss";
	private static final String FULL_AD_2 = "yyyyMMddHHmmss";
	
	public static String getFullAd1(Date date) {
		return new SimpleDateFormat(FULL_AD_1).format(date);
	}
	
	public static String getFullAd2(Date date) {
		return new SimpleDateFormat(FULL_AD_2).format(date);
	}
	
	public static Date plusDays(Date date, int days) {
		if(date!=null) {
			date.setTime(date.getTime() + days*24*60*60*1000);
		}
		return date;
	}
}

package com.mitake.clundcounter.util;

import java.math.BigInteger;
import java.security.MessageDigest;

public class SHA256Util {

	public static String encode(String input) throws Exception {
		String encodeResult = "";

		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		digest.reset();
		digest.update(input.getBytes("utf8"));
		encodeResult = String.format("%064x", new BigInteger(1, digest.digest()));

		return encodeResult;
	}

	public static void main(String[] args) {
		try {
			System.out.println(SHA256Util.encode("123456"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

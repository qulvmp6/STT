package com.mitake.clundcounter.util;

import java.security.SecureRandom;

import org.apache.commons.lang.StringUtils;

public class StrUtil {
	/**
	 * 
	 * 轉全型
	 * 
	 * @param s
	 * 
	 * @return
	 * 
	 */

	public static String toFullChar(String s) {

		String[] asciiTable = { "!", "\"", "#", "$", "%", "&", "\'", "(", ")",

				"*", "+", ",", "-", ".", "/", "0", "1", "2", "3", "4", "5",

				"6", "7", "8", "9", ":", ";", "<", "=", ">", "?", "@", "A",

				"B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",

				"N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y",

				"Z", "[", "\\", "]", "^", "_", "`", "a", "b", "c", "d", "e",

				"f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q",

				"r", "s", "t", "u", "v", "w", "x", "y", "z", "{", "|", "}",

				"~", " " };

		String[] big5Table = { "！", "”", "＃", "＄", "％", "＆", "’", "（", "）",

				"＊", "＋", "，", "－", "。", "／", "０", "１", "２", "３", "４", "５",

				"６", "７", "８", "９", "：", "；", "＜", "＝", "＞", "？", "＠", "Ａ",

				"Ｂ", "Ｃ", "Ｄ", "Ｅ", "Ｆ", "Ｇ", "Ｈ", "Ｉ", "Ｊ", "Ｋ", "Ｌ", "Ｍ",

				"Ｎ", "Ｏ", "Ｐ", "Ｑ", "Ｒ", "Ｓ", "Ｔ", "Ｕ", "Ｖ", "Ｗ", "Ｘ", "Ｙ",

				"Ｚ", "〔", "＼", "〕", "︿", "﹍", "‵", "ａ", "ｂ", "ｃ", "ｄ", "ｅ",

				"ｆ", "ｇ", "ｈ", "ｉ", "ｊ", "ｋ", "ｌ", "ｍ", "ｎ", "ｏ", "ｐ", "ｑ",

				"ｒ", "ｓ", "ｔ", "ｕ", "ｖ", "ｗ", "ｘ", "ｙ", "ｚ", "｛", "｜", "｝",

				"～", "　" };

		if (s == null || "".equalsIgnoreCase(s)) {

			return "";

		}

		char[] ca = s.toCharArray();

		StringBuffer outStr = new StringBuffer();

		for (int a = 0; a < ca.length; a++) {

			String caStr = String.valueOf(ca[a]);

			for (int b = 0; b < asciiTable.length; b++) {

				if (caStr.equals(asciiTable[b])) {

					caStr = big5Table[b];

					break;

				}

			}

			outStr.append(caStr);

		}

		return outStr.toString();

	}

	/*
	 * 過濾前後空白(含全型空白, 並將全形空白轉半形空白)
	 */
	public static String getTrimSpace(String strCom) {
		String value = "";
		if (strCom != null) {
			value = strCom.replaceAll("　", " ").trim();
		}
		return value;
	}

	/*
	 * 移除所有全半形空白
	 */
	public static String removeAllSpace(String inputStr) {
		String result = "";

		if (inputStr != null && inputStr.length() > 0) {
			result = inputStr.replaceAll(" ", "").replaceAll("　", "");
		}

		return result;
	}

	/*
	 * 補滿字串至預期長度
	 * isPrefix: true, 補滿在字串前綴
	 * isPrefix: false, 補滿在字串後綴 
	 */
	public static String fillStringToLength(String inputStr, int length, char token, boolean isPrefix) {
		StringBuilder result = new StringBuilder();

		if (inputStr != null) {
			result.append(inputStr);

			if (length > inputStr.length()) {
				StringBuilder tokens = new StringBuilder();
				int count = length - inputStr.length();
				for (int i = 0; i != count; i++) {
					tokens.append(token);
				}

				if (isPrefix) {
					result.insert(0, tokens.toString());
				} else {
					result.append(tokens.toString());
				}
			}
		}

		return result.toString();
	}
	
	/*
	 * 產生指定長度亂數數字字串
	 */
	public static String getRandomNumber(int length) {
		String result = "";

		if (length > 0) {
			String charPools = "0123456789";
			StringBuilder sb = new StringBuilder();
			SecureRandom rnd = new SecureRandom();
			while (sb.length() < length) {
				int index = (int) (rnd.nextFloat() * charPools.length());
				sb.append(charPools.charAt(index));
			}
			result = sb.toString();
		}

		return result;
	}

	/*
	 * xml跳脫字元處理
	 */
	public static String getXmlEscapeStr(String originStr) {
		final String[][] xmlEscape = {
			{"&", "&amp;"},	// AND符號固定放第一個處理
			{"<", "&lt;"},
			{">", "&gt;"},
			{"'", "&apos;"},
			{"\"", "&quot;"}
		};
		
		String escapeStr = originStr;
		if (StringUtils.isNotEmpty(escapeStr)) {
			for (String[] rule : xmlEscape) {
				escapeStr = escapeStr.replaceAll(rule[0], rule[1]);
			}
		}

		return escapeStr;
	}

}

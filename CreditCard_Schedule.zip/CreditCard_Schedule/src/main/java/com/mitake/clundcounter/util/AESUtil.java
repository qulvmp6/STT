package com.mitake.clundcounter.util;

import java.nio.charset.StandardCharsets;
import java.security.Security;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mitake.clundcounter.constant.CommonConstant;

public class AESUtil {

	private static final Logger logger = LoggerFactory.getLogger(CommonConstant.LOGGER_NAME_CREDITCARD_SCHEDULE);

	/** cipher */
	private static Cipher cipher = null;

	private static SecretKeySpec skeySpec;

	/**
	 * 初始化SecretKey,key 要補滿16位元
	 * 
	 * @return
	 */
	public static void init(String phoneKey) throws Exception {
		try {
			Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
			cipher = Cipher.getInstance("AES/CBC/PKCS7Padding", "BC");// "算法/模式/補碼方式"
			skeySpec = new SecretKeySpec(phoneKey.getBytes(StandardCharsets.UTF_8.name()), "AES");
		} catch (Exception e) {
			logger.error("encrypt failed {}", e);
			throw new Exception("aesUtils init failed.");
		}
	}

	/**
	 * 加密
	 * 
	 * @param p
	 * @return
	 */
	public static synchronized String encrypt(String p, String phoneKey) throws Exception {
		init(phoneKey);
		String encrypted = "";
		try {
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec, new IvParameterSpec(new byte[16]));
			byte[] encrypt = cipher.doFinal(p.getBytes(StandardCharsets.UTF_8.name()));
			encrypted = new Base64().encodeToString(encrypt).trim();
		} catch (Exception e) {
			logger.error("encrypt failed {}", e);
			throw new Exception("aesUtils encrypt failed.");
		}
		return encrypted;
	}

	/**
	 * 解密
	 * 
	 * @param base64
	 * @param phoneKey
	 * @return
	 */
	public static synchronized String decrypt(String base64, String phoneKey) throws Exception {
		init(phoneKey);
		String decrypted = "";
		try {
			byte[] b = new Base64().decode(base64);
			cipher.init(Cipher.DECRYPT_MODE, skeySpec, new IvParameterSpec(new byte[16]));
			byte[] decrypt = cipher.doFinal(b);
			decrypted = new String(decrypt);
		} catch (Exception e) {
			logger.error("decrypt failed {}", e);
			throw new Exception("aesUtils decrypt 128key failed.");
		}
		return decrypted;
	}

}

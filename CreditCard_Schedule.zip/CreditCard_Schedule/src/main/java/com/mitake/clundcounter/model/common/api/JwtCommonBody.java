package com.mitake.clundcounter.model.common.api;

public class JwtCommonBody {

	protected String data;

	public String getData() {
		return data;
	}

	public void setData(String value) {
		this.data = value;
	}

}

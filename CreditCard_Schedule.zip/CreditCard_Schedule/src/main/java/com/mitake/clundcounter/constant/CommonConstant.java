package com.mitake.clundcounter.constant;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CommonConstant {

	public static String envMode;
	/** 測試用mq response xml資料夾 */
    public static String MOCK_XML_FOLDER;
    
	/** 測試環境電文檢查開關 - 測試IP清單 */
	public final static List<String> API_SWITCH_IP = Arrays.asList("192.168.53.157", "192.168.53.54", "192.168.53.154", "192.168.211.212");

	public final static String CHARSET = "UTF-8";
	
	// log4j依功能寫log檔，對應log4j2.xml內tag Logger的name屬性
	public final static String LOGGER_NAME_CREDITCARD_SCHEDULE = "CreditCardSchedule-logger";
	public final static String LOGGER_NAME_BUSINESSNOTES = "BusinessNotes-logger";
	
	public final static String ERROR_CODE_THIRD_PARTY_PREFIX = "#";
	
	@Value("${PATH.MOCK_XML_FOLDER}")
    public void setMockXmlFolder(String path) {
        CommonConstant.MOCK_XML_FOLDER = path;
    }
	
	@Value("${env.mode}")
	public void setEnvMode(String mode) {
		CommonConstant.envMode = mode;
	}
	
	public static boolean isDevMode() {
		return "DEV".equals(envMode);
	}

	public static boolean isUatMode() {
		return "UAT".equals(envMode);
	}

}

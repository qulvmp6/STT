package com.mitake.clundcounter.util;

import com.fasterxml.jackson.databind.ObjectMapper;

public class BeanUtil {

	public static <T> T jsonToBean(String json, Class<T> beanClass) throws Exception {
		T jsonBean = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			jsonBean = (T) objectMapper.readValue(json, beanClass);
		} catch (Exception e) {
			throw e;
		}
		return jsonBean;
	}

	public static String beanToJson(Object obj) throws Exception {
		String resultJson = "";
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			resultJson = objectMapper.writeValueAsString(obj);
		} catch (Exception e) {
			throw e;
		}
		return resultJson;
	}

}

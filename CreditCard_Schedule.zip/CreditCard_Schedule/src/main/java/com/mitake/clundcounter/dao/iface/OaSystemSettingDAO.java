package com.mitake.clundcounter.dao.iface;

import java.util.List;
import java.util.Map;

import com.mitake.clundcounter.model.domain.OaSystemsetting;

public interface OaSystemSettingDAO {

	public List<Map<String, String>> getSystemSetting(List<String> type);
	
	public OaSystemsetting getSystemSetting(String settingtype, String status);
	
	public int updateSystemSetting(String settingType, String status, String oldFlag, String newFlag);
}

package com.mitake.clundcounter.dao.iface;

import com.mitake.clundcounter.model.domain.OaScBusinessNotes;

public interface OaScBusinessNotesDAO {

	public OaScBusinessNotes findByKey(String itemid);
	
	public void save(OaScBusinessNotes osbn);

	public void update(OaScBusinessNotes osbn);
}

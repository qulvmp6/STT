package com.mitake.clundcounter.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.validator.routines.InetAddressValidator;
import org.apache.logging.log4j.ThreadContext;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.errors.IntrusionException;
import org.owasp.esapi.errors.ValidationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mitake.clundcounter.constant.CommonConstant;
import com.mitake.clundcounter.util.IpUtil;

public class ThreadContextFilter implements Filter {

	private static final Logger logger = LoggerFactory.getLogger(CommonConstant.LOGGER_NAME_CREDITCARD_SCHEDULE);

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;

		ThreadContext.clearMap();
		String ipAddress = "error_ip";
		try {
			// 這裡檢查IPV4
			ESAPI.validator().getValidInput("IPAddress Validation Secure Exercise", IpUtil.getRemoteIP(request),"IPAddress", 200, false);
			ipAddress = IpUtil.getRemoteIP(request);
		} catch (IntrusionException | ValidationException e) {

			// 這裡檢查IPV6
			InetAddressValidator validator = InetAddressValidator.getInstance();
			if (validator.isValidInet6Address(IpUtil.getRemoteIP(request))) {
				ipAddress = IpUtil.getRemoteIP(request);
			} else {
				logger.info("error ip=" + IpUtil.getRemoteIP(request));
				logger.error("failed", e);
			}
		}
		ThreadContext.put("ipAddress", ipAddress);
		// 繼續處理其他的過濾鏈。
		chain.doFilter(request, response);
		ThreadContext.clearMap();
	}

	@Override
	public void destroy() {

	}

}
package com.mitake.clundcounter.dao.impl;

import java.util.List;
import java.util.Map;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mitake.clundcounter.constant.CommonConstant;
import com.mitake.clundcounter.dao.iface.OaScBusinessNotesDAO;
import com.mitake.clundcounter.model.domain.OaScBusinessNotes;

@Repository
@Transactional(rollbackFor= {Exception.class, RuntimeException.class})
public class OaScBusinessNotesDAOImpl implements OaScBusinessNotesDAO {

	private static final Logger logger = LoggerFactory.getLogger(CommonConstant.LOGGER_NAME_BUSINESSNOTES);
	
	@Autowired
	@Qualifier(value="sessionFactory")
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public OaScBusinessNotes findByKey(String bsnoteid) {
		logger.info("findByKey OaScBusinessNotes bsnoteid:{} ", bsnoteid);
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT BSNOTEID, ITEMID, VERNUM FROM ECSDB.OA_SC_BUSINESS_NOTES ");
		sb.append(" WHERE BSNOTEID = :bsnoteid WITH UR ");
		
		Session session = sessionFactory.getCurrentSession();
		SQLQuery query  = session.createSQLQuery(sb.toString());
		query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		
		query.setParameter("bsnoteid", bsnoteid);
		
		OaScBusinessNotes osbn = null;
		List<Map<String, String>> list = query.list();
		if (!list.isEmpty()) {
			Map<String, String> row  = list.get(0);
			osbn = new OaScBusinessNotes();
			osbn.setBsnoteid(row.get("BSNOTEID"));
			osbn.setItemid(row.get("ITEMID"));
			osbn.setVernum(row.get("VERNUM"));
		}
		return osbn;
	}
	
	@Override
	public void save(OaScBusinessNotes osbn) {
		StringBuilder sb = new StringBuilder();
		sb.append("INSERT INTO ECSDB.OA_SC_BUSINESS_NOTES(BSNOTEID, ITEMID, NOTENAME, VERNUM, DOWNLOADLINK, CLAUSEPDF, CLAUSEHTML) ");
		sb.append("VALUES (:bsnoteid, :itemid, :notename, :vernum, :downloadlink, :clausepdf, :clausehtml)");
		
		Session session = sessionFactory.getCurrentSession();
		SQLQuery query  = session.createSQLQuery(sb.toString());
		
		query.setParameter("bsnoteid", osbn.getBsnoteid());
		query.setParameter("itemid", osbn.getItemid());
		query.setParameter("notename", osbn.getNotename());
		query.setParameter("vernum", osbn.getVernum());
		query.setParameter("downloadlink", osbn.getDownloadlink());
		query.setParameter("clausepdf", osbn.getClausepdf());
		query.setParameter("clausehtml", osbn.getClausehtml());

		query.executeUpdate();
	}
	
	@Override
	public void update(OaScBusinessNotes osbn) {
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ECSDB.OA_SC_BUSINESS_NOTES ");
		sb.append("   SET ITEMID = :itemid, NOTENAME = :notename, VERNUM = :vernum, DOWNLOADLINK = :downloadlink, ");
		sb.append("       CLAUSEPDF = :clausepdf, CLAUSEHTML = :clausehtml ");
		sb.append(" WHERE BSNOTEID = :bsnoteid ");
		
		Session session = sessionFactory.getCurrentSession();
		SQLQuery query  = session.createSQLQuery(sb.toString());
		
		query.setParameter("bsnoteid", osbn.getBsnoteid());
		query.setParameter("itemid", osbn.getItemid());
		query.setParameter("notename", osbn.getNotename());
		query.setParameter("vernum", osbn.getVernum());
		query.setParameter("downloadlink", osbn.getDownloadlink());
		query.setParameter("clausepdf", osbn.getClausepdf());
		query.setParameter("clausehtml", osbn.getClausehtml());
		
		query.executeUpdate();
	}
}

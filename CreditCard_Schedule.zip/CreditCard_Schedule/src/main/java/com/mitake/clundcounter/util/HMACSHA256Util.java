package com.mitake.clundcounter.util;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

public class HMACSHA256Util {

	public static String encode(String input, String salt) throws Exception {
		String encodeResult = "";

		Mac hmacSHA256 = Mac.getInstance("HmacSHA256");
		SecretKeySpec secretKey = new SecretKeySpec(salt.getBytes(), "HmacSHA256");
		hmacSHA256.init(secretKey);

		encodeResult = Base64.encodeBase64String(hmacSHA256.doFinal(input.getBytes()));

		return encodeResult;
	}

}

package com.mitake.clundcounter.dao.impl;

import java.util.List;
import java.util.Map;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mitake.clundcounter.dao.iface.OaSystemSettingDAO;
import com.mitake.clundcounter.model.domain.OaSystemsetting;

@Repository
@Transactional(rollbackFor= {Exception.class, RuntimeException.class})
public class OaSystemSettingDAOImpl implements OaSystemSettingDAO {

	@Autowired
	@Qualifier(value="sessionFactory")
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Map<String, String>> getSystemSetting(List<String> type) {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT SETTINGTYPE, STATUS, RESERVESTATUS, DESC ");
		sb.append("  FROM ECSDB.OA_SYSTEMSETTING ");
		sb.append(" WHERE SETTINGTYPE IN (:settingtype) WITH UR ");
		
		Session session = sessionFactory.getCurrentSession();
		SQLQuery query  = session.createSQLQuery(sb.toString());
		query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP) ;
		
		query.setParameterList("settingtype", type);
		
		return query.list();
	};
	
	@SuppressWarnings("unchecked")
	@Override
	public OaSystemsetting getSystemSetting(String settingtype, String status) {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT SETTINGTYPE AS \"settingtype\", STATUS AS \"status\", RESERVESTATUS AS \"reservestatus\" ");
		sb.append("  FROM ECSDB.OA_SYSTEMSETTING ");
		sb.append(" WHERE SETTINGTYPE = :settingtype ");
		sb.append("   AND STATUS = :status ");
		
		Session session = sessionFactory.getCurrentSession();
		SQLQuery query  = session.createSQLQuery(sb.toString());
		query.setResultTransformer(Transformers.aliasToBean(OaSystemsetting.class));
		
		query.setParameter("settingtype", settingtype);
		query.setParameter("status", status);
		
		List<OaSystemsetting> result = query.list();
		
		return result.size() > 0 ? result.get(0) : null;
	}
	
	@Override
	public int updateSystemSetting(String settingType, String status, String oldFlag, String newFlag) {
		StringBuilder sb = new StringBuilder();
		sb.append("UPDATE ECSDB.OA_SYSTEMSETTING ");
		sb.append("   SET RESERVESTATUS = :newFlag, MODIFIER = 'creditcardschedule', MODIFYDATE = CURRENT_TIMESTAMP ");
		sb.append(" WHERE SETTINGTYPE = :settingType AND STATUS = :status ");
		sb.append("   AND RESERVESTATUS = :oldFlag ");
		
		Session session = sessionFactory.getCurrentSession();
		SQLQuery query  = session.createSQLQuery(sb.toString());
		query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		
		query.setParameter("settingType", settingType);
		query.setParameter("status", status);
		query.setParameter("newFlag", newFlag);
		query.setParameter("oldFlag", oldFlag);
		
		return query.executeUpdate();
	}
}

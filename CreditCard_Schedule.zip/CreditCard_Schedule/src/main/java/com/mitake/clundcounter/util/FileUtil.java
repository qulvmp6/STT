package com.mitake.clundcounter.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

public class FileUtil {

	/*
	 * 讀取檔案內容
	 */
	public static String readFile(String filePath) throws IOException {
		String content = "";

		BufferedReader buf = null;
		try {
			InputStream is = new FileInputStream(filePath);
			buf = new BufferedReader(new InputStreamReader(is));
			String line = buf.readLine();
			StringBuilder sb = new StringBuilder();
			while (line != null) {
				sb.append(line);
				line = buf.readLine();
			}
			content = sb.toString();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (buf != null) {
				buf.close();
			}
		}

		return content;
	}

	/*
	 * 取得WEB-INF路徑
	 */
	public static String getWebInfFolderPath() {
		String resultPath = "";

		URL url = FileUtil.class.getResource("");
		String className = url.getFile();
		resultPath = className.substring(0, className.indexOf("WEB-INF") + "WEB-INF".length() + 1);

		return resultPath;
	}

}

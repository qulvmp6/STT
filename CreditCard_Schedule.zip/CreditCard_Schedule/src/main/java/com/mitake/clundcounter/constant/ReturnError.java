package com.mitake.clundcounter.constant;

public enum ReturnError {

	RE_0000("0000","交易成功"),
	RE_C9999("C9999","資料異常，請稍後再試"),
	RE_C1000("C1000","預填表單已超過單日上限"),
	RE_D0001("D0001","查無資料"),
	RE_D9999("D9999","資料庫操作錯誤，請重新再試一次"),
	RE_S9999("S9999","內部系統異常"),
	RE_T8000("T8000","操作時間逾時"),
	RE_T9999("T9999","交易已逾時，請重新交易"),
	RE_V0001("V0001","驗證失敗"),
	RE_V9999("V9999","電文參數錯誤"),
	
	// 串接其他異質平台所得到的對應訊息
	// IBM MQ
	RE_MQ_9999("#M9999", "內部交易失敗"),
	// 印鑑系統
	RE_OCR_9999("#O9999", "上傳影像資料失敗");
	
	private String errorCode;
	private String errorMsg;
	
	private ReturnError(String errorCode, String errorMsg) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
}

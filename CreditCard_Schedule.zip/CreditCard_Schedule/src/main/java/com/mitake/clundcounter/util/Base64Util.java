package com.mitake.clundcounter.util;

import org.apache.commons.codec.binary.Base64;

public class Base64Util {

	public static String encode(String inputStr) throws Exception {
		return new Base64().encodeToString(inputStr.getBytes("UTF8"));
	}

	public static String encode(byte[] inputByteAry) throws Exception {
		return new Base64().encodeToString(inputByteAry);
	}

	public static String decodeToString(String base64Str) throws Exception {
		return new String(new Base64().decode(base64Str));
	}

	public static byte[] decodeToByteAry(String base64Str) throws Exception {
		return new Base64().decode(base64Str);
	}

	public static void main(String[] args) {
		try {
			System.out.println(Base64Util.encode("666666666".getBytes("UTF8")));
			System.out.println(new String(Base64Util.decodeToByteAry("NjY2NjY2NjY2")));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

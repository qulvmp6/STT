package com.mitake.clundcounter.model.common.api;

import com.mitake.clundcounter.constant.ReturnError;

public class JwtResponseHeader {

	private String returnCode;
	private String returnMsg;

	public void setReturnError(ReturnError error) {
		this.returnCode = error.getErrorCode();
		this.returnMsg = error.getErrorMsg();
	}

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public String getReturnMsg() {
		return returnMsg;
	}

	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}

}

package com.mitake.clundcounter.model.common.api;

public class JwtCommonApiResp {

	private JwtResponseHeader responseHeader;
	private JwtCommonBody responseBody;
	
	public JwtCommonApiResp() {
		super();
		this.responseHeader = new JwtResponseHeader();
		this.responseBody = new JwtCommonBody();
	}

	public JwtResponseHeader getResponseHeader() {
		return responseHeader;
	}

	public void setResponseHeader(JwtResponseHeader responseHeader) {
		this.responseHeader = responseHeader;
	}

	public JwtCommonBody getResponseBody() {
		return responseBody;
	}

	public void setResponseBody(JwtCommonBody responseBody) {
		this.responseBody = responseBody;
	}

}

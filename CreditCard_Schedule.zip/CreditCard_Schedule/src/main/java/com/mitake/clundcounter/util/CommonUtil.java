package com.mitake.clundcounter.util;

import com.mitake.clundcounter.constant.CommonConstant;

public class CommonUtil {

	public static String decorateThirdPartyErrorCode(String originErrorCode) {
		return CommonConstant.ERROR_CODE_THIRD_PARTY_PREFIX + originErrorCode;
	}

}

package com.mitake.clundcounter.util;

import java.net.InetAddress;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mitake.clundcounter.constant.CommonConstant;

public class IpUtil {
	
	private static final Logger logger = LoggerFactory.getLogger(CommonConstant.LOGGER_NAME_CREDITCARD_SCHEDULE);

	public static String getLocalIp() {
		try {
		    InetAddress addr = InetAddress.getLocalHost();

		    byte[] ipAddr = addr.getAddress();

		    String s =  (int)(ipAddr[0] & 0x00ff) + "." + (int)(ipAddr[1] & 0x00ff)  + "." +  (int)(ipAddr[2] & 0x00ff)  + "." + (int)(ipAddr[3] & 0x00ff);
		    return s;
		}
		catch(Exception e) {
			logger.error("{}", e);
			throw new RuntimeException(e);
		}
	}

	public static boolean isLocalTestIp() {
		if("10.10.215.95".equals(getLocalIp()))
			return true;
		if(getLocalIp().startsWith("192.168.11."))
			return true;

		return false;
	}

	public static String getRemoteIP(HttpServletRequest request) {
		if(request != null) {
			
			StringBuffer sb = new StringBuffer();
			sb.append("== Request Header Start ... \n");

			java.util.Enumeration<String> enumer = request.getHeaderNames();
			while(enumer.hasMoreElements()) {
				String xName = (String)enumer.nextElement();
				sb.append("[Header]" + xName + " : " + request.getHeader(xName) + "\n");
			}

			sb.append("== Request Header End \n");
			logger.debug(sb.toString());

			String ip = request.getHeader("True-Client-IP");
			if (ip == null || ip.length() == 0) {
				ip = request.getRemoteAddr();
			}

			return ip;
		}
		else {
			return getLocalIp();
		}
	}

	public static String getHead(HttpServletRequest request, String params) {
		logger.debug("getHead params = {}", params);
		String RetS="";
		if(request != null) {

			RetS = request.getHeader(params);
			logger.debug("getHead RetS = {}", RetS);
			if (RetS == null || RetS.length() == 0) {
				RetS = "";
			}

			return RetS;
		}
		else {
			return RetS;
		}
	}

}
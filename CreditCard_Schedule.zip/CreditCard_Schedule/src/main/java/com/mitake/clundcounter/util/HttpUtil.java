package com.mitake.clundcounter.util;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Map;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mitake.clundcounter.constant.CommonConstant;

@SuppressWarnings("deprecation")
public class HttpUtil {

	private static final Logger logger = LoggerFactory.getLogger(CommonConstant.LOGGER_NAME_CREDITCARD_SCHEDULE);

	public static final String CONTENT_TYPE_APPLICATION_JSON_UTF8 = "application/json;charset=UTF-8";
	public static final String CONTENT_TYPE_TEXT_XML_UTF8 = "text/xml;charset=UTF-8";

	public static final String CHARSET_UTF8 = "UTF-8";

	public static String doGet(String url, String charset, Map<String, String> rqHeaderMap) throws Exception {
//		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(
//				SSLContexts.createDefault(), new String[] { "TLSv1.2" }, null,
//				SSLConnectionSocketFactory.getDefaultHostnameVerifier());
		SSLContextBuilder builder = SSLContexts.custom();
		builder.loadTrustMaterial(null, new TrustStrategy() {
			@Override
			public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
				return true;
			}
		});
		SSLContext sslContext = builder.build();
		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, new String[] { "TLSv1.2" }, null, new X509HostnameVerifier() {
			@Override
			public void verify(String host, SSLSocket ssl) throws IOException {
			}

			@Override
			public void verify(String host, X509Certificate cert) throws SSLException {
			}

			@Override
			public void verify(String host, String[] cns, String[] subjectAlts) throws SSLException {
			}

			@Override
			public boolean verify(String s, SSLSession sslSession) {
				return true;
			}
		});
		CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(sslsf).build();

		HttpGet httpGet = new HttpGet(url);
		String tmpCharset = (charset != null && charset.length() > 0) ? charset : CHARSET_UTF8;

		if (rqHeaderMap != null && rqHeaderMap.size() > 0) {
			for (String key : rqHeaderMap.keySet()) {
				httpGet.setHeader(key, rqHeaderMap.get(key));
			}
		}

		HttpResponse response = httpClient.execute(httpGet);

		return handleResponse(response, tmpCharset);
	}

	public static byte[] doGetFile(String url, String charset, Map<String, String> rqHeaderMap) throws Exception {
		//		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(
		//				SSLContexts.createDefault(), new String[] { "TLSv1.2" }, null,
		//				SSLConnectionSocketFactory.getDefaultHostnameVerifier());
		SSLContextBuilder builder = SSLContexts.custom();
		builder.loadTrustMaterial(null, new TrustStrategy() {
			@Override
			public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
				return true;
			}
		});
		SSLContext sslContext = builder.build();
		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, new String[] { "TLSv1.2" }, null, new X509HostnameVerifier() {
			@Override
			public void verify(String host, SSLSocket ssl) throws IOException {
			}

			@Override
			public void verify(String host, X509Certificate cert) throws SSLException {
			}

			@Override
			public void verify(String host, String[] cns, String[] subjectAlts) throws SSLException {
			}

			@Override
			public boolean verify(String s, SSLSession sslSession) {
				return true;
			}
		});
		CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(sslsf).build();

		HttpGet httpGet = new HttpGet(url);
		String tmpCharset = (charset != null && charset.length() > 0) ? charset : CHARSET_UTF8;

		if (rqHeaderMap != null && rqHeaderMap.size() > 0) {
			for (String key : rqHeaderMap.keySet()) {
				httpGet.setHeader(key, rqHeaderMap.get(key));
			}
		}

		HttpResponse response = httpClient.execute(httpGet);

		return handleResponseFile(response, tmpCharset);
	}
	
	public static String doPost(String url, String payload, String charset, Map<String, String> rqHeaderMap) throws Exception {
		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(
				SSLContexts.createDefault(), new String[] { "TLSv1.2" }, null,
				SSLConnectionSocketFactory.getDefaultHostnameVerifier());
		CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(sslsf).build();

		HttpPost httpPost = new HttpPost(url);
		String tmpCharset = (charset != null && charset.length() > 0) ? charset : CHARSET_UTF8;
		StringEntity rqEntity = new StringEntity(payload, tmpCharset);
		httpPost.setEntity(rqEntity);
		
		if (rqHeaderMap != null && rqHeaderMap.size() > 0) {
			for (String key : rqHeaderMap.keySet()) {
				httpPost.setHeader(key, rqHeaderMap.get(key));
			}
		}

		HttpResponse response = httpClient.execute(httpPost);

		return handleResponse(response, charset);
	}

	private static String handleResponse(HttpResponse response, String charset) throws Exception {
		StatusLine statusLine = response.getStatusLine();
		int statusCode = statusLine.getStatusCode();
		if (statusCode == 200 || statusCode == 201) {
			return getResponseBody(response.getEntity(), charset);
		} else {
			logger.info("Http request failed with status code: " + String.valueOf(statusCode));
			throw new Exception("Http request failed with status code: " + String.valueOf(statusCode));
		}
	}

	private static String getResponseBody(HttpEntity entity, String charset) {
		BufferedReader br = null;
		StringBuilder sb = new StringBuilder();

		String line;
		try {

			br = new BufferedReader(new InputStreamReader(entity.getContent(), charset));
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return sb.toString();
	}
	
	private static byte[] handleResponseFile(HttpResponse response, String charset) throws Exception {
		StatusLine statusLine = response.getStatusLine();
		int statusCode = statusLine.getStatusCode();
		if (statusCode == 200 || statusCode == 201) {
			return getResponseBodyFile(response.getEntity(), charset);
		} else {
			logger.info("Http request failed with status code: " + String.valueOf(statusCode));
			throw new Exception("Http request failed with status code: " + String.valueOf(statusCode));
		}
	}

	private static byte[] getResponseBodyFile(HttpEntity entity, String charset) {
		BufferedInputStream br = null;
		byte[] b = null;
		try {
			br = new BufferedInputStream(entity.getContent());
			b = IOUtils.toByteArray(br);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return b;
	}
}

package com.mitake.clundcounter.model.domain;

public class OaScBusinessNotes implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String bsnoteid;
	private String itemid;
	private String notename;
	private String vernum;
	private String downloadlink;
	private String clausepdf;
	private String clausehtml;

	public OaScBusinessNotes() {
	}

	public OaScBusinessNotes(String bsnoteid, String itemid, String notename, String vernum) {
		this.bsnoteid = bsnoteid;
		this.itemid = itemid;
		this.notename = notename;
		this.vernum = vernum;
	}

	public OaScBusinessNotes(String bsnoteid, String itemid, String notename, String vernum, String downloadlink,
			String clausepdf, String clausehtml) {
		this.bsnoteid = bsnoteid;
		this.itemid = itemid;
		this.notename = notename;
		this.vernum = vernum;
		this.downloadlink = downloadlink;
		this.clausepdf = clausepdf;
		this.clausehtml = clausehtml;
	}

	public String getBsnoteid() {
		return this.bsnoteid;
	}

	public void setBsnoteid(String bsnoteid) {
		this.bsnoteid = bsnoteid;
	}

	public String getItemid() {
		return this.itemid;
	}

	public void setItemid(String itemid) {
		this.itemid = itemid;
	}

	public String getNotename() {
		return this.notename;
	}

	public void setNotename(String notename) {
		this.notename = notename;
	}

	public String getVernum() {
		return this.vernum;
	}

	public void setVernum(String vernum) {
		this.vernum = vernum;
	}

	public String getDownloadlink() {
		return this.downloadlink;
	}

	public void setDownloadlink(String downloadlink) {
		this.downloadlink = downloadlink;
	}

	public String getClausepdf() {
		return this.clausepdf;
	}

	public void setClausepdf(String clausepdf) {
		this.clausepdf = clausepdf;
	}

	public String getClausehtml() {
		return this.clausehtml;
	}

	public void setClausehtml(String clausehtml) {
		this.clausehtml = clausehtml;
	}

}

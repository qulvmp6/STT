package com.mitake.clundcounter.util;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.util.StringUtils;

public class ValidateUtil {
	
	private static List<Integer> mgcCurrChkCodeList = genMGCChkCodeList();
	private static List<String> twCurrChkCodeList = genTWCurrChkCodeList();
	private static List<String> ddCurrChkCodeList = genDDCurrChkCodeList();
	
	/**
	 * 是否為兆豐正確帳號
	 * @param actno			兆豐 11 碼帳號
	 * @return
	 */
	public static boolean isMGCAcno( String actno ) {
		if(StringUtils.hasText(actno) && actno.length()==11) {
			int sum = 0;
			char[] chars = actno.toCharArray();
			int lastNum = Integer.valueOf(actno.substring(actno.length()-1));
			for (int i = 0; i<mgcCurrChkCodeList.size(); i++) {
				Integer chkCode = mgcCurrChkCodeList.get(i);
				char c = chars[i];
				sum += Integer.valueOf(c)*chkCode;
			}
			
			int ret = sum%11;
			ret = (ret==10)? 0: ret;
			if(ret==lastNum) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * 是否為台幣存款帳號
	 * @param actno		帳號
	 * @return
	 */
	public static boolean isTWCurr(String actno) {
		if(isMGCAcno(actno)) {
			String chkCde = actno.substring(3, 5);
			if(!twCurrChkCodeList.contains(chkCde)) {
				return true;
			}
		}
		
		return false;
	}

	/**
	 * 是否為活期存款帳號
	 * @param actno		帳號
	 * @return
	 */
	public static boolean isDDCurr(String actno) {
		if(isMGCAcno(actno)) {
			String chkCde = actno.substring(3, 5);
			if(ddCurrChkCodeList.contains(chkCde)) {
				return true;
			}
		}
		
		return false;
	}
	
	/**判斷是否全數字*/
	public static boolean isNumeric(String str){
		Pattern pattern = Pattern.compile("[0-9]*");
		if(StringUtils.hasText(str) && pattern.matcher(str).matches()) {
			return true;
		}
		return false;
	}
	
	private static List<Integer> genMGCChkCodeList(){
		Integer[] chkCodes = { 4, 3, 2, 8, 7, 6, 5, 4, 3, 2 };
		return Arrays.asList(chkCodes);
	}
	
	private static List<String> genTWCurrChkCodeList(){
		String[] chkCodes = { "03", "05", "15", "16", "17", "18", "31", "32", "39", "45", "46", "47", "48", "49", "50", 
				"53", "57", "58" };
		return Arrays.asList(chkCodes);
	}
	
	private static List<String> genDDCurrChkCodeList(){
		String[] chkCodes = { "01", "02", "06", "07", "08", "09", "10", "11", "12", "13", "14", "19", "60", "61", "62", 
				"63", "64", "65" };
		return Arrays.asList(chkCodes);
	}
}

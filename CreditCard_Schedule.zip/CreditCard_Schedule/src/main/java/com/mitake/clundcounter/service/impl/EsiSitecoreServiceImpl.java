package com.mitake.clundcounter.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mitake.clundcounter.dao.iface.OaScBusinessNotesDAO;
import com.mitake.clundcounter.dao.iface.OaSystemSettingDAO;
import com.mitake.clundcounter.model.domain.OaScBusinessNotes;
import com.mitake.clundcounter.model.domain.OaSystemsetting;
import com.mitake.clundcounter.service.iface.EsiSitecoreService;
import com.mitake.clundcounter.util.Base64Util;

@Service
public class EsiSitecoreServiceImpl extends BasicServiceImpl implements EsiSitecoreService {
	
	@Autowired
	private OaScBusinessNotesDAO oaScBusinessNotesDAO;
	
	@Autowired
	private OaSystemSettingDAO oaSystemSettingDAO;

	
	@Override
	public int updateSystemSetting(String settingType, String status, String oldFlag, String newFlag) {
		return oaSystemSettingDAO.updateSystemSetting(settingType, status, oldFlag, newFlag);
	}
	
	@Override
	public OaSystemsetting getSystemSetting(String settingtype, String status) {
		return oaSystemSettingDAO.getSystemSetting(settingtype, status);
	}
	
	@Override
	public JSONObject BusinessNotes(Logger logger) throws Exception {
		JSONObject errObj = new JSONObject();
		try {
			String[] settingtype = {"OA_SCHEDULE", "OA_SC_BUSINESS_NOTES"};
			List<Map<String, String>> dataList = this.getSystemParamData(logger, Arrays.asList(settingtype));
			Map<String, String> common = dataList.get(0);
			Map<String, String> itemid = dataList.get(1);
			
			String businessUrl = common.get("url")
					.replace("{source}", common.get("source"))
					.replace("{clientid}", common.get("clientid"));
			
			for (String key : itemid.keySet()) {
				if (!itemid.get(key).isEmpty()) {
					try {
						String businessUrlNoteUrl = businessUrl.replace("{itemid}", itemid.get(key));
						logger.info("businessUrlNoteUrl："+businessUrlNoteUrl);
						String thirdStr = this.levelCheck(logger, businessUrlNoteUrl, "item");
						if (!"false".equals(thirdStr)) {
							boolean bool = this.BusinessNotesData(logger, key, thirdStr);
							if (!bool) {
								errObj.put(key, "資料內容解析失敗");
							}
						}
					} catch (Exception e) {
						errObj.put(key, e.toString());
						logger.error(e.toString());
					}
				} else {
					errObj.put(key, "OA_SYSTEMSETTING內RESERVESTATUS不得為空");
					logger.error("key {}:OA_SYSTEMSETTING內RESERVESTATUS不得為空", key);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			this.errorException(e);
		}
		return errObj;
	}

	/**
	 * 由資料庫取得資料源資訊
	 * @param logger
	 * @param type
	 * @return
	 * @throws Exception
	 */
	@Transactional(readOnly = true)
	private List<Map<String, String>> getSystemParamData(Logger logger, List<String> type) throws Exception {
		List<Map<String, String>> ossList = oaSystemSettingDAO.getSystemSetting(type);
		return this.systemParamSortOut(type, ossList);
	}
	
	/**
	 * @param ossList
	 * @return
	 * @throws Exception
	 */
	private List<Map<String, String>> systemParamSortOut(List<String> type, List<Map<String, String>> ossList) throws Exception {
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		Map<String, String> common = new HashMap<String, String>();
		Map<String, String> itemid = new HashMap<String, String>();
		Set<String> inputSet = new HashSet<String>();
		inputSet.addAll(Arrays.asList(new String[]{"url", "clientid", "source"}));
		for (Map<String, String> oss : ossList) {
			if (inputSet.contains(oss.get("STATUS"))) {
				common.put(oss.get("STATUS"), oss.get("RESERVESTATUS"));
			} else {
				itemid.put(oss.get("STATUS"), oss.get("RESERVESTATUS"));
			}
		}
		
		if (!common.isEmpty()) {
			dataList.add(common);
		} else {
			this.errorException("common資料取得錯誤");
		}
		
		if (type.size() > 1) {
			if (!itemid.isEmpty()) {
				dataList.add(itemid);
			} else {
				this.errorException("itemid資料取得錯誤");
			}
		}
		
		return dataList;
	}
	
	private boolean BusinessNotesData(Logger logger, String key, String thirdStr) throws JSONException, Exception {
		boolean result = false;
		try {
			JSONObject thirdLevel = strToJson(thirdStr);
			//第三層內容檢查
			if (thirdLevel.isNull("ItemID")) {
				this.JsonTagNameError("result/item/ItemID");
			} else if (thirdLevel.isNull("Name")) {
				this.JsonTagNameError("result/item/Name");
			} else if (thirdLevel.isNull("VerNum")) {
				this.JsonTagNameError("result/item/VerNum");
			} else if (thirdLevel.isNull("Download Link")) {
				this.JsonTagNameError("result/item/Download Link");
			} else if (thirdLevel.isNull("Content")) {
				this.JsonTagNameError("result/item/Content");
			} else {
				String itemId = thirdLevel.get("ItemID").toString().replace("{", "").replace("}", "");
				String verNum = thirdLevel.get("VerNum").toString();
//				if ("".equals(verNum)) {
//					logger.warn("key{} 版本號不得為空");
//					return result;
//				}
				
				OaScBusinessNotes osbn = null;
				OaScBusinessNotes dirtyData = oaScBusinessNotesDAO.findByKey(key);
				if (dirtyData == null) {
					osbn = this.setOaScBusinessNotes(logger, key, itemId, verNum, thirdLevel);
					oaScBusinessNotesDAO.save(osbn);
					logger.info("key {} 查無此內故新增", key);
				} else {
					//版號不一樣時更新
					if (!verNum.equals(dirtyData.getVernum())) {
						osbn = this.setOaScBusinessNotes(logger, key, itemId, verNum, thirdLevel);
						oaScBusinessNotesDAO.update(osbn);
						logger.info("key {} 版本號 新：{} 舊：{} 更新", key, verNum, dirtyData.getVernum());
					} else {
						logger.info("key {} 版本號 新：{} 舊：{} 不需更新", key, verNum, dirtyData.getVernum());
					}
				}
				result = true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(e.toString());
			e.printStackTrace();
		}
		return result;
	}
	
	
	private OaScBusinessNotes setOaScBusinessNotes(Logger logger, String key, String itemId, String verNum, JSONObject thirdLevel) throws JSONException, Exception {
		OaScBusinessNotes osbn = new OaScBusinessNotes();
		osbn.setBsnoteid(key);
		osbn.setItemid(itemId);
		osbn.setNotename(thirdLevel.get("Name").toString());
		osbn.setVernum(verNum);
		osbn.setDownloadlink(thirdLevel.get("Download Link").toString());
		osbn.setClausepdf(this.getPdfFile(thirdLevel.get("Download Link").toString()));
		osbn.setClausehtml(Base64Util.encode(thirdLevel.get("Content").toString()));
		
		logger.info("show BusinessNotesData info start============");
		logger.info("bsnoteid      :{}", osbn.getBsnoteid());
		logger.info("itemid        :{}", osbn.getItemid());
		logger.info("notename      :{}", osbn.getNotename());
		logger.info("vernum        :{}", osbn.getVernum());
		logger.info("downloadlink  :{}", osbn.getDownloadlink());
		//以下二個資料過於龐大故不印出
//		logger.info("clausepdf     :{}", osbn.getClausepdf());
//		logger.info("clausehtml    :{}", osbn.getClausehtml());
		logger.info("show BusinessNotesData info end============");
		
		return osbn;
	}
}

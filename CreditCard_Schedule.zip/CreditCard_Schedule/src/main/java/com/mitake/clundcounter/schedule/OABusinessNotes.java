package com.mitake.clundcounter.schedule;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.mitake.clundcounter.constant.CommonConstant;
import com.mitake.clundcounter.service.iface.EsiSitecoreService;

public class OABusinessNotes {

	private static final Logger logger = LoggerFactory.getLogger(CommonConstant.LOGGER_NAME_BUSINESSNOTES);
	
	@Autowired
	EsiSitecoreService esiSitecoreService;
	
	public void start() {
		logger.info("======schedule OABusinessNotes start======");
		try {
			int flagSuccess = esiSitecoreService.updateSystemSetting("OA_SCHEDULE_FLAG", "BUSINESSNOTES", "Y", "N");
			logger.info("schedule flag update success count: {}", flagSuccess);
			if (flagSuccess >= 1) {
				try {
					esiSitecoreService.BusinessNotes(logger);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					logger.error("schedule OABusinessNotes is faild. error:"+e.toString());
				}
				esiSitecoreService.updateSystemSetting("OA_SCHEDULE_FLAG", "BUSINESSNOTES", "N", "Y");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("schedule OABusinessNotes update systemsetting is faild. error:"+e.toString());
		}
		logger.info("======schedule OABusinessNotes end======");
	}
}

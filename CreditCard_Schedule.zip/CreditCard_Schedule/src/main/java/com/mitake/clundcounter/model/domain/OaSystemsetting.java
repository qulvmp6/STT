package com.mitake.clundcounter.model.domain;

import java.util.Date;

public class OaSystemsetting implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String settingtype;
	private String status;
	private String reservestatus;
	private String desc;
	private String creator;
	private Date createdate;
	private String modifier;
	private Date modifydate;

	public OaSystemsetting() {
	}

	public OaSystemsetting(String settingtype, String status, String reservestatus, String desc) {
		this.settingtype = settingtype;
		this.status = status;
		this.reservestatus = reservestatus;
		this.desc = desc;
	}
	
	public OaSystemsetting(String settingtype, String status, String desc, String creator, Date createdate) {
		this.settingtype = settingtype;
		this.status = status;
		this.desc = desc;
		this.creator = creator;
		this.createdate = createdate;
	}

	public OaSystemsetting(String settingtype, String status, String reservestatus, String desc, String creator, Date createdate,
			String modifier, Date modifydate) {
		this.settingtype = settingtype;
		this.status = status;
		this.reservestatus = reservestatus;
		this.desc = desc;
		this.creator = creator;
		this.createdate = createdate;
		this.modifier = modifier;
		this.modifydate = modifydate;
	}

	public String getSettingtype() {
		return settingtype;
	}

	public void setSettingtype(String settingtype) {
		this.settingtype = settingtype;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getReservestatus() {
		return this.reservestatus;
	}

	public void setReservestatus(String reservestatus) {
		this.reservestatus = reservestatus;
	}

	public String getDesc() {
		return this.desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getCreator() {
		return this.creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public Date getCreatedate() {
		return this.createdate;
	}

	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}

	public String getModifier() {
		return this.modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public Date getModifydate() {
		return this.modifydate;
	}

	public void setModifydate(Date modifydate) {
		this.modifydate = modifydate;
	}

}

package com.mitake.clundcounter.service.impl;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;

import com.mitake.clundcounter.constant.CommonConstant;
import com.mitake.clundcounter.util.Base64Util;
import com.mitake.clundcounter.util.HttpUtil;

public class BasicServiceImpl {

	//檢查json第一、二層固定格式
	protected String levelCheck(Logger logger, String url, String itemStr) throws Exception {
		String result = "false"; //解析過程失敗皆回傳false
		String str = HttpUtil.doGet(url, CommonConstant.CHARSET, null);
		JSONObject firstLevel = strToJson(str);
		if (!firstLevel.isNull("StatusCode")) {
			//檢查狀態碼
			if ("200".equals(firstLevel.get("StatusCode").toString())) {
				//第一層內容檢查 result
				if (!firstLevel.isNull("result")) {
					JSONObject secondLevel = strToJson(firstLevel.get("result").toString());
					//第二層內容檢查 item
					if (!secondLevel.isNull(itemStr)) {
						//前面檢查成功寫入內容
						result = secondLevel.get(itemStr).toString();
					} else {
						this.JsonTagNameError("result/"+itemStr);
					}
				} else {
					this.JsonTagNameError("result");
				}
			} else {
				this.JsonTagStatusCodeNotOk(firstLevel.get("StatusCode").toString());
			}
		} else {
			this.JsonTagNameError("StatusCode");
		}
		return result;
	}
		
	//下載pdf並轉換成byte在用base64加密回傳
	protected String getPdfFile(String urlLink) throws Exception {
		if (!"".equals(urlLink)) {
			byte[] fileByte = HttpUtil.doGetFile(urlLink, CommonConstant.CHARSET, null);
			return Base64Util.encode(fileByte);
		} else {
			return "";
		}
	}
	
	protected void JsonTagStatusCodeNotOk(String msg) throws Exception {
		throw new Exception("失敗：狀態碼為 " + msg);
	}
	
	protected void JsonTagNameError(String msg) throws Exception {
		throw new Exception("該JSON格式與原先制定格式不同，找不到 " + msg + " 內容。");
	}
	
	protected void errorException(String errorMsg) throws Exception {
		throw new Exception(errorMsg);
	}
	
	protected void errorException(Exception e) throws Exception {
		throw new Exception(e);
	}
	
	protected JSONObject strToJson(String str) {
		return new JSONObject(str);
	}
	
	protected JSONArray strToJsonArray(String str) {
		return new JSONArray(str);
	}
}
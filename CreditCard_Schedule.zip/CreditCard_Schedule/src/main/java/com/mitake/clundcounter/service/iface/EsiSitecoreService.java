package com.mitake.clundcounter.service.iface;

import org.json.JSONObject;
import org.slf4j.Logger;

import com.mitake.clundcounter.model.domain.OaSystemsetting;

public interface EsiSitecoreService {

	/**
	 * OA_SCHEDULE排程FLAG設定
	 * @param settingType
	 * @param status
	 * @param oldFlag
	 * @param newFlag
	 * @return
	 */
	public int updateSystemSetting(String settingType, String status, String oldFlag, String newFlag);
	
	/**
	 * OA_SCHEDULE查詢排程是否正在執行
	 * @param settingtype
	 * @param status
	 * @return
	 */
	public OaSystemsetting getSystemSetting(String settingtype, String status);
	
	/**
	 * 條款頁
	 * @param logger
	 * @return
	 * @throws Exception
	 */
	public JSONObject BusinessNotes(Logger logger) throws Exception;
	
}

package com.mitake.clundcounter.controller;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mitake.clundcounter.constant.CommonConstant;
import com.mitake.clundcounter.constant.ReturnError;
import com.mitake.clundcounter.model.common.api.JwtCommonApiResp;
import com.mitake.clundcounter.model.domain.OaSystemsetting;
import com.mitake.clundcounter.service.iface.EsiSitecoreService;

@Controller
@RequestMapping("/api")
public class ScheduleNativeRun {

	private static final Logger logger = LoggerFactory.getLogger(CommonConstant.LOGGER_NAME_CREDITCARD_SCHEDULE);
	
	@Autowired
	private EsiSitecoreService esiSitecoreService;
	
	@RequestMapping(value = "/BusinessNotes", method = RequestMethod.GET)
	public @ResponseBody JwtCommonApiResp BusinessNotes() {
		logger.info("======BusinessNotes api run start======");
		JwtCommonApiResp resp = new JwtCommonApiResp();
		
		try {
			OaSystemsetting oaflag = esiSitecoreService.getSystemSetting("OA_SCHEDULE_FLAG", "BUSINESSNOTES");
			if ("Y".equals(oaflag.getReservestatus())) {
				JSONObject result = esiSitecoreService.BusinessNotes(logger);
				if (result.length() > 0) {
					resp.getResponseHeader().setReturnError(ReturnError.RE_S9999);
					resp.getResponseBody().setData(result.toString());
				} else {
					resp.getResponseHeader().setReturnError(ReturnError.RE_0000);
					resp.getResponseBody().setData("");
				}
			} else {
				resp.getResponseHeader().setReturnCode(ReturnError.RE_C9999.getErrorCode());
				resp.getResponseHeader().setReturnMsg("排程正在執行中請稍候在執行!!");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("exception catched", e);
			resp.getResponseHeader().setReturnError(ReturnError.RE_C9999);
		}
		logger.info("======BusinessNotes api run end======");
		return resp;
	}
	
}

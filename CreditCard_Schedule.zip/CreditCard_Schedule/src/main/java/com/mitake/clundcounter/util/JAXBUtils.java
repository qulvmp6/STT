package com.mitake.clundcounter.util;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;

public class JAXBUtils {
	
	/* (non-Javadoc)
	 * @see com.fubon.mobile.insurance.pad.webservice.handler.intrface.ISecurityHandle#bean2Xml(java.lang.Class, java.lang.Object)
	 */
	public static String bean2Xml(Class<?> beanClass, Object xmlBean) throws Exception {
		String xmlStr = null;
		try {
			JAXBContext context = null;
			context = JAXBContext.newInstance(beanClass);
			Marshaller ma = context.createMarshaller();
//			ma.setProperty("com.sun.xml.bind.namespacePrefixMapper", new NamespacePrefixMapperImpl());
			StringWriter w = new StringWriter();
			ma.marshal(xmlBean, w);
			xmlStr = w.toString();
			return xmlStr;
		}
		catch (Exception e) {
			throw e;
		}
	}

	/* (non-Javadoc)
	 * @see com.fubon.mobile.insurance.pad.webservice.handler.intrface.ISecurityHandle#Xml2Bean(java.lang.String, java.lang.Class)
	 */
	@SuppressWarnings("unchecked")
	public static <T> T Xml2Bean(String xml, Class<T> beanClass) throws Exception {
		T xmlBean = null;
		try {
			JAXBContext context = null;
			context = JAXBContext.newInstance(beanClass);
			Unmarshaller um = context.createUnmarshaller();
//			xmlBean = (T) um.unmarshal(new StringReader(ToolUtil.documentToString(xml)));
			XMLInputFactory xif = XMLInputFactory.newInstance();
			xif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
			xif.setProperty(XMLInputFactory.SUPPORT_DTD, false);
			XMLStreamReader xsr = xif.createXMLStreamReader(new StringReader(xml));
			xmlBean = (T) um.unmarshal(xsr);
		}
		catch (Exception e) {
			throw e;
		}
		return xmlBean;
	}

}
